# Detection fixtures

`messages.jsonl` contains 150 synthetic, UTF-8 labeled examples: 120 scam-style examples across ten categories and 30 ordinary messages. It includes English, Hindi, and Kannada text, including benign bank OTP notices, account updates, deliveries, cab rides, and food orders.

The records are deliberately authored test fixtures, not user reports or a representative sample of real-world fraud. Run the backend evaluator with `python backend/scripts/evaluate_detection.py`. Its precision, recall, false-positive/false-negative rates, per-category results, and latency describe only these fixtures; they must not be presented as production detection accuracy.
