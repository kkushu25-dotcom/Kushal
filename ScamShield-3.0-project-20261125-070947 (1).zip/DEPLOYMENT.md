# Deployment runbook

No production account, deployment target, domain, database, signing key, or provider credentials were supplied. No deployment has been attempted or claimed.

## Local Compose

With Docker Desktop installed (Compose defaults are for local development only):

```powershell
docker compose up --build
```

Verify `http://localhost:8000/health`, `http://localhost:8000/ready`, API docs at `http://localhost:8000/docs`, and the web app at `http://localhost:5173`. Stop with `Ctrl+C`; use `docker compose down` to stop. Do not add `-v` unless you intend to remove the local development database volume.

Set strong local `POSTGRES_PASSWORD` and `JWT_SECRET` values in a root `.env` before sharing the environment.

## Production sequence

1. Create managed PostgreSQL and a restricted database user; enable backups and point-in-time recovery.
2. Create separate web and API services from this repository. Set the API to Python 3.12 and install the pinned backend lock/requirements.
3. Configure server-side secrets: database URL, JWT signing key, shared Redis URL for rate limits, allowed web origin, refresh-cookie settings, SMTP host/from address and credentials, and `PASSWORD_RESET_URL` pointing at the deployed web reset route. `PASSWORD_RESET_MOBILE_URL` defaults to `scamshield://auth/reset-password`; use a verified HTTPS app link if you configure a domain association. Set `SMTP_USE_SSL=true` for implicit TLS or use STARTTLS (default); never enable plaintext SMTP. Never place server secrets in web/mobile build variables.
4. Configure production CORS to the exact web origin, HTTPS-only cookies, HSTS, CSP, security headers, and request/rate limits.
5. Run the Alembic migration as a release step, not on every web worker startup.
6. Configure health probes (`/health` liveness and `/ready` dependency readiness), structured redacted logs, and an error-monitoring DSN if desired.
7. Deploy the web app with SPA fallback and only public API origin configuration. Ensure the offline shell never caches authenticated API responses.
8. Configure the Expo project ID and Android signing/EAS credentials. Build with a pinned EAS CLI and review permissions before publishing an APK/AAB.
9. Run smoke checks in a non-production environment first: registration, login, refresh rotation, message and URL scan, opt-in history, ownership denial, deletion, and emergency resources.
10. For production, run a small controlled smoke test, verify all live URLs and headers, then record actual output in `PROGRESS.md`.

## Rollback

Keep the previous API/web artifact and database backup. Roll back app releases first when migrations are backward compatible. For an incompatible schema migration, follow a reviewed restore/forward-fix plan; do not blindly downgrade if writes have occurred. Disable optional LLM/reputation/push providers independently if they fail. Rotate credentials if compromise is suspected.

## Android build profiles

`apps/mobile/eas.json` defines an internal development APK, an internal preview APK, and a production Android App Bundle. The share-intent native module requires a development or production client; Expo Go does not include it. Link the app to an Expo project with `eas init`, configure Android credentials, and review the permission set before building:

```powershell
cd apps\mobile
npx eas-cli build --platform android --profile development
npx eas-cli build --platform android --profile preview
npx eas-cli build --platform android --profile production
```

Pin the exact EAS CLI release in the project toolchain before release builds; do not use an unpinned `latest` tag. These profiles have not been built because the Expo account/project credentials and Android signing configuration are absent.

