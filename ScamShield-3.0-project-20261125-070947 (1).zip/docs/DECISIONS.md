# Decisions

- 2026-11-25: When the scan API is unavailable, guest message checks may fall back to a clearly labeled reduced ruleset in the browser; opted-in history scans still require the API and are never silently stored locally.
- 2026-11-25: Guest URL checks may use local parsing and shared host signals when the scan API is unavailable; URLs are never fetched and reputation stays not checked.
- 2026-11-25: Guest profile language changes apply immediately and persist as a non-sensitive device preference; account profile changes continue to require authentication.
