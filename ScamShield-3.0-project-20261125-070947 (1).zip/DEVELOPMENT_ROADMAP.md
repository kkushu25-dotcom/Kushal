# Development roadmap

## Milestone 1 — Discovery

Inspect `/reference/` and the repository; record requirements, architecture and diagrams, database, API, screen map, risks, and roadmap. **Status:** documentation created from the written build brief; repo and `/reference/` were empty.

## Milestone 2 — Foundation

Create monorepo and pinned toolchains; shared tokens and localized content; FastAPI app/config/database/migrations/health; Docker Compose; web/mobile shells; CI and API client drift check. Verify with backend, web, mobile, and Compose commands before marking complete.

## Milestone 3 — Backend core

Implement password hashing, access/refresh rotation and reuse detection, cookie/CSRF policy, users, ownership-scoped repositories, error envelope, rate limits, audit redaction, account deletion, password reset, and authorization tests. **Status:** registration/login/logout/refresh, web registration/sign-in/password-reset screens, in-memory web access tokens, HttpOnly refresh cookies with CSRF, remember-me behavior, profile preferences, deletion, shared Redis rate limits, and opt-in owner-scoped metadata scan history are implemented. Reset links use hashed single-use tokens, generic request responses, expiry, SMTP TLS, and refresh-family revocation. GitHub Actions run 45485706196 passed the reset/history implementation. Authorization for emergency cases and family/contact resources remains open because those resources are not stored.

## Milestone 4 — Detection

Build normalization/language/entity extraction, explainable configurable rules, URL parsing, safe fetch (disabled until SSRF tests pass), optional reputation/LLM interfaces, multilingual explanations, 150+ labeled dataset, and real evaluation report. **Status:** normalization, script-based language inference, explainable rule data, entity extraction, offline URL signals, and 150-example synthetic fixture evaluation are implemented. The hosted CI run measured 1.0000 precision/recall and 0 false positives/negatives on these hand-authored fixtures; this is not real-world accuracy. Safe fetching and external providers remain disabled.

## Milestone 5 — Web app

Implement the route shell, onboarding/auth, Home, scanners/results/history, emergency, alerts, learning, protection, privacy, family, settings, query states, PWA, accessibility and Playwright flows. **Status:** responsive shell, welcome guide, Home, guest message/URL scans, session-only guided emergency checklist, registration/sign-in/password reset, profile screens, opt-in scan metadata history, and a recent-scan card are implemented. The welcome E2E passed in run 45480000439; API, web, browser E2E, mobile typecheck, and Compose checks for account history and the Home recent-scan card passed in run 45486625915. A shared set of ten English/Hindi/Kannada lessons, interactive quizzes, synthetic scenarios, explanations, and client-local completion progress is implemented in the web and Android shells and awaits CI. The lesson text is localized; most interface labels remain English. Server-synced progress, personalized recommendations, full app translations, accessibility audits, and most API-backed routes remain open.

## Milestone 6 — Android app

Implement Expo Router tabs/stacks, auth and secure token storage, shared scanning, camera QR with permission states, share-intent intake, offline emergency guidance, opt-in push, and EAS Android build. **Status:** Expo shell, guest message/URL scanning, emergency guidance, shared ten-lesson localized Learn tab, QR decode with user-triggered API assessment, registration/sign-in with rotating refresh-token storage, and opt-in owner-scoped history are present in the workspace. Native password reset requests create app deep links, and reset confirmation and explicit confirmed account deletion are implemented locally. The Profile route also opens a device-local Secure My Account checklist with official Google and Meta guidance. Alerts and emergency guidance now have separate routes; the Alerts tab explicitly reports that push is not available. Related QR, auth, and reset tests are added but not run locally. Push registration/sending, device permission and share-target tests, and a built EAS artifact remain open.

Milestone 6 follow-up: native password recovery and confirmed account deletion are implemented locally. Shared text and links prefill the scanner on-device without auto-submitting. A native share plugin and development/preview/production EAS Android profiles are configured; push registration/sending, share-target and camera device tests, and a built artifact remain open. Related QR, auth, and reset tests are not run locally.

## Milestone 7 — Extended modules

Moderated community reports, explicit/revocable family consent, audit trails, and learning personalization.

## Milestone 8 — Hardening

Review each security control; run regression, load, accessibility and performance checks; fix confirmed issues; publish only measured dataset results.

## Milestone 9 — Deployment and handover

Provision deployment resources, configure secrets, migrate, deploy, smoke-test register/scan/history/delete, verify live URLs, and document rollback. If credentials or deployment access are unavailable, provide exact owner commands and mark the deployment unverified.

## Dependencies and release verification

Use Python 3.12. For current JS toolchains, check official docs and lock exact compatible releases. As checked on 2026-11-24: React 19.3; Expo SDK 58 aligns with React Native 0.88 and React 19.3; Vite 8.3 is its active regular-patch line; FastAPI 0.163.1 is listed in current official release notes. Package versions must still be pinned in manifests/lockfiles and install/build verified before claiming compatibility. See [React versions](https://react.dev/versions), [Expo SDK reference](https://docs.expo.dev/versions/latest/), [Vite release policy](https://vite.dev/releases), and [FastAPI release notes](https://fastapi.tiangolo.com/release-notes/).

