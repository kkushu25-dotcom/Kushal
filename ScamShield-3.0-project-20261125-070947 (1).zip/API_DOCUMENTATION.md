# API contract

The normative API schema is [`docs/openapi.yaml`](docs/openapi.yaml). Base prefix: `/api/v1`. JSON uses UTF-8. Errors use a stable envelope:

```json
{"error":{"code":"validation_error","message":"The request could not be processed.","request_id":"..."}}
```

Do not return secrets, matched raw message text, or ownership details in error messages. A private resource not owned by the current user returns `404`.

## Implementation status

- Implemented now: `GET /health`, `GET /ready`, `POST /scans/messages`, `POST /scans/urls`, `POST /scans/qr`, authenticated opt-in `GET/DELETE /scans` metadata history, `GET/DELETE /scans/{scan_id}`, `/auth/register`, `/auth/login`, `/auth/refresh`, `/auth/logout`, `/auth/password-reset/request`, `/auth/password-reset/confirm`, and `GET/PATCH/DELETE /users/me`.
- Planned in `docs/openapi.yaml`: alerts, server-backed lessons/progress, emergency cases, protection checklists, family consent, community reports, and device registration. These routes are not mounted yet and currently return `404`.

The OpenAPI file describes the target API and is not yet a complete server-generated contract. Do not treat planned routes as available until they are mounted and covered by tests.

## Scans

`POST /scans/messages` accepts `message` (maximum 4,000 Unicode characters), an optional language override (`en`, `hi`, `kn`), and `save_history` (false by default). If language is omitted, the server infers Hindi or Kannada from script and otherwise uses English. The response includes rule indicators with offsets into the original text and URL/phone/UPI candidates; the guest scanner does not persist them. It returns `SAFE`, `SUSPICIOUS`, or `SCAM` as a risk assessment plus uncertainty, actions, engine, and provider status. Confidence is an uncalibrated rule-strength value. When a signed-in user opts in to saving, only scan type, verdict, risk level, category, language, and time are stored; source text and extracted entities are omitted. Anonymous history saves return `401`.

`SAFE` is a schema compatibility value only; display copy must be “No configured warning signs found” with “This does not prove the message is safe.” The API must not equate HTTPS or absence of matches with legitimacy.

`POST /scans/urls` analyzes the supplied string without opening it. Structure signals include shorteners, unusual ports, userinfo, risky TLDs, excessive subdomains, punycode, raw IPs, and configured brand lookalikes. `reputation` is currently `not_checked`; no reputation provider is configured. URL fetching remains off. `GET /scans` returns only the current account's saved metadata using keyset pagination; `DELETE /scans/{scan_id}` deletes an item owned by the current account and returns `404` for another account's ID.

`POST /scans/qr` accepts text decoded locally by the Android camera. It classifies URL, UPI payment request, or other text; returns a risk assessment and localized caution; and parses only the UPI payee, amount, and note for display. It does not save the payload, open links, or initiate payment. In the Android flow, camera decoding stays on-device and the decoded text is sent only after the user taps “Assess QR content.” UPI QR content describes money being sent; entering a UPI PIN authorizes payment and does not receive money.

## Authentication

Passwords use Argon2. Access tokens are short-lived and returned to the web client for in-memory storage. Web refresh uses an HttpOnly/SameSite cookie and CSRF double-submit token; production cookies are Secure. The web “Remember me” choice controls whether that refresh cookie survives browser close, and is retained through token rotation. Mobile refresh tokens are returned in the response and must be stored in OS secure storage. Refresh tokens are hashed in storage, single-use, rotated on success, and revoke their family on reuse. Account deletion removes the user and owned records; mobile deletion clears its secure refresh token. Password-reset requests always return the same response; when SMTP is configured, the API emails a single-use token whose SHA-256 digest is stored for a configurable expiry. `client_type` defaults to `web`; mobile callers request a `scamshield://auth/reset-password` deep link (configurable with `PASSWORD_RESET_MOBILE_URL`). Confirming a reset invalidates outstanding reset tokens and refresh-token families; short-lived access tokens are rejected when their family has no active refresh token. SMTP is optional in development and must be configured for email delivery. Production must configure a high-entropy `JWT_SECRET` and shared `REDIS_URL` for rate limits.

## Generated client

`packages/api-client/src/index.ts` contains the hand-authored calls used by scanners, web authentication, password recovery, and saved scan history. Generated OpenAPI types are not checked in yet; add the generator and drift check after the server contract stabilizes.

