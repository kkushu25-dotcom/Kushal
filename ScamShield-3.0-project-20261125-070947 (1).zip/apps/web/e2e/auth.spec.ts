import { expect, test } from '@playwright/test';

test('registration validates the password and exposes an accessible show-password control', async ({ page }) => {
  await page.goto('/auth/register');
  await page.getByLabel(/email address/i).fill('person@example.com');
  const password = page.getByLabel(/^password$/i);
  await password.fill('short');
  await page.getByRole('button', { name: /show password/i }).click();
  await expect(password).toHaveAttribute('type', 'text');
  await page.getByRole('button', { name: /create account/i }).click();
  await expect(page.getByRole('alert')).toContainText(/at least 12 characters/i);
});

test('web registration keeps access tokens in memory and sends the remember-me choice', async ({ page }) => {
  let submitted: { remember_me?: boolean } | undefined;
  await page.route('**/api/v1/auth/register', async (route) => {
    submitted = route.request().postDataJSON() as { remember_me?: boolean };
    await route.fulfill({
      status: 201,
      contentType: 'application/json',
      body: JSON.stringify({
        access_token: 'test-access-token', csrf_token: 'test-csrf', token_type: 'bearer', expires_in: 900,
        user: { id: 'test-user', email: 'person@example.com', display_name: null, language: 'en', created_at: '2026-01-01T00:00:00Z' },
      }),
    });
  });
  await page.goto('/auth/register');
  await page.getByLabel(/email address/i).fill('person@example.com');
  await page.getByLabel(/^password$/i).fill('long enough secure password');
  await page.getByLabel(/remember me on this device/i).check();
  await page.getByRole('button', { name: /create account/i }).click();
  await expect(page.getByText('person@example.com')).toBeVisible();
  expect(submitted?.remember_me).toBe(true);
  expect(await page.evaluate(() => localStorage.getItem('scamshield-access-token'))).toBeNull();
});

test('signed-in users can explicitly save only assessment metadata', async ({ page }) => {
  let scanRequest: { body: { message?: string; save_history?: boolean }; authorization?: string } | undefined;
  await page.route('**/api/v1/auth/register', async (route) => {
    await route.fulfill({
      status: 201,
      contentType: 'application/json',
      body: JSON.stringify({
        access_token: 'test-access-token', csrf_token: 'test-csrf', token_type: 'bearer', expires_in: 900,
        user: { id: 'test-user', email: 'person@example.com', display_name: null, language: 'en', created_at: '2026-01-01T00:00:00Z' },
      }),
    });
  });
  await page.route('**/api/v1/scans/messages', async (route) => {
    scanRequest = {
      body: route.request().postDataJSON() as { message?: string; save_history?: boolean },
      authorization: route.request().headers().authorization,
    };
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        verdict: 'SUSPICIOUS', risk_level: 'medium', category: null, confidence: 0.5,
        uncertainty: 'This assessment cannot prove the message is safe or fraudulent.',
        indicators: [], entities: [], recommended_actions: [], language: 'en', lesson_id: null,
        engine: 'rules', llm_status: 'not_configured',
      }),
    });
  });

  await page.goto('/auth/register');
  await page.getByLabel(/email address/i).fill('person@example.com');
  await page.getByLabel(/^password$/i).fill('long enough secure password');
  await page.getByRole('button', { name: /create account/i }).click();
  await expect(page.getByText('person@example.com')).toBeVisible();
  await page.getByRole('navigation', { name: /main navigation/i }).getByRole('button', { name: /^scan$/i }).click();
  await page.getByLabel(/save assessment details to my account history/i).check();
  await page.getByLabel(/paste the message/i).fill('This is a private example message.');
  await page.getByRole('button', { name: /check message/i }).click();
  await expect(page.getByRole('status')).toContainText(/original text was not stored/i);
  expect(scanRequest?.body).toEqual({ message: 'This is a private example message.', language: 'en', save_history: true });
  expect(scanRequest?.authorization).toBe('Bearer test-access-token');
});
