import { expect, test } from '@playwright/test';

test('shows the safety dashboard and emergency guidance entry point', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: /your digital safety, made simple/i })).toBeVisible();
  await expect(page.getByRole('button', { name: /need help right now/i })).toBeVisible();
});

