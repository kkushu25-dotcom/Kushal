import { expect, test } from '@playwright/test';

test('emergency checklist advances only after acknowledgement and keeps references in-tab', async ({ page }) => {
  await page.goto('/emergency-centre/lost-money');

  await expect(page.getByRole('heading', { name: /take one step at a time/i })).toBeVisible();
  await expect(page.getByRole('link', { name: /call 1930/i })).toHaveAttribute('href', 'tel:1930');
  await expect(page.getByRole('button', { name: /next step/i })).toBeDisabled();

  await page.getByRole('button', { name: /mark this step complete/i }).click();
  await page.getByRole('button', { name: /next step/i }).click();
  await page.getByRole('button', { name: /mark this step complete/i }).click();
  await page.getByRole('button', { name: /next step/i }).click();
  await expect(page.getByText(/call india's cyber fraud helpline at 1930/i)).toBeVisible();

  await page.getByLabel(/bank complaint reference/i).fill('BANK-REF-2026-44');
  await page.getByLabel(/cybercrime acknowledgement number/i).fill('ACK-2026-114');
  await page.getByRole('button', { name: /save references/i }).click();
  await expect(page.getByRole('status')).toContainText(/not sent to ScamShield/i);
});
