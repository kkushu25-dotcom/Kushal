import { expect, test } from '@playwright/test';

test('learning quiz explains a safer response and tracks tab-local completion', async ({ page }) => {
  await page.goto('/learning-centre/interactive-quizzes');
  await page.getByRole('button', { name: /start quiz/i }).first().click();
  await page.getByRole('button', { name: /end an unexpected call/i }).click();
  await page.getByRole('button', { name: /check answer/i }).click();
  await expect(page.getByRole('status')).toContainText(/safer next step/i);
  await page.getByRole('button', { name: /mark lesson complete/i }).click();
  await expect(page.getByText(/completed/i).first()).toBeVisible();
  await page.getByRole('link', { name: /view this tab’s progress/i }).click();
  await expect(page.getByRole('heading', { name: /1 of 10 lessons completed/i })).toBeVisible();
});
