import { expect, test } from '@playwright/test';

test('welcome flow explains guest privacy and offers a working guest scan entry', async ({ page }) => {
  await page.goto('/welcome');
  await expect(page.getByRole('heading', { name: /pause, check, and choose your next step/i })).toBeVisible();
  await expect(page.getByText(/does not monitor messages or accounts in the background/i)).toBeVisible();
  await page.getByRole('link', { name: /continue as guest/i }).click();
  await expect(page.getByRole('tab', { name: /message/i })).toBeVisible();
});
