import { useState, type JSX } from 'react';
import { Check, ChevronLeft, ChevronRight, RotateCcw, Save, ShieldAlert } from 'lucide-react';

type References = { bank: string; cybercrime: string };

const emptyReferences: References = { bank: '', cybercrime: '' };

function readSessionValue(key: string): { completed: number[]; references: References } {
  try {
    const stored = JSON.parse(sessionStorage.getItem(key) ?? '{}') as Partial<{
      completed: number[];
      references: References;
    }>;
    return {
      completed: Array.isArray(stored.completed) ? stored.completed.filter(Number.isInteger) : [],
      references: { ...emptyReferences, ...stored.references },
    };
  } catch {
    return { completed: [], references: emptyReferences };
  }
}

export function EmergencyChecklist({ steps, storageKey }: { steps: string[]; storageKey: string }): JSX.Element {
  const key = `scamshield-emergency-${storageKey}`;
  const [initial] = useState(() => readSessionValue(key));
  const [stepIndex, setStepIndex] = useState(0);
  const [completed, setCompleted] = useState<Set<number>>(() => new Set(initial.completed));
  const [references, setReferences] = useState<References>(initial.references);
  const [referenceError, setReferenceError] = useState('');
  const [referencesSaved, setReferencesSaved] = useState(Boolean(initial.references.bank || initial.references.cybercrime));
  const [finished, setFinished] = useState(false);
  const currentStep = steps[stepIndex] ?? steps[0] ?? 'Contact your bank using its official app or website.';
  const isStepComplete = completed.has(stepIndex);

  function saveProgress(nextCompleted: Set<number>, nextReferences = references): void {
    sessionStorage.setItem(key, JSON.stringify({ completed: [...nextCompleted], references: nextReferences }));
  }

  function toggleComplete(): void {
    const next = new Set(completed);
    if (next.has(stepIndex)) next.delete(stepIndex);
    else next.add(stepIndex);
    setCompleted(next);
    saveProgress(next);
  }

  function saveReferences(): void {
    const values = [references.bank.trim(), references.cybercrime.trim()];
    const invalidFormat = values.some((value) => value && !/^[A-Za-z0-9][A-Za-z0-9 ._/-]{0,63}$/.test(value));
    const secretLike = values.some((value) => /^\d{4,8}$|^\d{13,19}$/.test(value.replaceAll(' ', '')));
    if (invalidFormat || secretLike) {
      setReferenceError('Enter only a complaint or acknowledgement reference. Do not enter an OTP, PIN, CVV, password, or account/card number.');
      setReferencesSaved(false);
      return;
    }
    const cleaned: References = { bank: values[0] ?? '', cybercrime: values[1] ?? '' };
    setReferences(cleaned);
    setReferenceError('');
    setReferencesSaved(true);
    saveProgress(completed, cleaned);
  }

  function resetChecklist(): void {
    setStepIndex(0);
    setCompleted(new Set());
    setFinished(false);
    saveProgress(new Set());
  }

  return <div className="emergency-workflow">
    <section className="workflow-step surface-card" aria-label="Emergency checklist">
      <div className="workflow-topline">
        <span className="workflow-alert-icon"><ShieldAlert size={18} /></span>
        <div>
          <div className="eyebrow">STEP {Math.min(stepIndex + 1, steps.length)} OF {steps.length}</div>
          <h2>{finished ? 'Checklist complete' : 'Take one step at a time'}</h2>
        </div>
        <span className="workflow-count">{completed.size}/{steps.length}</span>
      </div>
      <div className="workflow-progress" role="progressbar" aria-label="Emergency checklist progress" aria-valuemin={0} aria-valuemax={steps.length} aria-valuenow={completed.size}>
        <span style={{ width: `${steps.length ? (completed.size / steps.length) * 100 : 0}%` }} />
      </div>
      {finished ? <div className="workflow-finished" aria-live="polite"><span className="workflow-done-icon"><Check size={17} /></span><p>You have reached the end of this checklist. Your progress and references remain only in this browser tab.</p><button className="button button-outline" type="button" onClick={() => { setFinished(false); setStepIndex(0); }}>Review steps</button></div> : <>
        <p className="workflow-current" aria-live="polite">{currentStep}</p>
        <button className={`workflow-complete ${isStepComplete ? 'is-complete' : ''}`} type="button" aria-pressed={isStepComplete} onClick={toggleComplete}>
          <span className="workflow-checkbox">{isStepComplete && <Check size={14} />}</span>
          {isStepComplete ? 'Mark this step incomplete' : 'Mark this step complete'}
        </button>
        <div className="workflow-navigation">
          <button className="button button-outline" type="button" disabled={stepIndex === 0} onClick={() => setStepIndex((index) => Math.max(0, index - 1))}><ChevronLeft size={15} /> Previous</button>
          {stepIndex < steps.length - 1
            ? <button className="button button-primary" type="button" disabled={!isStepComplete} onClick={() => setStepIndex((index) => index + 1)}>Next step <ChevronRight size={15} /></button>
            : <button className="button button-primary" type="button" disabled={!isStepComplete} onClick={() => setFinished(true)}>Finish checklist <Check size={15} /></button>}
        </div>
      </>}
      <button className="workflow-reset" type="button" onClick={resetChecklist}><RotateCcw size={13} /> Start over</button>
    </section>

    <section className="reference-card surface-card" aria-labelledby="reference-heading">
      <div className="reference-heading"><span className="reference-icon"><Save size={16} /></span><div><h3 id="reference-heading">Keep your report references</h3><p>Optional · stored in this browser tab only</p></div></div>
      <label htmlFor="bank-reference">Bank complaint reference</label>
      <input id="bank-reference" autoComplete="off" maxLength={64} value={references.bank} onChange={(event) => { setReferences({ ...references, bank: event.target.value }); setReferencesSaved(false); }} placeholder="Enter a reference number" />
      <label htmlFor="cybercrime-reference">Cybercrime acknowledgement number</label>
      <input id="cybercrime-reference" autoComplete="off" maxLength={64} value={references.cybercrime} onChange={(event) => { setReferences({ ...references, cybercrime: event.target.value }); setReferencesSaved(false); }} placeholder="Enter an acknowledgement number" />
      {referenceError && <p className="reference-error" role="alert">{referenceError}</p>}
      <div className="reference-actions"><button className="button button-outline" type="button" onClick={saveReferences}>Save references</button>{referencesSaved && <span role="status">Saved in this tab; not sent to ScamShield.</span>}</div>
      <p className="reference-privacy">Never enter an OTP, UPI PIN, CVV, password, or account/card number here. Closing this tab clears the saved references.</p>
    </section>
  </div>;
}
