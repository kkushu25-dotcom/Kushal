import { Link, useParams } from 'react-router';
import type { JSX } from 'react';
import { ArrowUpRight, CheckCircle2, Info, LockKeyhole, Shield, ExternalLink, Phone } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import emergency from '../../../../packages/content/emergency-resources.json';
import { EmergencyChecklist } from './EmergencyChecklist';
import { ProfileScreen } from './ProfileScreen';
import { Scanner } from './Scanner';
import { ScanHistoryScreen } from './ScanHistoryScreen';
import { LearningScreen } from './LearningScreen';

const guidance: Record<string, { title: string; description: string; bullets: string[] }> = {
  'privacy-centre': { title: 'Privacy Centre', description: 'ScamShield checks only what you submit to a scan. This web app does not inspect browser cookies, other websites, or your bank activity.', bullets: ['Message and URL checks are on demand.', 'Scan history is not saved by default.', 'There is no background SMS, WhatsApp, or banking monitoring.', 'Never enter an OTP, UPI PIN, CVV, password, or full account number.'] },
  'cookie-tracker-scanner': { title: 'Cookie & Tracker Guidance', description: 'ScamShield cannot inspect cookies or trackers on other sites. These steps are general browser guidance.', bullets: ['Use your browser privacy settings to review or clear site data.', 'Clear data only for a site you recognize; this may sign you out.', 'Do not treat a cookie notice or HTTPS connection as proof a site is trustworthy.'] },
  'secure-my-account': { title: 'Secure My Account', description: 'These are steps you can take in the official service. ScamShield cannot change settings or sign you out remotely.', bullets: ['Change a reused or exposed password from the service’s official app or site.', 'Review signed-in devices and remove ones you do not recognize.', 'Turn on two-step verification and check recovery email/phone details.', 'Review connected apps and revoke access you no longer need.'] },
  'security-alerts': { title: 'Security Alerts', description: 'ScamShield does not continuously monitor your messages or accounts. Alert delivery is not enabled in this build.', bullets: ['No monitoring is active in guest mode.', 'Scans do not create alerts yet.', 'A scan result is an assessment, not confirmed fraud.', 'Never call numbers or follow links from a suspicious message.'] },
  'scan-history': { title: 'Scan History', description: 'Review or delete the assessment summaries you chose to save to this account.', bullets: ['Original message text, URLs, and detected entities are excluded.', 'Guest scans and scans without opt-in are not saved.'] },
  'lost-money': { title: 'If you may have lost money', description: 'Act quickly. Contact your bank using an official number or app, and report suspected cyber fraud.', bullets: emergency.steps.en },
  'account-hacked': { title: 'If an account may be hacked', description: 'Use the official service app or site and your bank’s official channels. ScamShield cannot sign you out or recover an account for you.', bullets: ['Contact your bank if payment or banking access could be affected.', 'Change the password from the official service and review active sessions.', 'Secure recovery email and phone access; turn on two-step verification.', 'Call 1930 if money was lost or a financial account was used.', 'Keep messages and transaction references as evidence.'] },
  'report-cyber-fraud': { title: 'Report cyber fraud', description: 'ScamShield guides you to official channels. It does not replace your bank or law enforcement.', bullets: emergency.steps.en },
  'emergency-history': { title: 'Emergency History', description: 'Saved emergency cases require an account and are not available in guest mode.', bullets: ['Guest information is not saved on the server.', 'You can still follow the emergency steps on this page.'] },
  'my-profile': { title: 'Your profile', description: 'You are using ScamShield in guest mode. No account is signed in.', bullets: ['The guest service offers rules-only message and URL checks.', 'Guest results are not saved to a server-side history.'] },
  'notifications': { title: 'Notifications', description: 'Push alerts are not configured in this build. ScamShield does not claim continuous monitoring.', bullets: ['No device is registered for push notifications.', 'You can still open ScamShield and scan on demand.'] },
  'trusted-contacts': { title: 'Trusted Contacts', description: 'Contact storage and sharing are not enabled in this guest session.', bullets: ['Family sharing requires an account and explicit, revocable consent.', 'Message contents are never shared through family alerts.'] },
  'family-protection': { title: 'Family Protection', description: 'Family alerts are not active. No one receives your scan content.', bullets: ['Sharing must be enabled per contact and scope.', 'Only alert metadata may be shared; message contents are excluded.'] },
  'privacy-settings': { title: 'Privacy settings', description: 'Guest scans are not retained. Saved scan summaries are optional and can be deleted from Scan History.', bullets: ['Do not paste sensitive banking credentials.', 'Sign out to end the current account session.'] },
  'scam-lessons': { title: 'Scam Lessons', description: 'Learning topics are guidance and are separate from anything ScamShield has inspected. Full lesson content is not available yet.', bullets: ['Bank impersonation', 'UPI payment requests', 'Delivery fee requests', 'Fake jobs and guaranteed returns'] },
  'interactive-quizzes': { title: 'Interactive Quizzes', description: 'Quiz scoring measures learning activity only, not how protected you are.', bullets: ['Quiz delivery and saved progress are not enabled yet.'] },
  'scam-simulator': { title: 'Scam Simulator', description: 'Simulator examples will be clearly labeled as educational demonstrations.', bullets: ['No message is sent, opened, or reported by this educational feature.'] },
  'learning-progress': { title: 'My Learning Progress', description: 'Learning progress is not a safety score.', bullets: ['No lessons have been completed in this guest session.'] },
  'qr-code-scanner': { title: 'QR Code Safety', description: 'QR decoding is not available yet. Review a payment request in your payment app before approving it.', bullets: ['A QR code can contain a request to send money.', 'Never enter your UPI PIN to receive money.', 'ScamShield never initiates a payment.'] },
  'language': { title: 'Language', description: 'Use the language control in the top bar to switch the navigation labels.', bullets: ['English', 'हिन्दी', 'ಕನ್ನಡ', 'Full-screen translation is not available yet.'] },
};

export function Feature({ notFound = false }: { notFound?: boolean }): JSX.Element {
  const params = useParams();
  const { i18n } = useTranslation();
  const slug = params.feature;
  if (slug === 'message-scanner') return <Scanner mode="message" />;
  if (slug === 'url-scanner') return <Scanner mode="url" />;
  if (slug === 'scan-history') return <ScanHistoryScreen />;
  if (slug === 'scam-lessons') return <LearningScreen mode="lessons" />;
  if (slug === 'interactive-quizzes') return <LearningScreen mode="quiz" />;
  if (slug === 'scam-simulator') return <LearningScreen mode="simulator" />;
  if (slug === 'learning-progress') return <LearningScreen mode="progress" />;
  const item = slug ? guidance[slug] : undefined;
  if (notFound || !item) return <section className="surface-card feature-content"><div className="eyebrow">NOT FOUND</div><h2>We couldn’t find that screen.</h2><p>Choose one of the available ScamShield sections to continue.</p><Link className="button button-outline" to="/">Go to Home</Link></section>;
  if (slug === 'my-profile') return <ProfileScreen />;
  const language = i18n.resolvedLanguage?.startsWith('hi') ? 'hi' : i18n.resolvedLanguage?.startsWith('kn') ? 'kn' : 'en';
  const emergencyScreen = ['lost-money', 'account-hacked', 'report-cyber-fraud', 'emergency-history'].includes(slug ?? '');
  const emergencyFlow = ['lost-money', 'account-hacked', 'report-cyber-fraud'].includes(slug ?? '');
  const workflowSteps = slug === 'account-hacked' ? emergency.accountHacked[language] : emergency.steps[language];
  const Icon = emergencyFlow ? Info : slug === 'secure-my-account' ? LockKeyhole : Shield;
  return <section className="feature-content surface-card">
    <div className="feature-content-icon"><Icon size={19} /></div>
    <p className="feature-lead">{item.description}</p>
    {emergencyScreen && <div className="emergency-disclaimer"><Info size={16} /><span>{emergency.disclaimer[language]}</span></div>}
    {emergencyFlow ? <EmergencyChecklist key={slug} storageKey={slug ?? 'emergency'} steps={workflowSteps} /> : <ol className="guidance-list">{item.bullets.map((bullet) => <li key={bullet}><CheckCircle2 size={16} /><span>{bullet}</span></li>)}</ol>}
    {emergencyFlow && <div className="official-actions"><a className="button button-primary" href={`tel:${emergency.helpline}`}><Phone size={16} /> Call {emergency.helpline}</a><a className="button button-outline" href={emergency.portal} target="_blank" rel="noopener noreferrer">Open cybercrime.gov.in <ExternalLink size={14} /></a></div>}
    {slug === 'secure-my-account' && <div className="official-link-list"><a href="https://myaccount.google.com/security" target="_blank" rel="noopener noreferrer">Google security <ArrowUpRight size={14} /></a><a href="https://www.facebook.com/security/2fac/settings/" target="_blank" rel="noopener noreferrer">Meta security <ArrowUpRight size={14} /></a></div>}
    {['scam-lessons', 'interactive-quizzes', 'scam-simulator', 'learning-progress'].includes(slug ?? '') && <p className="educational-label">Educational guidance · Not a scan result</p>}
    <div className="feature-content-footer"><Link to="/emergency-centre/lost-money">Emergency guidance</Link><Link to="/settings/privacy-settings">Privacy choices</Link></div>
  </section>;
}

