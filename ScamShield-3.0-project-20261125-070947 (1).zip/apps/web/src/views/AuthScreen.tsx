import { useEffect, useState, type JSX } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { z } from 'zod';
import { ArrowRight, Eye, EyeOff, LoaderCircle, Shield } from 'lucide-react';
import { requestPasswordReset, resetPassword, type Language } from '@scamshield/api-client';
import { useAuth } from '../auth/AuthProvider';

type Credentials = { email: string; password: string };

export function AuthScreen(): JSX.Element {
  const { action } = useParams();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { i18n } = useTranslation();
  const auth = useAuth();
  const isRegistration = action === 'register';
  const isReset = action === 'forgot-password';
  const [resetToken] = useState(() => searchParams.get('token') ?? '');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [resetSubmitted, setResetSubmitted] = useState(false);
  const form = useForm<Credentials>({ defaultValues: { email: '', password: '' } });
  const resetRequestForm = useForm<{ email: string }>({ defaultValues: { email: '' } });
  const resetConfirmForm = useForm<{ password: string; confirmation: string }>({ defaultValues: { password: '', confirmation: '' } });

  useEffect(() => {
    if (!resetToken || !searchParams.has('token')) return;
    const cleaned = new URLSearchParams(searchParams);
    cleaned.delete('token');
    setSearchParams(cleaned, { replace: true });
  }, [resetToken, searchParams, setSearchParams]);

  if (action !== 'login' && !isRegistration && !isReset) {
    return <section className="surface-card auth-card"><h2>Page not found</h2><Link to="/">Return home</Link></section>;
  }

  if (isReset) {
    const sendResetRequest = resetRequestForm.handleSubmit(async (values) => {
      const parsed = z.object({ email: z.string().trim().email('Enter a valid email address.').max(254) }).safeParse(values);
      if (!parsed.success) {
        resetRequestForm.setError('email', { message: parsed.error.issues[0]?.message ?? 'Enter a valid email address.' });
        return;
      }
      setSubmitError('');
      try {
        await requestPasswordReset(parsed.data.email);
        setResetSubmitted(true);
      } catch (error) {
        setSubmitError(error instanceof Error ? error.message : 'We could not request a reset. Try again.');
      }
    });

    const saveNewPassword = resetConfirmForm.handleSubmit(async (values) => {
      const parsed = z.object({
        password: z.string().min(12, 'Use at least 12 characters.').max(128, 'Use 128 characters or fewer.'),
        confirmation: z.string(),
      }).refine((value) => value.password === value.confirmation, { message: 'Passwords do not match.', path: ['confirmation'] }).safeParse(values);
      if (!parsed.success) {
        for (const issue of parsed.error.issues) {
          const field = issue.path[0];
          if (field === 'password' || field === 'confirmation') resetConfirmForm.setError(field, { message: issue.message });
        }
        return;
      }
      setSubmitError('');
      try {
        await resetPassword(resetToken, parsed.data.password);
        navigate('/auth/login?reset=complete', { replace: true });
      } catch (error) {
        setSubmitError(error instanceof Error ? error.message : 'This reset link may have expired. Request a new one.');
      }
    });

    if (resetToken) return <section className="surface-card auth-card">
      <div className="auth-mark"><Shield size={20} /></div>
      <div className="eyebrow">ACCOUNT SUPPORT</div>
      <h2>Choose a new password</h2>
      <p className="auth-lead">Use a unique password with at least 12 characters. This reset link works once and has a limited expiry.</p>
      <form className="auth-form" onSubmit={saveNewPassword} noValidate>
        <label htmlFor="reset-password">New password</label>
        <input id="reset-password" type="password" autoComplete="new-password" maxLength={128} {...resetConfirmForm.register('password')} />
        {resetConfirmForm.formState.errors.password && <p className="field-error" role="alert">{resetConfirmForm.formState.errors.password.message}</p>}
        <label htmlFor="reset-confirmation">Confirm new password</label>
        <input id="reset-confirmation" type="password" autoComplete="new-password" maxLength={128} {...resetConfirmForm.register('confirmation')} />
        {resetConfirmForm.formState.errors.confirmation && <p className="field-error" role="alert">{resetConfirmForm.formState.errors.confirmation.message}</p>}
        {submitError && <p className="auth-submit-error" role="alert">{submitError}</p>}
        <button className="button button-primary auth-submit" type="submit" disabled={resetConfirmForm.formState.isSubmitting}>
          {resetConfirmForm.formState.isSubmitting ? <><LoaderCircle className="spin" size={16} /> Please wait…</> : <>Save new password <ArrowRight size={16} /></>}
        </button>
      </form>
      <Link className="auth-forgot" to="/auth/forgot-password">Request a new reset link</Link>
    </section>;

    return <section className="surface-card auth-card">
      <div className="auth-mark"><Shield size={20} /></div>
      <div className="eyebrow">ACCOUNT SUPPORT</div>
      <h2>Reset your password</h2>
      {resetSubmitted ? <p className="auth-lead" role="status">If an account with that email exists and reset email is enabled, instructions will be sent. Check your inbox and spam folder.</p> : <>
        <p className="auth-lead">Enter your account email. If an account exists and email delivery is enabled for this service, ScamShield will send a one-time reset link.</p>
        <form className="auth-form" onSubmit={sendResetRequest} noValidate>
          <label htmlFor="reset-email">Email address</label>
          <input id="reset-email" type="email" autoComplete="email" maxLength={254} {...resetRequestForm.register('email')} />
          {resetRequestForm.formState.errors.email && <p className="field-error" role="alert">{resetRequestForm.formState.errors.email.message}</p>}
          {submitError && <p className="auth-submit-error" role="alert">{submitError}</p>}
          <button className="button button-primary auth-submit" type="submit" disabled={resetRequestForm.formState.isSubmitting}>
            {resetRequestForm.formState.isSubmitting ? <><LoaderCircle className="spin" size={16} /> Please wait…</> : <>Send reset link <ArrowRight size={16} /></>}
          </button>
        </form>
      </>}
      <Link className="button button-outline" to="/auth/login">Back to sign in</Link>
    </section>;
  }

  const submit = form.handleSubmit(async (values) => {
    const schema = z.object({
      email: z.string().trim().email('Enter a valid email address.').max(254),
      password: isRegistration
        ? z.string().min(12, 'Use at least 12 characters.').max(128, 'Use 128 characters or fewer.')
        : z.string().min(1, 'Enter your password.').max(128, 'Use 128 characters or fewer.'),
    });
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      for (const issue of parsed.error.issues) {
        const field = issue.path[0];
        if (field === 'email' || field === 'password') form.setError(field, { message: issue.message });
      }
      return;
    }
    setSubmitError('');
    try {
      const language: Language = i18n.resolvedLanguage?.startsWith('hi') ? 'hi' : i18n.resolvedLanguage?.startsWith('kn') ? 'kn' : 'en';
      if (isRegistration) await auth.register(parsed.data.email, parsed.data.password, language, rememberMe);
      else await auth.login(parsed.data.email, parsed.data.password, rememberMe);
      navigate('/settings/my-profile', { replace: true });
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'We could not complete sign in. Try again.');
    }
  });

  return <section className="surface-card auth-card">
    <div className="auth-mark"><Shield size={20} /></div>
    <div className="eyebrow">{isRegistration ? 'CREATE YOUR ACCOUNT' : 'WELCOME BACK'}</div>
    <h2>{isRegistration ? 'Create your account' : 'Sign in to ScamShield'}</h2>
    {searchParams.get('reset') === 'complete' && <p className="auth-lead" role="status">Your password has been updated. Sign in with the new password.</p>}
    <p className="auth-lead">{isRegistration ? 'Your account keeps profile preferences. Guest scans remain available without signing in.' : 'Your refresh session is kept in an HttpOnly cookie; the access token stays in memory.'}</p>
    <form className="auth-form" onSubmit={submit} noValidate>
      <label htmlFor="auth-email">Email address</label>
      <input id="auth-email" type="email" autoComplete="email" maxLength={254} aria-describedby="auth-email-error" {...form.register('email')} />
      {form.formState.errors.email && <p className="field-error" id="auth-email-error" role="alert">{form.formState.errors.email.message}</p>}
      <label htmlFor="auth-password">Password</label>
      <div className="password-field">
        <input id="auth-password" type={showPassword ? 'text' : 'password'} autoComplete={isRegistration ? 'new-password' : 'current-password'} maxLength={128} aria-describedby="auth-password-help auth-password-error" {...form.register('password')} />
        <button type="button" className="password-toggle" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((visible) => !visible)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>
      </div>
      {form.formState.errors.password && <p className="field-error" id="auth-password-error" role="alert">{form.formState.errors.password.message}</p>}
      <small id="auth-password-help" className="auth-help">{isRegistration ? 'Use 12–128 characters. Never reuse a password exposed elsewhere.' : 'Passwords are never saved in this browser.'}</small>
      <label className="remember-toggle"><input type="checkbox" checked={rememberMe} onChange={(event) => setRememberMe(event.target.checked)} /><span>Remember me on this device</span></label>
      {submitError && <p className="auth-submit-error" role="alert">{submitError}</p>}
      <button className="button button-primary auth-submit" type="submit" disabled={form.formState.isSubmitting}>
        {form.formState.isSubmitting ? <><LoaderCircle className="spin" size={16} /> Please wait…</> : <>{isRegistration ? 'Create account' : 'Sign in'} <ArrowRight size={16} /></>}
      </button>
    </form>
    {!isRegistration && <Link className="auth-forgot" to="/auth/forgot-password">Forgot password?</Link>}
    <p className="auth-switch">{isRegistration ? 'Already have an account?' : 'New to ScamShield?'} <Link to={isRegistration ? '/auth/login' : '/auth/register'}>{isRegistration ? 'Sign in' : 'Create account'}</Link></p>
    <p className="auth-privacy">ScamShield never asks for an OTP, UPI PIN, CVV, or banking password.</p>
  </section>;
}
