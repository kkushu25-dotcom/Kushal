import { useState, type JSX } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, ArrowRight, CheckCircle2, GraduationCap, RotateCcw } from 'lucide-react';
import learning from '../../../../packages/content/learning-content.json';

type LearningMode = 'lessons' | 'quiz' | 'simulator' | 'progress';
type Lesson = (typeof learning.en)[number];
const progressKey = 'scamshield-learning-progress-v1';

function readProgress(): string[] {
  try {
    const value: unknown = JSON.parse(sessionStorage.getItem(progressKey) ?? '[]');
    return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
  } catch {
    return [];
  }
}

export function LearningScreen({ mode }: { mode: LearningMode }): JSX.Element {
  const [language, setLanguage] = useState<'en' | 'hi' | 'kn'>('en');
  const [completed, setCompleted] = useState<string[]>(readProgress);
  const [lessonId, setLessonId] = useState<string | null>(null);
  const [choice, setChoice] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const lessons = learning[language] as Lesson[];
  const lesson = lessons.find((item) => item.id === lessonId);

  function openLesson(id: string): void {
    setLessonId(id);
    setChoice(null);
    setChecked(false);
  }

  function markComplete(id: string): void {
    const next = completed.includes(id) ? completed : [...completed, id];
    setCompleted(next);
    try { sessionStorage.setItem(progressKey, JSON.stringify(next)); } catch { /* Progress is optional when storage is unavailable. */ }
    setLessonId(null);
  }

  const isCorrect = lesson !== undefined && choice === lesson.answerIndex;
  const title = mode === 'quiz' ? 'Interactive quizzes' : mode === 'simulator' ? 'Practice scenario' : mode === 'progress' ? 'Learning progress' : 'Scam safety lessons';

  if (mode === 'progress') {
    const done = lessons.filter((item) => completed.includes(item.id));
    return <section className="learning-screen surface-card">
      <div className="learning-icon"><GraduationCap size={20} /></div><div className="eyebrow">LEARNING PROGRESS</div><h2>{done.length} of {lessons.length} lessons completed</h2>
      <p>Progress stays in this browser tab. It is learning activity, not a safety score or a measure of scam protection.</p>
      {done.length ? <ul className="learning-completed">{done.map((item) => <li key={item.id}><CheckCircle2 size={16} /><span>{item.title}</span></li>)}</ul> : <p>No lessons completed in this tab yet. Start with a short scenario below.</p>}
      <div className="learning-actions"><Link className="button button-primary" to="/learning-centre/scam-lessons">Browse lessons <ArrowRight size={15} /></Link><button className="button button-outline" type="button" onClick={() => { setCompleted([]); try { sessionStorage.removeItem(progressKey); } catch { /* Progress is optional when storage is unavailable. */ } }}><RotateCcw size={14} /> Reset progress</button></div>
    </section>;
  }

  if (!lesson) return <section className="learning-screen">
    <div className="learning-intro surface-card"><div className="learning-icon"><GraduationCap size={20} /></div><div className="eyebrow">{mode === 'simulator' ? 'SYNTHETIC PRACTICE' : 'BUILD PRACTICAL HABITS'}</div><h2>{title}</h2><p>Read a short example, choose a safer next step, and see why it helps. These are educational examples, not scan results.</p><label htmlFor="learning-language">Content language</label><select id="learning-language" value={language} onChange={(event) => setLanguage(event.target.value as 'en' | 'hi' | 'kn')}><option value="en">English</option><option value="hi">हिन्दी</option><option value="kn">ಕನ್ನಡ</option></select></div>
    <div className="learning-cards">{lessons.map((item, index) => {
      const isDone = completed.includes(item.id);
      return <article className="surface-card learning-card" key={item.id}>
        <div className="eyebrow">{mode === 'simulator' ? `SYNTHETIC EXAMPLE ${index + 1}` : `LESSON ${index + 1}`}{isDone ? ' · COMPLETED' : ''}</div><h3>{item.title}</h3><p>{item.summary}</p><button className="button button-outline" type="button" onClick={() => openLesson(item.id)}>{mode === 'quiz' ? 'Start quiz' : mode === 'simulator' ? 'Try scenario' : 'Open lesson'} <ArrowRight size={14} /></button>
      </article>;
    })}</div>
    <Link className="learning-progress-link" to="/learning-centre/learning-progress">View this tab’s progress</Link>
  </section>;

  return <section className="learning-detail surface-card">
    <button className="learning-back" type="button" onClick={() => { setLessonId(null); setChoice(null); setChecked(false); }}><ArrowLeft size={15} /> All {mode === 'quiz' ? 'quizzes' : 'lessons'}</button>
    <div className="eyebrow">{mode === 'simulator' ? 'SYNTHETIC EXAMPLE · NOT A LIVE MESSAGE' : 'PRACTICAL LESSON'}</div><h2>{lesson.title}</h2><p>{lesson.summary}</p>
    {mode === 'simulator' && <div className="learning-scenario"><strong>Example only</strong><p>{lesson.scenario}</p></div>}
    <div className="learning-points"><h3>Remember</h3><ul>{lesson.keyPoints.map((point) => <li key={point}>{point}</li>)}</ul></div>
    <div className="learning-quiz"><div className="eyebrow">CHECK YOUR UNDERSTANDING</div><h3>{lesson.question}</h3><div className="learning-choices">{lesson.choices.map((option, index) => <button className={choice === index ? 'learning-choice selected' : 'learning-choice'} type="button" aria-pressed={choice === index} key={option} onClick={() => { setChoice(index); setChecked(false); }}>{option}</button>)}</div>
      {!checked ? <button className="button button-primary" type="button" disabled={choice === null} onClick={() => setChecked(true)}>Check answer <ArrowRight size={15} /></button> : <div className="learning-feedback" role="status"><strong>{isCorrect ? 'That is a safer next step.' : 'Review the safer next step.'}</strong><p>{lesson.explanation}</p>{!isCorrect && <p>Safer choice: {lesson.choices[lesson.answerIndex]}</p>}<button className="button button-primary" type="button" onClick={() => markComplete(lesson.id)}>{completed.includes(lesson.id) ? 'Return to lessons' : 'Mark lesson complete'} <CheckCircle2 size={15} /></button></div>}
    </div>
    <Link className="learning-progress-link" to="/learning-centre/learning-progress">Progress is not a safety score</Link>
  </section>;
}
