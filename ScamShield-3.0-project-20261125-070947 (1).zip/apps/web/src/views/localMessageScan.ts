import ruleSet from '../../../../backend/app/services/detection/rules.json';
import urlSignals from '../../../../backend/app/services/detection/url_signals.json';
import type { DetectedEntity, Indicator, Language, ScanResult, UrlScanResult } from '@scamshield/api-client';

type RuleConfig = { key: string; category: string; pattern: string; flags?: string[]; priority: number };
type IndexedText = { value: string; starts: number[]; ends: number[] };

const rules = ruleSet as RuleConfig[];
const shorteners = new Set(urlSignals.shorteners);
const riskyTlds = new Set(urlSignals.risky_tlds);
const labels: Record<Language, Record<string, [string, string]>> = {
  en: {
    credentials: ['Sensitive information', 'This text mentions an OTP, credential, or banking detail.'], urgency: ['Urgent pressure', 'Urgent language can pressure people into acting before checking.'], payment_bait: ['Payment or reward claim', 'Unexpected prizes, refunds, or fees are a common lure.'], impersonation: ['Authority or bank claim', 'The sender may be claiming an official or bank role.'], remote_access: ['Remote access request', 'Remote access can expose your device and accounts.'], kyc_update: ['KYC or identity update', 'A message asking to update identity details can lead to credential theft.'], upi_collect: ['UPI payment request', 'A UPI collect request asks you to authorize a payment; it does not receive money for you.'], fake_job: ['Unusual job or task offer', 'Upfront fees and task deposits are warning signs in job offers.'], investment: ['Guaranteed investment claim', 'Promises of guaranteed or unusually high returns deserve independent checks.'], delivery_fee: ['Unexpected delivery charge', 'Unsolicited delivery fees can be used to draw people to a phishing link.'], support_number: ['Unverified support number', 'Use contact details from an official app or website you type yourself.'], short_link: ['Shortened link', 'The destination is hidden behind a link shortener.'], odd_host: ['Unusual web address', 'The address uses a raw IP address or an unusual hostname.'],
  },
  hi: {
    credentials: ['गोपनीय जानकारी', 'इस संदेश में ओटीपी, पासवर्ड या बैंकिंग जानकारी का उल्लेख है।'], urgency: ['जल्दबाज़ी का दबाव', 'तुरंत कार्रवाई का दबाव जांचने का समय कम कर सकता है।'], payment_bait: ['भुगतान या इनाम का दावा', 'अचानक इनाम, रिफंड या शुल्क आम लालच हैं।'], impersonation: ['बैंक या अधिकारी का दावा', 'भेजने वाला बैंक या अधिकारी होने का दावा कर सकता है।'], remote_access: ['रिमोट एक्सेस का अनुरोध', 'रिमोट एक्सेस से आपका डिवाइस और खाते जोखिम में पड़ सकते हैं।'], kyc_update: ['केवाईसी या पहचान अपडेट', 'पहचान विवरण अपडेट करने का संदेश जानकारी चुराने का तरीका हो सकता है।'], upi_collect: ['यूपीआई भुगतान अनुरोध', 'यूपीआई कलेक्ट अनुरोध भुगतान की अनुमति मांगता है; इससे आपको पैसा नहीं मिलता।'], fake_job: ['असामान्य नौकरी या टास्क प्रस्ताव', 'नौकरी के लिए अग्रिम शुल्क या जमा राशि चेतावनी संकेत हैं।'], investment: ['गारंटीड निवेश का दावा', 'गारंटीड या बहुत अधिक रिटर्न के दावों की स्वतंत्र जांच करें।'], delivery_fee: ['अनपेक्षित डिलीवरी शुल्क', 'अनचाहा डिलीवरी शुल्क फ़िशिंग लिंक तक ले जा सकता है।'], support_number: ['असत्यापित सहायता नंबर', 'संपर्क विवरण आधिकारिक ऐप या वेबसाइट से लें।'], short_link: ['छोटा किया गया लिंक', 'लिंक का असली पता छिपा हुआ है।'], odd_host: ['असामान्य वेब पता', 'इस पते में सीधे IP या असामान्य होस्टनाम है।'],
  },
  kn: {
    credentials: ['ಗೌಪ್ಯ ಮಾಹಿತಿ', 'ಈ ಪಠ್ಯದಲ್ಲಿ OTP, ಗುಪ್ತಪದ ಅಥವಾ ಬ್ಯಾಂಕ್ ವಿವರಗಳ ಉಲ್ಲೇಖವಿದೆ.'], urgency: ['ತುರ್ತು ಒತ್ತಡ', 'ತಕ್ಷಣ ಕ್ರಮಕ್ಕೆ ಒತ್ತಾಯಿಸುವುದು ಪರಿಶೀಲನೆಗೆ ಸಮಯ ಕಡಿಮೆ ಮಾಡಬಹುದು.'], payment_bait: ['ಪಾವತಿ ಅಥವಾ ಬಹುಮಾನದ ಹೇಳಿಕೆ', 'ಅನಿರೀಕ್ಷಿತ ಬಹುಮಾನ, ಮರುಪಾವತಿ ಅಥವಾ ಶುಲ್ಕ ಸಾಮಾನ್ಯ ಆಮಿಷಗಳಾಗಿವೆ.'], impersonation: ['ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಧಿಕಾರಿಯ ಹೇಳಿಕೆ', 'ಕಳುಹಿಸಿದವರು ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಧಿಕಾರಿ ಎಂದು ಹೇಳಿಕೊಳ್ಳಬಹುದು.'], remote_access: ['ದೂರಸ್ಥ ಪ್ರವೇಶದ ವಿನಂತಿ', 'ದೂರಸ್ಥ ಪ್ರವೇಶವು ನಿಮ್ಮ ಸಾಧನ ಮತ್ತು ಖಾತೆಗಳನ್ನು ಅಪಾಯಕ್ಕೆ ಒಳಪಡಿಸಬಹುದು.'], kyc_update: ['ಕೆವೈಸಿ ಅಥವಾ ಗುರುತು ನವೀಕರಣ', 'ಗುರುತು ವಿವರಗಳನ್ನು ನವೀಕರಿಸುವ ಸಂದೇಶವು ಮಾಹಿತಿಯನ್ನು ಕದಿಯುವ ಪ್ರಯತ್ನವಾಗಿರಬಹುದು.'], upi_collect: ['ಯುಪಿಐ ಪಾವತಿ ವಿನಂತಿ', 'ಯುಪಿಐ ಕಲೆಕ್ಟ್ ವಿನಂತಿ ಪಾವತಿಗೆ ಅನುಮತಿ ಕೇಳುತ್ತದೆ; ಅದು ನಿಮಗೆ ಹಣ ಸ್ವೀಕರಿಸುವುದಲ್ಲ.'], fake_job: ['ಅಸಾಮಾನ್ಯ ಉದ್ಯೋಗ ಅಥವಾ ಕೆಲಸದ ಆಫರ್', 'ಉದ್ಯೋಗಕ್ಕಾಗಿ ಮುಂಗಡ ಶುಲ್ಕ ಅಥವಾ ಠೇವಣಿ ಎಚ್ಚರಿಕೆಯ ಸೂಚನೆಗಳಾಗಿವೆ.'], investment: ['ಖಚಿತ ಹೂಡಿಕೆ ಲಾಭದ ಹೇಳಿಕೆ', 'ಖಚಿತ ಅಥವಾ ಅತಿಯಾದ ಲಾಭದ ಹೇಳಿಕೆಗಳನ್ನು ಸ್ವತಂತ್ರವಾಗಿ ಪರಿಶೀಲಿಸಿ.'], delivery_fee: ['ಅನಿರೀಕ್ಷಿತ ವಿತರಣಾ ಶುಲ್ಕ', 'ಅನಿರೀಕ್ಷಿತ ವಿತರಣಾ ಶುಲ್ಕ ಫಿಶಿಂಗ್ ಲಿಂಕ್‌ಗೆ ಕರೆದೊಯ್ಯಬಹುದು.'], support_number: ['ಪರಿಶೀಲಿಸದ ಸಹಾಯವಾಣಿ ಸಂಖ್ಯೆ', 'ಅಧಿಕೃತ ಆ್ಯಪ್ ಅಥವಾ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿರುವ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ಬಳಸಿ.'], short_link: ['ಸಂಕ್ಷಿಪ್ತ ಲಿಂಕ್', 'ಲಿಂಕ್‌ನ ನಿಜವಾದ ಗಮ್ಯಸ್ಥಾನ ಮರೆಮಾಡಲಾಗಿದೆ.'], odd_host: ['ಅಸಾಮಾನ್ಯ ವೆಬ್ ವಿಳಾಸ', 'ಈ ವಿಳಾಸದಲ್ಲಿ ನೇರ IP ಅಥವಾ ಅಸಾಮಾನ್ಯ ಹೋಸ್ಟ್ ಹೆಸರು ಇದೆ.'],
  },
};

const copy: Record<Language, { uncertain: string; strong: string; clear: string; action: string; report: string }> = {
  en: { uncertain: 'Some warning signs matched. This reduced offline check can be wrong; verify through a contact method you already trust.', strong: 'Several strong warning signs matched. Do not share codes or money; verify independently.', clear: 'No configured warning signs matched. This check cannot prove the content is safe.', action: 'Do not share OTPs, PINs, passwords, or payment details. Contact the organization using its official app or a number you already trust.', report: 'If money may have been lost in India, contact your bank and call 1930 or report at cybercrime.gov.in.' },
  hi: { uncertain: 'कुछ चेतावनी संकेत मिले। यह सीमित ऑफलाइन जांच गलत हो सकती है; पहले से विश्वसनीय संपर्क माध्यम से पुष्टि करें।', strong: 'कई गंभीर चेतावनी संकेत मिले। कोड या पैसे साझा न करें; स्वतंत्र रूप से पुष्टि करें।', clear: 'निर्धारित चेतावनी संकेत नहीं मिले। इससे सामग्री सुरक्षित साबित नहीं होती।', action: 'OTP, PIN, पासवर्ड या भुगतान विवरण साझा न करें। आधिकारिक ऐप या पहले से ज्ञात नंबर से संस्था से संपर्क करें।', report: 'भारत में पैसे का नुकसान हुआ हो सकता है, तो बैंक से संपर्क करें और 1930 पर कॉल करें या cybercrime.gov.in पर रिपोर्ट करें।' },
  kn: { uncertain: 'ಕೆಲವು ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ. ಈ ಸೀಮಿತ ಆಫ್‌ಲೈನ್ ಪರಿಶೀಲನೆ ತಪ್ಪಾಗಿರಬಹುದು; ಈಗಾಗಲೇ ತಿಳಿದಿರುವ ವಿಶ್ವಾಸಾರ್ಹ ಮಾರ್ಗದಲ್ಲಿ ಪರಿಶೀಲಿಸಿ.', strong: 'ಹಲವು ಗಂಭೀರ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ. ಕೋಡ್ ಅಥವಾ ಹಣವನ್ನು ಹಂಚಬೇಡಿ; ಸ್ವತಂತ್ರವಾಗಿ ಪರಿಶೀಲಿಸಿ.', clear: 'ಸಂರಚಿತ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಹೊಂದಿಕೆಯಾಗಲಿಲ್ಲ. ಇದರಿಂದ ವಿಷಯ ಸುರಕ್ಷಿತವೆಂದು ಸಾಬೀತಾಗುವುದಿಲ್ಲ.', action: 'OTP, PIN, ಗುಪ್ತಪದ ಅಥವಾ ಪಾವತಿ ವಿವರಗಳನ್ನು ಹಂಚಬೇಡಿ. ಅಧಿಕೃತ ಆ್ಯಪ್ ಅಥವಾ ನಿಮಗೆ ಈಗಾಗಲೇ ತಿಳಿದಿರುವ ಸಂಖ್ಯೆಯ ಮೂಲಕ ಸಂಸ್ಥೆಯನ್ನು ಸಂಪರ್ಕಿಸಿ.', report: 'ಭಾರತದಲ್ಲಿ ಹಣ ಕಳೆದುಹೋಗಿರಬಹುದು ಎಂದಾದರೆ ಬ್ಯಾಂಕ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ, 1930ಕ್ಕೆ ಕರೆಮಾಡಿ ಅಥವಾ cybercrime.gov.in ನಲ್ಲಿ ವರದಿ ಮಾಡಿ.' },
};

const trustNegation = /\b(?:never|don't|do not|cannot|can't)\s+(?:share|send|give|reveal)(?:\s+(?:your|any|an?|it|this))?\b|\bwill never ask for\b|साझा न करें|किसी को न बताएं|ಹಂಚಬೇಡಿ/iu;
const urlPattern = /https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/giu;
const entityPatterns: Array<[DetectedEntity['type'], RegExp]> = [
  ['phone', /(?<![A-Za-z0-9])(?:\+?91[\s.-]?)?[6-9](?:[\s.-]?\d){9}(?!\d)/gu],
  ['upi_id', /\b[a-z0-9][a-z0-9._-]{0,80}@(ybl|ibl|upi|paytm|okaxis|okhdfcbank|okicici|oksbi|axl|apl)\b/giu],
];

function normalize(source: string): IndexedText {
  let value = '';
  const starts: number[] = [];
  const ends: number[] = [];
  let sourceIndex = 0;
  for (const original of source) {
    const start = sourceIndex;
    const end = start + original.length;
    sourceIndex = end;
    if (/^[\u00ad\u200b\u200c\u200d\u2060\ufeff]$/u.test(original)) continue;
    const expanded = original.normalize('NFKC');
    for (const point of expanded) {
      if (/^[\u00ad\u200b\u200c\u200d\u2060\ufeff]$/u.test(point)) continue;
      const normalized = /^[\p{Zs}\p{Zl}\p{Zp}]$/u.test(point) ? ' ' : point;
      value += normalized;
      for (let unit = 0; unit < normalized.length; unit += 1) { starts.push(start); ends.push(end); }
    }
  }
  return { value, starts, ends };
}

function sourceSpan(indexed: IndexedText, start: number, end: number, sourceLength: number): [number, number] {
  if (end <= start || indexed.starts.length === 0) return [0, 0];
  return [indexed.starts[Math.min(start, indexed.starts.length - 1)] ?? 0, indexed.ends[Math.min(end - 1, indexed.ends.length - 1)] ?? sourceLength];
}

export function assessMessageLocally(source: string, language: Language): ScanResult {
  const indexed = normalize(source);
  const found: Indicator[] = [];
  const addIndicator = (key: string, start: number, end: number, whyFallback?: string): void => {
    const [label, why] = labels[language][key] ?? [key, whyFallback ?? 'A configured warning sign matched.'];
    found.push({ id: key, label, why, start, end });
  };

  for (const rule of rules) {
    const flags = (rule.flags ?? []).map((flag) => ({ IGNORECASE: 'i', MULTILINE: 'm', DOTALL: 's' })[flag]).filter(Boolean).join('');
    const match = new RegExp(rule.pattern, flags).exec(indexed.value);
    if (!match || (rule.key === 'credentials' && trustNegation.test(indexed.value.slice(Math.max(0, match.index - 70), Math.min(indexed.value.length, match.index + match[0].length + 70))))) continue;
    const [start, end] = sourceSpan(indexed, match.index, match.index + match[0].length, source.length);
    addIndicator(rule.key, start, end);
  }

  for (const match of indexed.value.matchAll(urlPattern)) {
    const raw = match[0].replace(/[.,!?;:)]+$/u, '');
    const candidate = raw.startsWith('www.') ? `https://${raw}` : raw;
    try {
      const parsed = new URL(candidate);
      const host = parsed.hostname.toLowerCase();
      const labelsCount = host.split('.').length;
      const tld = host.split('.').at(-1) ?? '';
      const oddHost = /^\d{1,3}(?:\.\d{1,3}){3}$/u.test(host) || host === 'localhost' || host.endsWith('.local') || host.startsWith('xn--') || riskyTlds.has(tld) || labelsCount - 2 > 4 || Boolean(parsed.username) || Boolean(parsed.port && parsed.port !== '80' && parsed.port !== '443');
      const key = shorteners.has(host) ? 'short_link' : oddHost ? 'odd_host' : null;
      if (key) {
        const [start, end] = sourceSpan(indexed, match.index, match.index + raw.length, source.length);
        addIndicator(key, start, end);
      }
    } catch { /* Invalid URLs remain visible as text and produce no URL-specific signal. */ }
  }

  const entities: DetectedEntity[] = [];
  const allEntityPatterns: Array<[DetectedEntity['type'], RegExp]> = [['url', urlPattern], ...entityPatterns];
  for (const [type, pattern] of allEntityPatterns) {
    for (const match of indexed.value.matchAll(pattern)) {
      const raw = type === 'url' ? match[0].replace(/[.,!?;:)]+$/u, '') : match[0];
      const [start, end] = sourceSpan(indexed, match.index, match.index + raw.length, source.length);
      if (end > start) entities.push({ type, value: source.slice(start, end), start, end });
    }
  }
  entities.sort((left, right) => left.start - right.start);

  const keys = new Set(found.map((indicator) => indicator.id));
  const category = rules.filter((rule) => keys.has(rule.key)).sort((left, right) => right.priority - left.priority)[0]?.category
    ?? (keys.has('short_link') || keys.has('odd_host') ? 'phishing_link' : keys.has('credentials') ? 'credential_request' : keys.has('urgency') ? 'social_engineering' : null);
  const strongPairs = [['credentials', 'urgency'], ['credentials', 'payment_bait'], ['credentials', 'impersonation'], ['remote_access', 'urgency'], ['upi_collect', 'credentials']];
  const strong = strongPairs.some((pair) => pair.every((key) => keys.has(key))) || keys.size >= 3;
  const verdict: ScanResult['verdict'] = strong ? 'SCAM' : found.length ? 'SUSPICIOUS' : 'SAFE';
  const message = copy[language];
  const actions = found.length ? [message.action] : [];
  if (strong && ['credentials', 'payment_bait', 'impersonation', 'upi_collect'].some((key) => keys.has(key))) actions.push(message.report);
  return {
    verdict,
    risk_level: verdict === 'SCAM' ? 'high' : verdict === 'SUSPICIOUS' ? 'medium' : 'low',
    category,
    confidence: keys.size ? Math.min(0.84, 0.55 + 0.09 * Math.max(0, keys.size - 1)) : 0,
    uncertainty: strong ? message.strong : found.length ? message.uncertain : message.clear,
    indicators: found,
    entities,
    recommended_actions: actions,
    language,
    lesson_id: null,
    engine: 'rules',
    llm_status: 'not_configured',
  };
}

export function assessUrlLocally(source: string, language: Language): UrlScanResult {
  const raw = source.trim();
  const explicitHttps = raw.toLowerCase().startsWith('https://');
  const candidate = raw.toLowerCase().startsWith('www.') ? `http://${raw}` : raw.includes('://') ? raw : `https://${raw}`;
  let host: string | null = null;
  let shortLink = false;
  let rawIp = false;
  let punycode = false;
  let riskyTld = false;
  let excessiveSubdomains = false;
  let hasUserinfo = false;
  let unusualPort = false;
  let lookalikeBrand = false;
  let oddHost = true;
  let valid = false;

  try {
    const parsed = new URL(candidate);
    host = parsed.hostname.replace(/\.$/u, '').toLowerCase();
    const parts = host.split('.');
    const tld = parts.at(-1) ?? '';
    rawIp = /^\d{1,3}(?:\.\d{1,3}){3}$/u.test(host) || host.startsWith('[');
    valid = ['http:', 'https:'].includes(parsed.protocol) && Boolean(host) && (host.includes('.') || host === 'localhost' || rawIp) && !/\s/u.test(candidate);
    if (valid && host) {
      shortLink = shorteners.has(host);
      excessiveSubdomains = Math.max(0, parts.length - 2) > 4;
      riskyTld = riskyTlds.has(tld);
      hasUserinfo = Boolean(parsed.username || parsed.password);
      unusualPort = Boolean(parsed.port && parsed.port !== '80' && parsed.port !== '443');
      const brandDomains = urlSignals.brand_domains as Record<string, string[]>;
      const brandHost = host;
      const foldedHost = brandHost.replace(/[-_]/gu, '');
      lookalikeBrand = Object.entries(brandDomains).some(([brand, domains]) => foldedHost.includes(brand) && !domains.some((domain) => brandHost === domain || brandHost.endsWith(`.${domain}`)));
      punycode = host.startsWith('xn--') || host.includes('.xn--');
      oddHost = rawIp || host === 'localhost' || host.endsWith('.local') || punycode || riskyTld || excessiveSubdomains || hasUserinfo || unusualPort || lookalikeBrand;
    }
  } catch { host = null; }

  const result = assessMessageLocally(raw, language);
  if (shortLink || oddHost) {
    const key = shortLink ? 'short_link' : 'odd_host';
    const [label, why] = labels[language][key] ?? [key, 'This address has a warning sign.'];
    result.indicators = [{ id: key, label, why, start: 0, end: raw.length }];
    result.verdict = 'SUSPICIOUS';
    result.risk_level = 'medium';
    result.category = 'phishing_link';
    result.confidence = 0.61;
    result.uncertainty = copy[language].uncertain;
    result.recommended_actions = [copy[language].action];
  }

  return {
    ...result,
    reputation: 'not_checked',
    https: explicitHttps,
    host,
    url_signals: { short_link: shortLink, odd_host: oddHost, raw_ip: rawIp, punycode, risky_tld: riskyTld, excessive_subdomains: excessiveSubdomains, has_userinfo: hasUserinfo, unusual_port: unusualPort, lookalike_brand: lookalikeBrand },
  };
}
