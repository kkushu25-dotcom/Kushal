import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router';
import { AuthProvider } from '../auth/AuthProvider';
import { Scanner } from './Scanner';

test('message scanner shows its size limit and privacy note', () => {
  const queryClient = new QueryClient();
  render(<AuthProvider><QueryClientProvider client={queryClient}><MemoryRouter><Scanner mode="message" /></MemoryRouter></QueryClientProvider></AuthProvider>);
  expect(screen.getByLabelText(/paste the message/i)).toBeTruthy();
  expect(screen.getByText(/never paste otps/i)).toBeTruthy();
  expect(screen.getByText('0/4,000')).toBeTruthy();
});

