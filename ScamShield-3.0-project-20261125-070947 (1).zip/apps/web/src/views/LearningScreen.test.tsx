import { fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { LearningScreen } from './LearningScreen';

test('lesson quiz explains why the safer choice helps and records tab progress', () => {
  sessionStorage.clear();
  render(<MemoryRouter><LearningScreen mode="quiz" /></MemoryRouter>);
  fireEvent.click(screen.getByRole('button', { name: /start quiz/i }));
  fireEvent.click(screen.getByRole('button', { name: /share the otp/i }));
  fireEvent.click(screen.getByRole('button', { name: /check answer/i }));
  expect(screen.getByRole('status').textContent).toMatch(/review the safer next step/i);
  fireEvent.click(screen.getByRole('button', { name: /mark lesson complete/i }));
  expect(sessionStorage.getItem('scamshield-learning-progress-v1')).toContain('account-impersonation');
});
