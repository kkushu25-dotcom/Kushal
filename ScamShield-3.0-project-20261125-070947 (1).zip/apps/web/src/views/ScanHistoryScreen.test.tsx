import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router';
import { AuthProvider } from '../auth/AuthProvider';
import { ScanHistoryScreen } from './ScanHistoryScreen';

test('guest scan history explains the metadata-only opt-in and links to sign in', async () => {
  const client = new QueryClient();
  render(<AuthProvider><QueryClientProvider client={client}><MemoryRouter><ScanHistoryScreen /></MemoryRouter></QueryClientProvider></AuthProvider>);
  expect(await screen.findByRole('heading', { name: /sign in to view saved assessments/i })).toBeTruthy();
  expect(screen.getByRole('link', { name: /sign in/i })).toBeTruthy();
  expect(screen.getByText(/only the assessment type, risk level, category, language, and time/i)).toBeTruthy();
});
