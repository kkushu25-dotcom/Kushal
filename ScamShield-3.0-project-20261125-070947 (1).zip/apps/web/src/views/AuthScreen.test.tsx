import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { vi } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router';
import { AuthProvider } from '../auth/AuthProvider';
import { ProfileScreen } from './ProfileScreen';
import { AuthScreen } from './AuthScreen';

function renderAuth(path: string): void {
  render(<AuthProvider><MemoryRouter initialEntries={[path]}><Routes><Route path="/auth/:action" element={<AuthScreen />} /></Routes></MemoryRouter></AuthProvider>);
}

test('registration validates password length and has an accessible visibility control', async () => {
  renderAuth('/auth/register');
  const password = screen.getByLabelText(/^password$/i) as HTMLInputElement;
  fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: 'person@example.com' } });
  fireEvent.change(password, { target: { value: 'short' } });
  fireEvent.click(screen.getByRole('button', { name: /show password/i }));
  expect(password.type).toBe('text');
  fireEvent.click(screen.getByRole('button', { name: /create account/i }));
  expect((await screen.findByRole('alert')).textContent).toMatch(/at least 12 characters/i);
});

test('profile provides a real sign-in entry in guest mode', async () => {
  render(<AuthProvider><MemoryRouter><ProfileScreen /></MemoryRouter></AuthProvider>);
  expect(await screen.findByRole('heading', { name: /no account is signed in/i })).toBeTruthy();
  expect(screen.getByRole('link', { name: /sign in/i })).toBeTruthy();
  expect(screen.getByRole('link', { name: /create account/i })).toBeTruthy();
});

test('password reset request uses the generic recovery response', async () => {
  const fetchMock = vi.fn().mockResolvedValue({
    ok: true,
    status: 202,
    json: async () => ({ message: 'If an account with that email exists, reset instructions will be sent.' }),
  });
  vi.stubGlobal('fetch', fetchMock);
  renderAuth('/auth/forgot-password');
  fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: 'person@example.com' } });
  fireEvent.click(screen.getByRole('button', { name: /send reset link/i }));
  expect(await screen.findByRole('status')).toBeTruthy();
  await waitFor(() => expect(fetchMock).toHaveBeenCalled());
  const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
  expect(url).toBe('/api/v1/auth/password-reset/request');
  expect(JSON.parse(String(init.body))).toEqual({ email: 'person@example.com' });
  vi.unstubAllGlobals();
});
