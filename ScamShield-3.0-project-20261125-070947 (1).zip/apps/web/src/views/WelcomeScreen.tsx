import type { JSX } from 'react';
import { Link } from 'react-router';
import { ArrowRight, EyeOff, ScanLine, ShieldCheck } from 'lucide-react';

export function WelcomeScreen(): JSX.Element {
  return <section className="surface-card welcome-card">
    <div className="welcome-mark"><ShieldCheck size={21} /></div>
    <div className="eyebrow">YOUR PERSONAL DIGITAL SAFETY ASSISTANT</div>
    <h2>Pause, check, and choose your next step.</h2>
    <p className="auth-lead">ScamShield helps you review suspicious messages and links, find practical guidance, and know where to report suspected fraud.</p>
    <ul className="welcome-points">
      <li><ScanLine size={17} /><span>Submit a message or URL for an on-demand risk assessment.</span></li>
      <li><EyeOff size={17} /><span>Guest scans are not saved, and ScamShield does not monitor messages or accounts in the background.</span></li>
      <li><ShieldCheck size={17} /><span>A result shows warning signs and uncertainty; it cannot prove something is safe or fraudulent.</span></li>
    </ul>
    <div className="welcome-actions"><Link className="button button-primary" to="/scan">Continue as guest <ArrowRight size={16} /></Link><Link className="button button-outline" to="/auth/register">Create account</Link><Link className="welcome-signin" to="/auth/login">Already have an account? Sign in</Link></div>
  </section>;
}
