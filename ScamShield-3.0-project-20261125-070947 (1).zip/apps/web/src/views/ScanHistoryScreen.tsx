import type { JSX } from 'react';
import { Link } from 'react-router';
import { useInfiniteQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, LoaderCircle, Trash2 } from 'lucide-react';
import { deleteSavedScan, listSavedScans, type SavedScan } from '@scamshield/api-client';
import { useAuth } from '../auth/AuthProvider';

export function ScanHistoryScreen(): JSX.Element {
  const { ready, session } = useAuth();
  const queryClient = useQueryClient();
  const history = useInfiniteQuery({
    queryKey: ['saved-scans', session?.user.id],
    enabled: ready && Boolean(session),
    initialPageParam: undefined as string | undefined,
    queryFn: ({ pageParam }) => listSavedScans(session!.accessToken, pageParam),
    getNextPageParam: (lastPage) => lastPage.next_cursor ?? undefined,
  });
  const remove = useMutation({
    mutationFn: (id: string) => deleteSavedScan(session!.accessToken, id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['saved-scans', session?.user.id] }),
  });

  if (!ready) return <section className="surface-card history-card" aria-busy="true"><p>Restoring your session…</p></section>;
  if (!session) return <section className="surface-card history-card">
    <div className="eyebrow">PRIVATE ACCOUNT HISTORY</div>
    <h2>Sign in to view saved assessments</h2>
    <p>Guest scans are not saved. If you opt in while signed in, history keeps only the assessment type, risk level, category, language, and time.</p>
    <Link className="button button-primary" to="/auth/login">Sign in <ArrowRight size={15} /></Link>
  </section>;

  if (history.isLoading) return <section className="surface-card history-card" aria-busy="true"><LoaderCircle className="spin" size={18} /><p>Loading your saved assessments…</p></section>;
  if (history.error) return <section className="surface-card history-card"><p className="field-error" role="alert">{history.error instanceof Error ? history.error.message : 'Could not load scan history.'}</p><button className="button button-outline" type="button" onClick={() => void history.refetch()}>Try again</button></section>;

  const scans = history.data?.pages.flatMap((page) => page.items) ?? [];
  if (scans.length === 0) return <section className="surface-card history-card">
    <div className="eyebrow">PRIVATE ACCOUNT HISTORY</div>
    <h2>No saved assessments yet</h2>
    <p>Saving is optional. Choose “Save assessment details” on a scan to keep a small summary here. Original messages, links, phone numbers, and detected entities are never included.</p>
    <Link className="button button-primary" to="/scan">Start a scan <ArrowRight size={15} /></Link>
  </section>;

  return <section className="history-list" aria-label="Saved scan assessments">
    <p className="history-privacy">Only metadata is stored. Source text and detected entities are not retained.</p>
    {scans.map((scan: SavedScan) => {
      const date = new Date(scan.created_at);
      const dateLabel = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
      return <article className="surface-card history-item" key={scan.id}>
        <div><div className="eyebrow">{scan.scan_type === 'message' ? 'MESSAGE ASSESSMENT' : 'URL ASSESSMENT'} · {scan.language.toUpperCase()}</div><h2>{scan.verdict === 'SCAM' ? 'Strong warning signs' : scan.verdict === 'SUSPICIOUS' ? 'Some warning signs' : 'No configured warning signs'}</h2><p>{scan.category ?? 'General check'} · {scan.risk_level} risk</p><time dateTime={scan.created_at}>{dateLabel}</time></div>
        <button className="history-delete" type="button" aria-label={`Delete saved assessment from ${dateLabel}`} disabled={remove.isPending} onClick={() => remove.mutate(scan.id)}><Trash2 size={16} /></button>
      </article>;
    })}
    {remove.error && <p className="field-error" role="alert">{remove.error instanceof Error ? remove.error.message : 'Could not delete this assessment.'}</p>}
    {history.hasNextPage && <button className="button button-outline history-more" type="button" disabled={history.isFetchingNextPage} onClick={() => void history.fetchNextPage()}>{history.isFetchingNextPage ? 'Loading…' : 'Load more'}</button>}
  </section>;
}
