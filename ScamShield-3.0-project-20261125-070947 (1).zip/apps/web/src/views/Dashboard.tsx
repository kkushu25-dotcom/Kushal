import { Link, useNavigate } from 'react-router';
import type { JSX } from 'react';
import { ArrowRight, QrCode, Shield, Link2, ScanText, ChevronRight, LockKeyhole, AlertTriangle, BookOpen, Users, Settings2, Sparkles } from 'lucide-react';
import { CATEGORIES } from './catalog';
import { useQuery } from '@tanstack/react-query';
import { listSavedScans } from '@scamshield/api-client';
import { useAuth } from '../auth/AuthProvider';
import { useTranslation } from 'react-i18next';

const categoryIcons = [Shield, LockKeyhole, AlertTriangle, BookOpen, Users, Settings2];
const dashboardCopy = {
  en: { kicker: 'YOUR EVERYDAY DIGITAL SAFETY', title: <>Your digital safety,<br />made simple.</>, intro: 'Pause, check the signs, and choose your next step with confidence.', start: 'Start a scan', welcome: 'New here? See how it works', private: 'Private by default · Guest scans are not saved', quick: 'Quick actions', message: 'Scan message', messageHelp: 'Check suspicious text', url: 'Check URL', urlHelp: 'Look before you click', qr: 'QR safety', qrHelp: 'Learn before scanning', emergency: 'Need help right now?', emergencyHelp: 'Take the next step if money or an account may be at risk.', explore: 'Explore ScamShield', seeAll: 'See all', recentEyebrow: 'RECENT ACTIVITY', recent: 'Recent scans', history: 'Open scan history', restoring: 'Restoring your session…', loading: 'Loading your scans…', none: 'No saved scans yet.', guest: 'Guest scans are not saved.', failed: 'Could not load recent activity.', saveHint: 'Choose whether to save assessment details when you scan.', next: 'YOUR NEXT STEP', prepared: 'Stay prepared', guidance: 'Guidance', learnNext: 'Learn to spot a fake bank message', lessonLength: 'Short lesson · about 3 minutes', emergencyNext: 'Know who to call in an emergency', official: 'Official contact information', disclaimer: 'ScamShield checks only what you submit. It does not watch your messages, accounts, or banking activity in the background.', messageCheck: 'Message check', urlCheck: 'URL check', risk: 'risk', general: 'General check' },
  hi: { kicker: 'रोज़मर्रा की डिजिटल सुरक्षा', title: <>आपकी डिजिटल सुरक्षा,<br />आसान तरीके से।</>, intro: 'रुकें, संकेत जाँचें और भरोसे के साथ अगला कदम चुनें।', start: 'स्कैन शुरू करें', welcome: 'पहली बार आए हैं? तरीका देखें', private: 'डिफ़ॉल्ट रूप से निजी · मेहमान के स्कैन सहेजे नहीं जाते', quick: 'त्वरित कार्रवाई', message: 'संदेश जाँचें', messageHelp: 'संदिग्ध टेक्स्ट जाँचें', url: 'URL जाँचें', urlHelp: 'क्लिक करने से पहले देखें', qr: 'QR सुरक्षा', qrHelp: 'स्कैन से पहले जानें', emergency: 'अभी मदद चाहिए?', emergencyHelp: 'पैसे या खाते को खतरा हो सकता है तो अगला कदम उठाएँ।', explore: 'ScamShield देखें', seeAll: 'सभी देखें', recentEyebrow: 'हाल की गतिविधि', recent: 'हाल के स्कैन', history: 'स्कैन इतिहास खोलें', restoring: 'सेशन वापस लाया जा रहा है…', loading: 'आपके स्कैन लोड हो रहे हैं…', none: 'अभी कोई स्कैन सहेजा नहीं गया।', guest: 'मेहमान के स्कैन सहेजे नहीं जाते।', failed: 'हाल की गतिविधि लोड नहीं हो सकी।', saveHint: 'स्कैन करते समय चुनें कि आकलन विवरण सहेजना है या नहीं।', next: 'आपका अगला कदम', prepared: 'तैयार रहें', guidance: 'मार्गदर्शन', learnNext: 'नकली बैंक संदेश पहचानें', lessonLength: 'छोटा पाठ · लगभग 3 मिनट', emergencyNext: 'आपातकाल में किसे कॉल करें जानें', official: 'आधिकारिक संपर्क जानकारी', disclaimer: 'ScamShield केवल आपके भेजे हुए कंटेंट की जाँच करता है। यह बैकग्राउंड में संदेशों, खातों या बैंक गतिविधि पर नज़र नहीं रखता।', messageCheck: 'संदेश जाँच', urlCheck: 'URL जाँच', risk: 'जोखिम', general: 'सामान्य जाँच' },
  kn: { kicker: 'ನಿಮ್ಮ ದೈನಂದಿನ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತೆ', title: <>ನಿಮ್ಮ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತೆ,<br />ಸರಳವಾಗಿ.</>, intro: 'ನಿಲ್ಲಿಸಿ, ಸೂಚನೆಗಳನ್ನು ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಮುಂದಿನ ಹೆಜ್ಜೆಯನ್ನು ಆತ್ಮವಿಶ್ವಾಸದಿಂದ ಆಯ್ಕೆಮಾಡಿ.', start: 'ಸ್ಕ್ಯಾನ್ ಪ್ರಾರಂಭಿಸಿ', welcome: 'ಹೊಸಬರೇ? ಹೇಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ನೋಡಿ', private: 'ಡೀಫಾಲ್ಟ್ ಆಗಿ ಖಾಸಗಿ · ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ', quick: 'ತ್ವರಿತ ಕ್ರಮಗಳು', message: 'ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ', messageHelp: 'ಅನುಮಾನಾಸ್ಪದ ಪಠ್ಯ ಪರಿಶೀಲಿಸಿ', url: 'URL ಪರಿಶೀಲಿಸಿ', urlHelp: 'ಕ್ಲಿಕ್ ಮಾಡುವ ಮೊದಲು ನೋಡಿ', qr: 'QR ಸುರಕ್ಷತೆ', qrHelp: 'ಸ್ಕ್ಯಾನ್ ಮಾಡುವ ಮೊದಲು ತಿಳಿಯಿರಿ', emergency: 'ಈಗಲೇ ಸಹಾಯ ಬೇಕೇ?', emergencyHelp: 'ಹಣ ಅಥವಾ ಖಾತೆಗೆ ಅಪಾಯವಿದ್ದರೆ ಮುಂದಿನ ಕ್ರಮ ಕೈಗೊಳ್ಳಿ.', explore: 'ScamShield ಅನ್ವೇಷಿಸಿ', seeAll: 'ಎಲ್ಲವನ್ನೂ ನೋಡಿ', recentEyebrow: 'ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ', recent: 'ಇತ್ತೀಚಿನ ಸ್ಕ್ಯಾನ್‌ಗಳು', history: 'ಸ್ಕ್ಯಾನ್ ಇತಿಹಾಸ ತೆರೆಯಿರಿ', restoring: 'ನಿಮ್ಮ ಸೆಷನ್ ಮರುಸ್ಥಾಪಿಸಲಾಗುತ್ತಿದೆ…', loading: 'ನಿಮ್ಮ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ…', none: 'ಇನ್ನೂ ಯಾವುದೇ ಸ್ಕ್ಯಾನ್ ಉಳಿಸಿಲ್ಲ.', guest: 'ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ.', failed: 'ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆಯನ್ನು ಲೋಡ್ ಮಾಡಲಾಗಲಿಲ್ಲ.', saveHint: 'ಸ್ಕ್ಯಾನ್ ಮಾಡುವಾಗ ಮೌಲ್ಯಮಾಪನ ವಿವರಗಳನ್ನು ಉಳಿಸಬೇಕೇ ಎಂದು ಆಯ್ಕೆಮಾಡಿ.', next: 'ನಿಮ್ಮ ಮುಂದಿನ ಹೆಜ್ಜೆ', prepared: 'ಸಿದ್ಧರಾಗಿರಿ', guidance: 'ಮಾರ್ಗದರ್ಶನ', learnNext: 'ನಕಲಿ ಬ್ಯಾಂಕ್ ಸಂದೇಶ ಗುರುತಿಸಿ', lessonLength: 'ಚಿಕ್ಕ ಪಾಠ · ಸುಮಾರು 3 ನಿಮಿಷ', emergencyNext: 'ತುರ್ತು ಪರಿಸ್ಥಿತಿಯಲ್ಲಿ ಯಾರಿಗೆ ಕರೆ ಮಾಡಬೇಕು ತಿಳಿಯಿರಿ', official: 'ಅಧಿಕೃತ ಸಂಪರ್ಕ ಮಾಹಿತಿ', disclaimer: 'ScamShield ನೀವು ಸಲ್ಲಿಸುವುದನ್ನು ಮಾತ್ರ ಪರಿಶೀಲಿಸುತ್ತದೆ. ಹಿನ್ನೆಲೆಯಲ್ಲೇ ನಿಮ್ಮ ಸಂದೇಶಗಳು, ಖಾತೆಗಳು ಅಥವಾ ಬ್ಯಾಂಕಿಂಗ್ ಚಟುವಟಿಕೆಯನ್ನು ಗಮನಿಸುವುದಿಲ್ಲ.', messageCheck: 'ಸಂದೇಶ ಪರಿಶೀಲನೆ', urlCheck: 'URL ಪರಿಶೀಲನೆ', risk: 'ಅಪಾಯ', general: 'ಸಾಮಾನ್ಯ ಪರಿಶೀಲನೆ' },
} as const;
const localizedCategories = {
  hi: [
    ['धोखाधड़ी जाँच', 'कार्रवाई से पहले संदेश, लिंक या QR सामग्री में चेतावनी संकेत देखें.'],
    ['डिजिटल सुरक्षा', 'खाते और गोपनीयता सेटिंग के लिए व्यावहारिक मार्गदर्शन.'],
    ['आपातकालीन सहायता', 'पैसे या खाते को खतरा हो तो अगला व्यावहारिक कदम उठाएँ.'],
    ['सीखने का केंद्र', 'छोटे पाठों से डिजिटल सुरक्षा की आदतें बनाएँ.'],
    ['परिवार की सुरक्षा', 'स्पष्ट सहमति से भरोसेमंद लोगों के साथ सुरक्षा मार्गदर्शन साझा करें.'],
    ['सेटिंग', 'अपनी पसंद और डेटा विकल्प प्रबंधित करें.'],
  ],
  kn: [
    ['ವಂಚನೆ ಪರಿಶೀಲನೆ', 'ಕ್ರಮಕ್ಕೂ ಮೊದಲು ಸಂದೇಶ, ಲಿಂಕ್ ಅಥವಾ QR ವಿಷಯದಲ್ಲಿ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳನ್ನು ನೋಡಿ.'],
    ['ಡಿಜಿಟಲ್ ರಕ್ಷಣೆ', 'ಖಾತೆ ಮತ್ತು ಗೌಪ್ಯತೆ ಸೆಟ್ಟಿಂಗ್‌ಗಳಿಗೆ ಪ್ರಾಯೋಗಿಕ ಮಾರ್ಗದರ್ಶನ.'],
    ['ತುರ್ತು ಕೇಂದ್ರ', 'ಹಣ ಅಥವಾ ಖಾತೆಗೆ ಅಪಾಯವಿದ್ದರೆ ಮುಂದಿನ ಪ್ರಾಯೋಗಿಕ ಹೆಜ್ಜೆ ಕೈಗೊಳ್ಳಿ.'],
    ['ಕಲಿಕಾ ಕೇಂದ್ರ', 'ಚಿಕ್ಕ ಪಾಠಗಳ ಮೂಲಕ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತಾ ಅಭ್ಯಾಸಗಳನ್ನು ಬೆಳೆಸಿ.'],
    ['ಕುಟುಂಬ ಸುರಕ್ಷತೆ', 'ಸ್ಪಷ್ಟ ಒಪ್ಪಿಗೆಯೊಂದಿಗೆ ನಂಬಿದವರ ಜೊತೆ ಸುರಕ್ಷತಾ ಮಾರ್ಗದರ್ಶನ ಹಂಚಿಕೊಳ್ಳಿ.'],
    ['ಸೆಟ್ಟಿಂಗ್‌ಗಳು', 'ನಿಮ್ಮ ಆದ್ಯತೆಗಳು ಮತ್ತು ಡೇಟಾ ಆಯ್ಕೆಗಳನ್ನು ನಿರ್ವಹಿಸಿ.'],
  ],
} as const;

export function Dashboard(): JSX.Element {
  const navigate = useNavigate();
  const { ready: authReady, session } = useAuth();
  const { i18n } = useTranslation();
  const language = i18n.resolvedLanguage?.startsWith('hi') ? 'hi' : i18n.resolvedLanguage?.startsWith('kn') ? 'kn' : 'en';
  const copy = dashboardCopy[language];
  const recentScans = useQuery({
    queryKey: ['saved-scans', session?.user.id, 'recent'],
    enabled: authReady && Boolean(session),
    queryFn: () => listSavedScans(session!.accessToken, undefined, 3),
  });
  const savedScans = recentScans.data?.items ?? [];
  return <div className="dashboard">
    <section className="hero-card">
      <span className="hero-kicker"><Sparkles size={13} /> {copy.kicker}</span>
      <h1>{copy.title}</h1>
      <p>{copy.intro}</p>
      <button className="button button-primary" onClick={() => navigate('/scan')}>{copy.start} <ArrowRight size={16} /></button>
      <Link className="hero-guide" to="/welcome">{copy.welcome} <ArrowRight size={13} /></Link>
      <div className="hero-glow hero-glow-orange" /><div className="hero-glow hero-glow-violet" />
      <div className="hero-orbit" aria-hidden="true"><div className="orbit-core"><Shield size={25} /></div><i /><i /><i /></div>
      <div className="hero-footnote">{copy.private}</div>
    </section>

    <section className="quick-actions" aria-label={copy.quick}>
      <button className="quick-action" onClick={() => navigate('/scan?mode=message')}><span className="quick-icon quick-icon-coral"><ScanText size={18} /></span><span><strong>{copy.message}</strong><small>{copy.messageHelp}</small></span><ChevronRight size={16} /></button>
      <button className="quick-action" onClick={() => navigate('/scan?mode=url')}><span className="quick-icon quick-icon-violet"><Link2 size={18} /></span><span><strong>{copy.url}</strong><small>{copy.urlHelp}</small></span><ChevronRight size={16} /></button>
      <button className="quick-action" onClick={() => navigate('/scam-detection/qr-code-scanner')}><span className="quick-icon quick-icon-green"><QrCode size={18} /></span><span><strong>{copy.qr}</strong><small>{copy.qrHelp}</small></span><ChevronRight size={16} /></button>
    </section>

    <button className="emergency-card" onClick={() => navigate('/emergency-centre/lost-money')}>
      <span className="emergency-symbol"><AlertTriangle size={20} /></span><span className="emergency-copy"><strong>{copy.emergency}</strong><small>{copy.emergencyHelp}</small></span><span className="emergency-arrow"><ArrowRight size={17} /></span>
    </button>

    <section className="section-block">
      <div className="section-heading"><div><div className="eyebrow">{copy.explore.toUpperCase()}</div><h2>{copy.explore}</h2></div><button className="text-button" onClick={() => navigate('/learning-centre')}>{copy.seeAll} <ArrowRight size={14} /></button></div>
      <div className="category-grid">{CATEGORIES.map((category, index) => {
        const Icon = categoryIcons[index] ?? Shield;
        const translated = language === 'en' ? null : localizedCategories[language][index];
        return <button className="category-tile" key={category.slug} onClick={() => navigate(`/${category.slug}`)}><span className="category-tile-icon"><Icon size={19} /></span><strong>{translated?.[0] ?? category.title}</strong><small>{translated?.[1] ?? category.description}</small><span className="tile-chevron"><ChevronRight size={15} /></span></button>;
      })}</div>
    </section>

    <section className="overview-grid">
      <div className="surface-card overview-card"><div className="section-heading"><div><div className="eyebrow">{copy.recentEyebrow}</div><h2>{copy.recent}</h2></div><button className="icon-button" aria-label={copy.history} onClick={() => navigate('/scam-detection/scan-history')}><ArrowRight size={16} /></button></div>{savedScans.length > 0 ? <div className="recent-scan-list">{savedScans.map((scan) => <div className="recent-scan-row" key={scan.id}><span className={`recent-scan-dot risk-${scan.risk_level}`} /><span><strong>{scan.scan_type === 'message' ? copy.messageCheck : copy.urlCheck}</strong><small>{scan.category ?? copy.general} · {scan.risk_level} {copy.risk}</small></span><time>{new Date(scan.created_at).toLocaleDateString()}</time></div>)}</div> : <div className="empty-state"><span className="empty-icon"><ScanText size={18} /></span><p>{!authReady ? copy.restoring : session && recentScans.isLoading ? copy.loading : session ? copy.none : copy.guest}</p><small>{recentScans.isError ? copy.failed : copy.saveHint}</small></div>}</div>
      <div className="surface-card overview-card"><div className="section-heading"><div><div className="eyebrow">{copy.next}</div><h2>{copy.prepared}</h2></div><span className="soft-tag">{copy.guidance}</span></div><div className="next-step-row"><span className="next-step-icon"><BookOpen size={17} /></span><span><strong>{copy.learnNext}</strong><small>{copy.lessonLength}</small></span><ChevronRight size={15} /></div><div className="next-step-row"><span className="next-step-icon next-step-icon-red"><AlertTriangle size={17} /></span><span><strong>{copy.emergencyNext}</strong><small>{copy.official}</small></span><ChevronRight size={15} /></div></div>
    </section>
    <p className="home-disclaimer">{copy.disclaimer}</p>
  </div>;
}

