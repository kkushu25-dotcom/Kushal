import { useState, type ReactNode, type JSX } from 'react';
import { Link, useLocation, useNavigate } from 'react-router';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { z } from 'zod';
import { AlertTriangle, ArrowRight, Check, CircleAlert, Info, LoaderCircle, ScanLine } from 'lucide-react';
import { ApiUnavailableError, scanMessage, scanUrl, type Indicator, type Language, type ScanResult, type UrlScanResult } from '@scamshield/api-client';
import { useAuth } from '../auth/AuthProvider';
import { assessMessageLocally, assessUrlLocally } from './localMessageScan';

type MessageForm = { message: string };
type UrlForm = { url: string };
type ScannerCopy = { privacyTitle: string; privacyDetails: string; scannerType: string; messageTab: string; urlTab: string; messageLabel: string; messagePlaceholder: string; noSecrets: string; saveHistory: string; signIn: string; guestHistory: string; urlLabel: string; urlHelp: string; messageHelp: string; checking: string; checkMessage: string; checkUrl: string; errorTitle: string; errorHelp: string; honesty: string; resultScam: string; resultSuspicious: string; resultClear: string; assessment: string; general: string; aiAssisted: string; rulesOnly: string; localRules: string; localNotice: string; urlDetails: string; host: string; httpsLabel: string; httpsPresent: string; httpsAbsent: string; reputation: string; notChecked: string; historySaved: string; strength: string; uncalibrated: string; evidence: string; references: string; link: string; phone: string; upi: string; noFindings: string; nextSteps: string; aiUnavailable: string; aiNotConfigured: string; footer: string; missingMessage: string; longMessage: string; missingUrl: string; longUrl: string; retryMessage: string; retryUrl: string };
const scannerCopy: Record<Language, ScannerCopy> = {
  en: { privacyTitle: 'Your scan is on demand.', privacyDetails: 'Submitted text is not saved by default. If you opt in while signed in, only assessment metadata is kept in your account history; the original text and detected entities are excluded. Never paste OTPs, UPI PINs, CVVs, passwords, or full card/account numbers.', scannerType: 'Scanner type', messageTab: 'Message', urlTab: 'URL', messageLabel: "Paste the message you'd like to check", messagePlaceholder: 'Paste suspicious SMS or chat text here…', noSecrets: 'Do not include passwords or banking secrets.', saveHistory: 'Save assessment details to my account history', signIn: 'Sign in', guestHistory: 'to save assessment details to your history. Guest scans are not saved.', urlLabel: 'Paste a link to inspect as text', urlHelp: 'ScamShield will not open this link.', messageHelp: 'Do not include passwords or banking secrets.', checking: 'Checking…', checkMessage: 'Check message', checkUrl: 'Check URL', errorTitle: "We couldn't complete that check.", errorHelp: 'Try again when you have a connection.', honesty: 'A scan can find warning signs, but it cannot prove a message or site is safe.', resultScam: 'Strong warning signs found', resultSuspicious: 'Some warning signs found', resultClear: 'No configured warning signs found', assessment: 'RISK ASSESSMENT', general: 'General check', aiAssisted: 'AI assisted', rulesOnly: 'Rules only', localRules: 'Offline local rules (reduced coverage)', localNotice: 'The scan service was unavailable. This on-device check uses a reduced ruleset and has no server or reputation analysis.', urlDetails: 'URL details', host: 'Host', httpsLabel: 'HTTPS', httpsPresent: 'Present', httpsAbsent: 'Not detected', reputation: 'Reputation', notChecked: 'Not checked', historySaved: 'Assessment details saved to your account history. Original text was not stored.', strength: 'Rule match strength', uncalibrated: 'This score is not statistically calibrated.', evidence: 'What stood out', references: 'References found in the text', link: 'Link', phone: 'Phone number', upi: 'UPI ID', noFindings: 'No configured warning signs matched. This does not prove the content is safe.', nextSteps: 'What you can do', aiUnavailable: 'AI analysis unavailable. This result uses the rules-based check only.', aiNotConfigured: 'Optional AI analysis is not configured. This result uses the rules-based check only.', footer: 'ScamShield provides a risk assessment, not proof of fraud or safety. HTTPS does not prove a website is legitimate.', missingMessage: 'Paste a message to check.', longMessage: 'Messages must be 4,000 characters or fewer.', missingUrl: 'Paste a link to check.', longUrl: 'Links must be 2,048 characters or fewer.', retryMessage: 'Check the message and try again.', retryUrl: 'Check the link and try again.' },
  hi: { privacyTitle: 'स्कैन आप चुनकर करते हैं।', privacyDetails: 'भेजा गया टेक्स्ट डिफ़ॉल्ट रूप से सहेजा नहीं जाता। साइन इन करके अनुमति देने पर केवल आकलन का मेटाडेटा इतिहास में रखा जाता है; मूल टेक्स्ट और पहचाने गए विवरण नहीं। OTP, UPI PIN, CVV, पासवर्ड या पूरे कार्ड/खाता नंबर कभी न डालें।', scannerType: 'जाँच का प्रकार', messageTab: 'संदेश', urlTab: 'URL', messageLabel: 'जाँचने के लिए संदेश डालें', messagePlaceholder: 'संदिग्ध SMS या चैट टेक्स्ट यहाँ डालें…', noSecrets: 'पासवर्ड या बैंकिंग की गोपनीय जानकारी न डालें।', saveHistory: 'आकलन का विवरण मेरे खाते के इतिहास में सहेजें', signIn: 'साइन इन करें', guestHistory: 'ताकि आकलन विवरण इतिहास में सहेज सकें। मेहमान के स्कैन सहेजे नहीं जाते।', urlLabel: 'टेक्स्ट के रूप में जाँचने के लिए लिंक डालें', urlHelp: 'ScamShield यह लिंक नहीं खोलेगा।', messageHelp: 'पासवर्ड या बैंकिंग की गोपनीय जानकारी न डालें।', checking: 'जाँच हो रही है…', checkMessage: 'संदेश जाँचें', checkUrl: 'URL जाँचें', errorTitle: 'जाँच पूरी नहीं हो सकी।', errorHelp: 'कनेक्शन मिलने पर फिर से कोशिश करें।', honesty: 'स्कैन चेतावनी संकेत ढूँढ़ सकता है, लेकिन संदेश या साइट की सुरक्षा साबित नहीं कर सकता।', resultScam: 'मजबूत चेतावनी संकेत मिले', resultSuspicious: 'कुछ चेतावनी संकेत मिले', resultClear: 'कॉन्फ़िगर किए गए चेतावनी संकेत नहीं मिले', assessment: 'जोखिम आकलन', general: 'सामान्य जाँच', aiAssisted: 'AI की सहायता से', rulesOnly: 'केवल नियम', localRules: 'ऑफ़लाइन स्थानीय नियम (सीमित जाँच)', localNotice: 'स्कैन सेवा उपलब्ध नहीं थी। यह डिवाइस की सीमित जाँच है; इसमें सर्वर या प्रतिष्ठा विश्लेषण शामिल नहीं है।', urlDetails: 'URL विवरण', host: 'होस्ट', httpsLabel: 'HTTPS', httpsPresent: 'उपलब्ध', httpsAbsent: 'नहीं मिला', reputation: 'प्रतिष्ठा', notChecked: 'जाँच नहीं हुई', historySaved: 'आकलन विवरण खाते के इतिहास में सहेजा गया। मूल टेक्स्ट सहेजा नहीं गया।', strength: 'नियम मिलान शक्ति', uncalibrated: 'यह स्कोर सांख्यिकीय रूप से कैलिब्रेट नहीं किया गया है।', evidence: 'ध्यान देने योग्य संकेत', references: 'टेक्स्ट में मिले संदर्भ', link: 'लिंक', phone: 'फ़ोन नंबर', upi: 'UPI ID', noFindings: 'कॉन्फ़िगर किए गए चेतावनी संकेत नहीं मिले। इससे सामग्री सुरक्षित साबित नहीं होती।', nextSteps: 'आप क्या कर सकते हैं', aiUnavailable: 'AI विश्लेषण उपलब्ध नहीं है। यह परिणाम केवल नियम-आधारित जाँच का है।', aiNotConfigured: 'वैकल्पिक AI विश्लेषण सेट नहीं है। यह परिणाम केवल नियम-आधारित जाँच का है।', footer: 'ScamShield जोखिम का आकलन देता है, धोखाधड़ी या सुरक्षा का प्रमाण नहीं। HTTPS से वेबसाइट की वैधता साबित नहीं होती।', missingMessage: 'जाँचने के लिए संदेश डालें।', longMessage: 'संदेश 4,000 अक्षरों या उससे कम का होना चाहिए।', missingUrl: 'जाँचने के लिए लिंक डालें।', longUrl: 'लिंक 2,048 अक्षरों या उससे कम का होना चाहिए।', retryMessage: 'संदेश जाँचें और फिर कोशिश करें।', retryUrl: 'लिंक जाँचें और फिर कोशिश करें।' },
  kn: { privacyTitle: 'ನಿಮ್ಮ ಆಯ್ಕೆಯ ಮೇರೆಗೆ ಮಾತ್ರ ಸ್ಕ್ಯಾನ್ ನಡೆಯುತ್ತದೆ.', privacyDetails: 'ಕಳುಹಿಸಿದ ಪಠ್ಯವನ್ನು ಡೀಫಾಲ್ಟ್ ಆಗಿ ಉಳಿಸುವುದಿಲ್ಲ. ಸೈನ್ ಇನ್ ಮಾಡಿ ಅನುಮತಿಸಿದರೆ, ಮೌಲ್ಯಮಾಪನದ ಮೆಟಾಡೇಟಾ ಮಾತ್ರ ಖಾತೆ ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಯುತ್ತದೆ; ಮೂಲ ಪಠ್ಯ ಮತ್ತು ಪತ್ತೆಯಾದ ವಿವರಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ. OTP, UPI PIN, CVV, ಪಾಸ್‌ವರ್ಡ್ ಅಥವಾ ಪೂರ್ಣ ಕಾರ್ಡ್/ಖಾತೆ ಸಂಖ್ಯೆಯನ್ನು ಅಂಟಿಸಬೇಡಿ.', scannerType: 'ಸ್ಕ್ಯಾನ್ ವಿಧ', messageTab: 'ಸಂದೇಶ', urlTab: 'URL', messageLabel: 'ಪರಿಶೀಲಿಸಬೇಕಾದ ಸಂದೇಶ ಅಂಟಿಸಿ', messagePlaceholder: 'ಅನುಮಾನಾಸ್ಪದ SMS ಅಥವಾ ಚಾಟ್ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಅಂಟಿಸಿ…', noSecrets: 'ಪಾಸ್‌ವರ್ಡ್ ಅಥವಾ ಬ್ಯಾಂಕಿಂಗ್ ರಹಸ್ಯಗಳನ್ನು ಸೇರಿಸಬೇಡಿ.', saveHistory: 'ಮೌಲ್ಯಮಾಪನ ವಿವರಗಳನ್ನು ನನ್ನ ಖಾತೆ ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಸಿ', signIn: 'ಸೈನ್ ಇನ್', guestHistory: 'ಮೌಲ್ಯಮಾಪನ ವಿವರಗಳನ್ನು ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಸಲು. ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ.', urlLabel: 'ಪಠ್ಯವಾಗಿ ಪರಿಶೀಲಿಸಲು ಲಿಂಕ್ ಅಂಟಿಸಿ', urlHelp: 'ScamShield ಈ ಲಿಂಕ್ ತೆರೆಯುವುದಿಲ್ಲ.', messageHelp: 'ಪಾಸ್‌ವರ್ಡ್ ಅಥವಾ ಬ್ಯಾಂಕಿಂಗ್ ರಹಸ್ಯಗಳನ್ನು ಸೇರಿಸಬೇಡಿ.', checking: 'ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ…', checkMessage: 'ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ', checkUrl: 'URL ಪರಿಶೀಲಿಸಿ', errorTitle: 'ಪರಿಶೀಲನೆ ಪೂರ್ಣಗೊಳ್ಳಲಿಲ್ಲ.', errorHelp: 'ಸಂಪರ್ಕ ಬಂದಾಗ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.', honesty: 'ಸ್ಕ್ಯಾನ್ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳನ್ನು ಕಂಡುಹಿಡಿಯಬಹುದು, ಆದರೆ ಸಂದೇಶ ಅಥವಾ ತಾಣ ಸುರಕ್ಷಿತವೆಂದು ಸಾಬೀತುಪಡಿಸುವುದಿಲ್ಲ.', resultScam: 'ಬಲವಾದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultSuspicious: 'ಕೆಲವು ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultClear: 'ಕಾನ್ಫಿಗರ್ ಮಾಡಿದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ', assessment: 'ಅಪಾಯ ಮೌಲ್ಯಮಾಪನ', general: 'ಸಾಮಾನ್ಯ ಪರಿಶೀಲನೆ', aiAssisted: 'AI ನೆರವಿನೊಂದಿಗೆ', rulesOnly: 'ನಿಯಮಗಳು ಮಾತ್ರ', localRules: 'ಆಫ್‌ಲೈನ್ ಸ್ಥಳೀಯ ನಿಯಮಗಳು (ಸೀಮಿತ ವ್ಯಾಪ್ತಿ)', localNotice: 'ಸ್ಕ್ಯಾನ್ ಸೇವೆ ಲಭ್ಯವಿರಲಿಲ್ಲ. ಈ ಸಾಧನದ ಸೀಮಿತ ಪರಿಶೀಲನೆಯಲ್ಲಿ ಸರ್ವರ್ ಅಥವಾ ಖ್ಯಾತಿ ವಿಶ್ಲೇಷಣೆ ಇಲ್ಲ.', urlDetails: 'URL ವಿವರಗಳು', host: 'ಹೋಸ್ಟ್', httpsLabel: 'HTTPS', httpsPresent: 'ಇದೆ', httpsAbsent: 'ಕಂಡುಬಂದಿಲ್ಲ', reputation: 'ಖ್ಯಾತಿ', notChecked: 'ಪರಿಶೀಲಿಸಲಾಗಿಲ್ಲ', historySaved: 'ಮೌಲ್ಯಮಾಪನ ವಿವರಗಳನ್ನು ಖಾತೆ ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಸಲಾಗಿದೆ. ಮೂಲ ಪಠ್ಯ ಉಳಿಸಿಲ್ಲ.', strength: 'ನಿಯಮ ಹೊಂದಾಣಿಕೆಯ ಬಲ', uncalibrated: 'ಈ ಅಂಕವನ್ನು ಸಂಖ್ಯಾಶಾಸ್ತ್ರೀಯವಾಗಿ ಕ್ಯಾಲಿಬ್ರೇಟ್ ಮಾಡಿಲ್ಲ.', evidence: 'ಗಮನ ಸೆಳೆದ ಅಂಶಗಳು', references: 'ಪಠ್ಯದಲ್ಲಿ ಕಂಡ ಉಲ್ಲೇಖಗಳು', link: 'ಲಿಂಕ್', phone: 'ಫೋನ್ ಸಂಖ್ಯೆ', upi: 'UPI ID', noFindings: 'ಕಾನ್ಫಿಗರ್ ಮಾಡಿದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಹೊಂದಿಕೆಯಾಗಲಿಲ್ಲ. ಇದರಿಂದ ವಿಷಯ ಸುರಕ್ಷಿತವೆಂದು ಸಾಬೀತಾಗುವುದಿಲ್ಲ.', nextSteps: 'ನೀವು ಏನು ಮಾಡಬಹುದು', aiUnavailable: 'AI ವಿಶ್ಲೇಷಣೆ ಲಭ್ಯವಿಲ್ಲ. ಈ ಫಲಿತಾಂಶ ನಿಯಮ ಆಧಾರಿತ ಪರಿಶೀಲನೆ ಮಾತ್ರ.', aiNotConfigured: 'ಐಚ್ಛಿಕ AI ವಿಶ್ಲೇಷಣೆ ಹೊಂದಿಸಿಲ್ಲ. ಈ ಫಲಿತಾಂಶ ನಿಯಮ ಆಧಾರಿತ ಪರಿಶೀಲನೆ ಮಾತ್ರ.', footer: 'ScamShield ಅಪಾಯ ಮೌಲ್ಯಮಾಪನ ನೀಡುತ್ತದೆ; ವಂಚನೆ ಅಥವಾ ಸುರಕ್ಷತೆಗೆ ಪುರಾವೆಯಲ್ಲ. HTTPS ಇದ್ದರೆ ವೆಬ್‌ಸೈಟ್ ನಿಜವೆಂದು ಸಾಬೀತಾಗುವುದಿಲ್ಲ.', missingMessage: 'ಪರಿಶೀಲಿಸಲು ಸಂದೇಶ ಅಂಟಿಸಿ.', longMessage: 'ಸಂದೇಶವು 4,000 ಅಕ್ಷರಗಳು ಅಥವಾ ಕಡಿಮೆ ಇರಬೇಕು.', missingUrl: 'ಪರಿಶೀಲಿಸಲು ಲಿಂಕ್ ಅಂಟಿಸಿ.', longUrl: 'ಲಿಂಕ್ 2,048 ಅಕ್ಷರಗಳು ಅಥವಾ ಕಡಿಮೆ ಇರಬೇಕು.', retryMessage: 'ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.', retryUrl: 'ಲಿಂಕ್ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.' },
};

export function Scanner({ mode: forcedMode }: { mode?: 'message' | 'url' }): JSX.Element {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { ready: authReady, session } = useAuth();
  const { i18n } = useTranslation();
  const language: Language = i18n.resolvedLanguage?.startsWith('hi') ? 'hi' : i18n.resolvedLanguage?.startsWith('kn') ? 'kn' : 'en';
  const copy = scannerCopy[language];
  const mode = forcedMode ?? (new URLSearchParams(location.search).get('mode') === 'url' ? 'url' : 'message');
  const [result, setResult] = useState<ScanResult | UrlScanResult | null>(null);
  const [localOnly, setLocalOnly] = useState(false);
  const [submittedText, setSubmittedText] = useState('');
  const [saveHistory, setSaveHistory] = useState(false);
  const [savedToHistory, setSavedToHistory] = useState(false);
  const messageForm = useForm<MessageForm>({ defaultValues: { message: '' } });
  const urlForm = useForm<UrlForm>({ defaultValues: { url: '' } });
  type ScanVariables = { text: string; selectedLanguage: 'en' | 'hi' | 'kn'; saveHistory: boolean; accessToken?: string };
  const onScanSuccess = (value: ScanResult | UrlScanResult, variables: ScanVariables): void => {
    setSubmittedText(variables.text);
    setResult(value);
    setSavedToHistory(variables.saveHistory);
    if (variables.saveHistory) void queryClient.invalidateQueries({ queryKey: ['saved-scans'] });
  };
  const messageMutation = useMutation({
    mutationFn: async ({ text, selectedLanguage, accessToken, saveHistory: shouldSave }: ScanVariables) => {
      try { return await scanMessage(text, { language: selectedLanguage, accessToken, saveHistory: shouldSave }); }
      catch (error) {
        if (error instanceof ApiUnavailableError && !shouldSave) return Object.assign(assessMessageLocally(text, selectedLanguage), { localOnly: true });
        throw error;
      }
    },
    onSuccess: (value, variables) => { onScanSuccess(value, variables); setLocalOnly('localOnly' in value && value.localOnly === true); },
  });
  const urlMutation = useMutation({
    mutationFn: async ({ text, selectedLanguage, accessToken, saveHistory: shouldSave }: ScanVariables) => {
      try { return await scanUrl(text, { language: selectedLanguage, accessToken, saveHistory: shouldSave }); }
      catch (error) {
        if (error instanceof ApiUnavailableError && !shouldSave) return Object.assign(assessUrlLocally(text, selectedLanguage), { localOnly: true });
        throw error;
      }
    },
    onSuccess: (value, variables) => { onScanSuccess(value, variables); setLocalOnly('localOnly' in value && value.localOnly === true); },
  });
  const pending = messageMutation.isPending || urlMutation.isPending;
  const error = messageMutation.error ?? urlMutation.error;

  const submitMessage = messageForm.handleSubmit(({ message }) => {
    const parsed = z.object({ message: z.string().trim().min(1, copy.missingMessage).max(4000, copy.longMessage) }).safeParse({ message });
    if (!parsed.success) { messageForm.setError('message', { message: parsed.error.issues[0]?.message ?? copy.retryMessage }); return; }
    setResult(null);
    setLocalOnly(false);
    setSavedToHistory(false);
    messageMutation.mutate({ text: parsed.data.message, selectedLanguage: language, saveHistory: saveHistory && Boolean(session), accessToken: session?.accessToken });
  });
  const submitUrl = urlForm.handleSubmit(({ url }) => {
    const parsed = z.object({ url: z.string().trim().min(1, copy.missingUrl).max(2048, copy.longUrl) }).safeParse({ url });
    if (!parsed.success) { urlForm.setError('url', { message: parsed.error.issues[0]?.message ?? copy.retryUrl }); return; }
    setResult(null);
    setLocalOnly(false);
    setSavedToHistory(false);
    urlMutation.mutate({ text: parsed.data.url, selectedLanguage: language, saveHistory: saveHistory && Boolean(session), accessToken: session?.accessToken });
  });

  return <section className="scanner-page">
    <div className="privacy-note"><Info size={17} /><span><strong>{copy.privacyTitle}</strong> {copy.privacyDetails}</span></div>
    <div className="scanner-tabs" role="tablist" aria-label={copy.scannerType}><button role="tab" aria-selected={mode === 'message'} className={mode === 'message' ? 'selected' : ''} onClick={() => { navigate('/scan?mode=message', { replace: true }); setResult(null); }}>{copy.messageTab}</button><button role="tab" aria-selected={mode === 'url'} className={mode === 'url' ? 'selected' : ''} onClick={() => { navigate('/scan?mode=url', { replace: true }); setResult(null); }}>{copy.urlTab}</button></div>
    {mode === 'message' ? <form className="surface-card scan-form" onSubmit={submitMessage}>
      <label htmlFor="message-input">{copy.messageLabel}</label>
      <textarea id="message-input" maxLength={4000} placeholder={copy.messagePlaceholder} aria-describedby="message-help message-count" {...messageForm.register('message')} onChange={(event) => { messageForm.clearErrors('message'); messageForm.register('message').onChange(event); }} />
      <div className="form-meta"><small id="message-help">{copy.messageHelp}</small><small id="message-count">{messageForm.watch('message').length}/4,000</small></div>
      {messageForm.formState.errors.message && <p className="field-error" role="alert">{messageForm.formState.errors.message.message}</p>}
      {authReady && session && <label className="scan-save-toggle"><input type="checkbox" checked={saveHistory} onChange={(event) => setSaveHistory(event.target.checked)} /><span>{copy.saveHistory}</span></label>}
      {authReady && !session && <p className="scan-history-hint"><Link to="/auth/login">{copy.signIn}</Link> {copy.guestHistory}</p>}
      <button className="button button-primary submit-button" type="submit" disabled={pending}>{pending ? <><LoaderCircle className="spin" size={16} /> {copy.checking}</> : <><ScanLine size={16} /> {copy.checkMessage}</>}</button>
    </form> : <form className="surface-card scan-form" onSubmit={submitUrl}>
      <label htmlFor="url-input">{copy.urlLabel}</label>
      <input id="url-input" type="text" inputMode="url" autoComplete="off" placeholder="https://example.com" aria-describedby="url-help" {...urlForm.register('url')} onChange={(event) => { urlForm.clearErrors('url'); urlForm.register('url').onChange(event); }} />
      <div className="form-meta"><small id="url-help">{copy.urlHelp}</small><small>{urlForm.watch('url').length}/2,048</small></div>
      {urlForm.formState.errors.url && <p className="field-error" role="alert">{urlForm.formState.errors.url.message}</p>}
      {authReady && session && <label className="scan-save-toggle"><input type="checkbox" checked={saveHistory} onChange={(event) => setSaveHistory(event.target.checked)} /><span>{copy.saveHistory}</span></label>}
      {authReady && !session && <p className="scan-history-hint"><Link to="/auth/login">{copy.signIn}</Link> {copy.guestHistory}</p>}
      <button className="button button-primary submit-button" type="submit" disabled={pending}>{pending ? <><LoaderCircle className="spin" size={16} /> {copy.checking}</> : <><ScanLine size={16} /> {copy.checkUrl}</>}</button>
    </form>}
    {error && <div className="error-banner" role="alert"><CircleAlert size={18} /><div><strong>{copy.errorTitle}</strong><p>{error.message}. {copy.errorHelp}</p></div></div>}
    {result && <ScanResultCard result={result} submittedText={submittedText} savedToHistory={savedToHistory} language={language} localOnly={localOnly} />}
    {!result && !error && <div className="scan-honesty"><ShieldIcon /><p>{copy.honesty}</p></div>}
  </section>;
}

function ShieldIcon(): JSX.Element { return <span className="shield-icon-small"><Check size={15} /></span>; }

function ScanResultCard({ result, submittedText, savedToHistory, language, localOnly }: { result: ScanResult | UrlScanResult; submittedText: string; savedToHistory: boolean; language: Language; localOnly: boolean }): JSX.Element {
  const copy = scannerCopy[language];
  const style = result.verdict.toLowerCase();
  const title = result.verdict === 'SCAM' ? copy.resultScam : result.verdict === 'SUSPICIOUS' ? copy.resultSuspicious : copy.resultClear;
  return <section className={`result-card verdict-${style}`} aria-live="polite">
    <div className="verdict-topline"><span className="verdict-icon">{result.verdict === 'SAFE' ? <Check size={18} /> : <AlertTriangle size={18} />}</span><div><div className="eyebrow">{copy.assessment} · {result.risk_level.toUpperCase()}</div><h2>{title}</h2></div></div>
    <p className="result-uncertainty">{result.uncertainty}</p>
    <div className="result-meta"><span>{result.category ?? copy.general}</span><span>{localOnly ? copy.localRules : result.engine === 'rules+llm' && result.llm_status === 'available' ? copy.aiAssisted : copy.rulesOnly}</span></div>
    {localOnly && <p className="provider-note" role="status"><Info size={15} /> {copy.localNotice}</p>}
    {'host' in result && <div className="actions-block"><h3>{copy.urlDetails}</h3><p><span>{copy.host}</span><code>{result.host ?? 'Unknown'}</code></p><p><span>{copy.httpsLabel}</span><code>{result.https ? copy.httpsPresent : copy.httpsAbsent}</code></p><p><span>{copy.reputation}</span><code>{result.reputation === 'not_checked' ? copy.notChecked : result.reputation}</code></p></div>}
    {savedToHistory && <p className="profile-status" role="status">{copy.historySaved}</p>}
    <p className="result-footer">{copy.strength}: {Math.round(result.confidence * 100)}/100. {copy.uncalibrated}</p>
    {submittedText && result.indicators.length > 0 && <div className="evidence-block"><h3>{copy.evidence}</h3><blockquote>{renderHighlights(submittedText, result.indicators)}</blockquote></div>}
    {result.indicators.length > 0 && <ul className="indicator-list">{result.indicators.map((indicator) => <li key={`${indicator.id}-${indicator.start}`}><strong>{indicator.label}</strong><span>{indicator.why}</span></li>)}</ul>}
    {result.entities.length > 0 && <div className="actions-block"><h3>{copy.references}</h3>{result.entities.map((entity) => <p key={`${entity.type}-${entity.start}`}><span>{entity.type === 'url' ? copy.link : entity.type === 'phone' ? copy.phone : copy.upi}</span><code>{entity.value}</code></p>)}</div>}
    {result.indicators.length === 0 && <p className="no-findings">{copy.noFindings}</p>}
    {result.recommended_actions.length > 0 && <div className="actions-block"><h3>{copy.nextSteps}</h3>{result.recommended_actions.map((action) => <p key={action}><ArrowRight size={14} />{action}</p>)}</div>}
    {result.llm_status === 'unavailable' && <p className="provider-note"><Info size={15} /> {copy.aiUnavailable}</p>}
    {result.llm_status === 'not_configured' && <p className="provider-note"><Info size={15} /> {copy.aiNotConfigured}</p>}
    <p className="result-footer">{copy.footer}</p>
  </section>;
}

function renderHighlights(text: string, indicators: Indicator[]): ReactNode {
  const spans = indicators.map((item) => ({ start: Math.max(0, Math.min(text.length, item.start)), end: Math.max(0, Math.min(text.length, item.end)) })).filter((item) => item.end > item.start).sort((a, b) => a.start - b.start);
  if (spans.length === 0) return text;
  const parts: ReactNode[] = [];
  let cursor = 0;
  for (const span of spans) {
    if (span.start < cursor) continue;
    if (cursor < span.start) parts.push(text.slice(cursor, span.start));
    parts.push(<mark key={`${span.start}-${span.end}`}>{text.slice(span.start, span.end)}</mark>);
    cursor = span.end;
  }
  if (cursor < text.length) parts.push(text.slice(cursor));
  return parts;
}

