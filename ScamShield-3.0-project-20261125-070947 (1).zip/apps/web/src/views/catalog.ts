export type FeatureEntry = { slug: string; title: string; description: string };
export type CategoryEntry = { slug: string; title: string; description: string; features: FeatureEntry[] };

export const CATEGORIES: CategoryEntry[] = [
  { slug: 'scam-detection', title: 'Scam detection', description: 'Check a message, link, or QR payload for warning signs before acting.', features: [
    { slug: 'message-scanner', title: 'Message Scanner', description: 'Review suspicious SMS or chat text on demand.' },
    { slug: 'url-scanner', title: 'URL Scanner', description: 'Inspect a link as text without opening it.' },
    { slug: 'qr-code-scanner', title: 'QR Code Safety', description: 'Learn how to treat QR payment requests safely.' },
    { slug: 'scan-history', title: 'Scan History', description: 'Saved results appear only after you opt in.' },
  ] },
  { slug: 'digital-protection', title: 'Digital protection', description: 'Practical guidance for account and privacy settings.', features: [
    { slug: 'security-alerts', title: 'Security Alerts', description: 'Review alerts created from real scans or labeled lessons.' },
    { slug: 'privacy-centre', title: 'Privacy Centre', description: 'Understand what ScamShield does and does not inspect.' },
    { slug: 'cookie-tracker-scanner', title: 'Cookie & Tracker Guidance', description: 'Learn how to review browser privacy controls.' },
    { slug: 'secure-my-account', title: 'Secure My Account', description: 'Work through account-hardening steps.' },
  ] },
  { slug: 'emergency-centre', title: 'Emergency centre', description: 'Take the next practical step if money or account access is at risk.', features: [
    { slug: 'lost-money', title: 'I Lost Money', description: 'Contact your bank and report suspected cyber fraud.' },
    { slug: 'account-hacked', title: 'Account Hacked', description: 'Reduce further access and secure recovery details.' },
    { slug: 'report-cyber-fraud', title: 'Report Cyber Fraud', description: 'Find official Indian reporting channels.' },
    { slug: 'emergency-history', title: 'Emergency History', description: 'Saved case tracking is not available in guest mode.' },
  ] },
  { slug: 'learning-centre', title: 'Learning centre', description: 'Build habits with short, practical lessons. Learning progress is not a safety score.', features: [
    { slug: 'scam-lessons', title: 'Scam Lessons', description: 'Learn how common scam patterns work.' },
    { slug: 'interactive-quizzes', title: 'Interactive Quizzes', description: 'Check what you learned with explanations.' },
    { slug: 'scam-simulator', title: 'Scam Simulator', description: 'Practice spotting warning signs in labeled examples.' },
    { slug: 'learning-progress', title: 'My Learning Progress', description: 'Track completed lessons and quizzes.' },
  ] },
  { slug: 'family-safety', title: 'Family safety', description: 'Share safety guidance with people you trust, with clear consent.', features: [
    { slug: 'trusted-contacts', title: 'Trusted Contacts', description: 'Contact sharing requires an account and explicit consent.' },
    { slug: 'family-protection', title: 'Family Protection', description: 'Share alert metadata only, never message contents.' },
  ] },
  { slug: 'settings', title: 'Settings', description: 'Manage preferences and understand your data choices.', features: [
    { slug: 'my-profile', title: 'My Profile', description: 'Sign in or manage your account preferences.' },
    { slug: 'language', title: 'Language', description: 'Choose English, Hindi, or Kannada.' },
    { slug: 'notifications', title: 'Notifications', description: 'Notifications are off unless you enable an actual device integration.' },
    { slug: 'privacy-settings', title: 'Privacy Settings', description: 'Review consent and data-retention choices.' },
  ] },
];

