import { fireEvent, render, screen } from '@testing-library/react';
import { EmergencyChecklist } from './EmergencyChecklist';

const steps = ['Contact your bank through its official app.', 'Call 1930 and save the report acknowledgement.'];

beforeEach(() => sessionStorage.clear());

test('requires each emergency step to be acknowledged before advancing', () => {
  render(<EmergencyChecklist steps={steps} storageKey="test-loss" />);
  const next = screen.getByRole('button', { name: /next step/i }) as HTMLButtonElement;
  expect(screen.getByRole('progressbar').getAttribute('aria-valuenow')).toBe('0');
  expect(next.disabled).toBe(true);

  fireEvent.click(screen.getByRole('button', { name: /mark this step complete/i }));
  expect(next.disabled).toBe(false);
  fireEvent.click(next);
  expect(screen.getByText(steps[1] ?? '')).toBeTruthy();
  expect(screen.getByRole('progressbar').getAttribute('aria-valuenow')).toBe('1');

  fireEvent.click(screen.getByRole('button', { name: /mark this step complete/i }));
  fireEvent.click(screen.getByRole('button', { name: /finish checklist/i }));
  expect(screen.getByText(/reached the end of this checklist/i)).toBeTruthy();
});

test('saves report references only in the current browser tab', () => {
  render(<EmergencyChecklist steps={steps} storageKey="test-report" />);
  fireEvent.change(screen.getByLabelText(/bank complaint reference/i), { target: { value: 'BANK-REF-23791' } });
  fireEvent.change(screen.getByLabelText(/cybercrime acknowledgement number/i), { target: { value: 'ACK-2026-114' } });
  fireEvent.click(screen.getByRole('button', { name: /save references/i }));

  expect(screen.getByRole('status').textContent).toMatch(/not sent to ScamShield/i);
  expect(sessionStorage.getItem('scamshield-emergency-test-report')).toContain('BANK-REF-23791');
});

test('refuses OTP-like numbers in reference fields', () => {
  render(<EmergencyChecklist steps={steps} storageKey="test-secret" />);
  fireEvent.change(screen.getByLabelText(/bank complaint reference/i), { target: { value: '482917' } });
  fireEvent.click(screen.getByRole('button', { name: /save references/i }));
  expect(screen.getByRole('alert').textContent).toMatch(/do not enter an OTP/i);
  expect(sessionStorage.getItem('scamshield-emergency-test-secret')).toBeNull();
});
