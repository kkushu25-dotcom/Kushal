import { useEffect, useState, type JSX } from 'react';
import { Link, useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, LogOut, Save, Shield, Trash2, UserRound } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';
import type { Language } from '@scamshield/api-client';

type ProfileCopy = { loading: string; guestEyebrow: string; guestTitle: string; guestLead: string; signIn: string; register: string; welcome: string; guestLanguage: string; guestLanguageSaved: string; accountEyebrow: string; defaultName: string; displayName: string; preferredLanguage: string; save: string; saved: string; saveError: string; signOut: string; signOutError: string; delete: string; deleteTitle: string; deleteDescription: string; keep: string; deleteForever: string; deleteError: string; securityNote: string };
const profileCopy: Record<Language, ProfileCopy> = {
  en: { loading: 'Restoring your session…', guestEyebrow: 'GUEST MODE', guestTitle: 'No account is signed in', guestLead: 'You can scan without an account. Guest results are not saved to a server-side history.', signIn: 'Sign in', register: 'Create account', welcome: 'Read the welcome guide', guestLanguage: 'Preferred language on this device', guestLanguageSaved: 'Language preference saved on this device.', accountEyebrow: 'YOUR ACCOUNT', defaultName: 'ScamShield member', displayName: 'Display name', preferredLanguage: 'Preferred language', save: 'Save preferences', saved: 'Profile preferences saved.', saveError: 'Could not save profile changes.', signOut: 'Sign out', signOutError: 'Could not sign out. Try again.', delete: 'Delete account', deleteTitle: 'Delete your ScamShield account?', deleteDescription: 'This permanently removes your account and its sessions. Guest scans are not saved.', keep: 'Keep account', deleteForever: 'Delete permanently', deleteError: 'Could not delete the account. Try again.', securityNote: 'ScamShield does not store passwords in this browser and never asks for banking secrets.' },
  hi: { loading: 'आपका सत्र वापस लाया जा रहा है…', guestEyebrow: 'अतिथि मोड', guestTitle: 'कोई खाता साइन इन नहीं है', guestLead: 'आप बिना खाते के स्कैन कर सकते हैं। अतिथि परिणाम सर्वर इतिहास में सहेजे नहीं जाते।', signIn: 'साइन इन करें', register: 'खाता बनाएँ', welcome: 'स्वागत गाइड पढ़ें', guestLanguage: 'इस डिवाइस की पसंदीदा भाषा', guestLanguageSaved: 'भाषा की पसंद इस डिवाइस पर सहेजी गई।', accountEyebrow: 'आपका खाता', defaultName: 'ScamShield सदस्य', displayName: 'दिखाने का नाम', preferredLanguage: 'पसंदीदा भाषा', save: 'पसंद सहेजें', saved: 'प्रोफ़ाइल की पसंद सहेजी गई।', saveError: 'प्रोफ़ाइल बदलाव सहेजे नहीं जा सके।', signOut: 'साइन आउट करें', signOutError: 'साइन आउट नहीं हो सका। फिर कोशिश करें।', delete: 'खाता हटाएँ', deleteTitle: 'अपना ScamShield खाता हटाएँ?', deleteDescription: 'इससे आपका खाता और उसके सत्र स्थायी रूप से हट जाएँगे। अतिथि स्कैन सहेजे नहीं जाते।', keep: 'खाता रखें', deleteForever: 'स्थायी रूप से हटाएँ', deleteError: 'खाता हटाया नहीं जा सका। फिर कोशिश करें।', securityNote: 'ScamShield इस ब्राउज़र में पासवर्ड नहीं रखता और बैंकिंग गोपनीय जानकारी नहीं माँगता।' },
  kn: { loading: 'ನಿಮ್ಮ ಸೆಷನ್ ಮರುಸ್ಥಾಪಿಸಲಾಗುತ್ತಿದೆ…', guestEyebrow: 'ಅತಿಥಿ ಮೋಡ್', guestTitle: 'ಯಾವ ಖಾತೆಯೂ ಸೈನ್ ಇನ್ ಆಗಿಲ್ಲ', guestLead: 'ಖಾತೆಯಿಲ್ಲದೆ ಸ್ಕ್ಯಾನ್ ಮಾಡಬಹುದು. ಅತಿಥಿ ಫಲಿತಾಂಶಗಳು ಸರ್ವರ್ ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಯುವುದಿಲ್ಲ.', signIn: 'ಸೈನ್ ಇನ್', register: 'ಖಾತೆ ರಚಿಸಿ', welcome: 'ಸ್ವಾಗತ ಮಾರ್ಗದರ್ಶಿ ಓದಿ', guestLanguage: 'ಈ ಸಾಧನದ ಆದ್ಯತೆಯ ಭಾಷೆ', guestLanguageSaved: 'ಭಾಷೆಯ ಆದ್ಯತೆಯನ್ನು ಈ ಸಾಧನದಲ್ಲಿ ಉಳಿಸಲಾಗಿದೆ.', accountEyebrow: 'ನಿಮ್ಮ ಖಾತೆ', defaultName: 'ScamShield ಸದಸ್ಯ', displayName: 'ಪ್ರದರ್ಶನ ಹೆಸರು', preferredLanguage: 'ಆದ್ಯತೆಯ ಭಾಷೆ', save: 'ಆದ್ಯತೆಗಳನ್ನು ಉಳಿಸಿ', saved: 'ಪ್ರೊಫೈಲ್ ಆದ್ಯತೆಗಳನ್ನು ಉಳಿಸಲಾಗಿದೆ.', saveError: 'ಪ್ರೊಫೈಲ್ ಬದಲಾವಣೆಗಳನ್ನು ಉಳಿಸಲಾಗಲಿಲ್ಲ.', signOut: 'ಸೈನ್ ಔಟ್', signOutError: 'ಸೈನ್ ಔಟ್ ಆಗಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.', delete: 'ಖಾತೆ ಅಳಿಸಿ', deleteTitle: 'ನಿಮ್ಮ ScamShield ಖಾತೆಯನ್ನು ಅಳಿಸಬೇಕೆ?', deleteDescription: 'ಇದರಿಂದ ನಿಮ್ಮ ಖಾತೆ ಮತ್ತು ಸೆಷನ್‌ಗಳು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಲ್ಪಡುತ್ತವೆ. ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ.', keep: 'ಖಾತೆ ಉಳಿಸಿ', deleteForever: 'ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿ', deleteError: 'ಖಾತೆ ಅಳಿಸಲಾಗಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.', securityNote: 'ScamShield ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಪಾಸ್‌ವರ್ಡ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಬ್ಯಾಂಕ್ ರಹಸ್ಯ ವಿವರಗಳನ್ನು ಕೇಳುವುದಿಲ್ಲ.' },
};

function resolveLanguage(value?: string): Language {
  return value?.startsWith('hi') ? 'hi' : value?.startsWith('kn') ? 'kn' : 'en';
}

export function ProfileScreen(): JSX.Element {
  const { ready, session, logout, updateProfile, deleteAccount } = useAuth();
  const { i18n } = useTranslation();
  const navigate = useNavigate();
  const activeLanguage = resolveLanguage(i18n.resolvedLanguage);
  const copy = profileCopy[activeLanguage];
  const [displayName, setDisplayName] = useState(session?.user.display_name ?? '');
  const [language, setLanguage] = useState<Language>(session?.user.language ?? activeLanguage);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setDisplayName(session?.user.display_name ?? '');
    setLanguage(session?.user.language ?? activeLanguage);
  }, [session?.user.display_name, session?.user.language, activeLanguage]);

  function changeGuestLanguage(next: Language): void {
    setLanguage(next);
    void i18n.changeLanguage(next);
    localStorage.setItem('scamshield-language', next);
  }

  if (!ready) return <section className="surface-card profile-card" aria-busy="true"><p>{copy.loading}</p></section>;
  if (!session) return <section className="surface-card profile-card">
    <div className="profile-icon"><UserRound size={20} /></div>
    <div className="eyebrow">{copy.guestEyebrow}</div>
    <h2>{copy.guestTitle}</h2>
    <p className="auth-lead">{copy.guestLead}</p>
    <div className="profile-form"><label htmlFor="guest-language">{copy.guestLanguage}</label><select id="guest-language" value={language} onChange={(event) => changeGuestLanguage(event.target.value as Language)}><option value="en">English</option><option value="hi">हिन्दी</option><option value="kn">ಕನ್ನಡ</option></select><small role="status">{copy.guestLanguageSaved}</small></div>
    <div className="profile-actions"><Link className="button button-primary" to="/auth/login">{copy.signIn}</Link><Link className="button button-outline" to="/auth/register">{copy.register}</Link></div>
    <Link className="welcome-signin" to="/welcome">{copy.welcome}</Link>
  </section>;

  async function saveProfile(): Promise<void> {
    setBusy(true); setError(''); setStatus('');
    try {
      await updateProfile({ display_name: displayName.trim() || null, language });
      await i18n.changeLanguage(language);
      localStorage.setItem('scamshield-language', language);
      setStatus(copy.saved);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : copy.saveError);
    } finally {
      setBusy(false);
    }
  }

  async function signOut(): Promise<void> {
    setBusy(true); setError('');
    try {
      await logout();
      navigate('/', { replace: true });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : copy.signOutError);
    } finally {
      setBusy(false);
    }
  }

  async function removeAccount(): Promise<void> {
    setBusy(true); setError('');
    try {
      await deleteAccount();
      navigate('/', { replace: true });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : copy.deleteError);
    } finally {
      setBusy(false);
      setConfirmDelete(false);
    }
  }

  return <section className="surface-card profile-card">
    <div className="profile-icon"><Shield size={19} /></div>
    <div className="eyebrow">{copy.accountEyebrow}</div>
    <h2>{session.user.display_name || copy.defaultName}</h2>
    <p className="profile-email">{session.user.email}</p>
    <div className="profile-form">
      <label htmlFor="profile-name">{copy.displayName}</label>
      <input id="profile-name" maxLength={80} value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
      <label htmlFor="profile-language">{copy.preferredLanguage}</label>
      <select id="profile-language" value={language} onChange={(event) => setLanguage(event.target.value as Language)}>
        <option value="en">English</option><option value="hi">हिन्दी</option><option value="kn">ಕನ್ನಡ</option>
      </select>
      <button className="button button-primary" type="button" disabled={busy} onClick={() => void saveProfile()}><Save size={15} /> {copy.save}</button>
    </div>
    {status && <p className="profile-status" role="status">{status}</p>}
    {error && <p className="field-error" role="alert">{error}</p>}
    <div className="profile-actions"><button className="button button-outline" type="button" disabled={busy} onClick={() => void signOut()}><LogOut size={15} /> {copy.signOut}</button><button className="profile-delete" type="button" disabled={busy} onClick={() => setConfirmDelete(true)}><Trash2 size={14} /> {copy.delete}</button></div>
    {confirmDelete && <div className="delete-confirmation" role="alertdialog" aria-modal="true" aria-labelledby="delete-title" aria-describedby="delete-description">
      <AlertTriangle size={18} />
      <div><strong id="delete-title">{copy.deleteTitle}</strong><p id="delete-description">{copy.deleteDescription}</p></div>
      <div className="delete-confirmation-actions"><button className="button button-outline" type="button" autoFocus onClick={() => setConfirmDelete(false)}>{copy.keep}</button><button className="button button-danger" type="button" disabled={busy} onClick={() => void removeAccount()}>{copy.deleteForever}</button></div>
    </div>}
    <p className="profile-security-note">{copy.securityNote}</p>
  </section>;
}
