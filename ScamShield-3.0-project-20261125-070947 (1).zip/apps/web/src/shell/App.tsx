import { useEffect, useState } from 'react';
import type { JSX } from 'react';
import { useLocation, useNavigate, useRoutes } from 'react-router';
import { useTranslation } from 'react-i18next';
import { Bell, ChevronLeft, ChevronRight, Home, Languages, Moon, ScanLine, Shield, Sun, UserRound, BookOpen, AlertTriangle, Search, Settings2, Users, LockKeyhole, History, QrCode, CircleHelp } from 'lucide-react';
import { Dashboard } from '../views/Dashboard';
import { Scanner } from '../views/Scanner';
import { CATEGORIES } from '../views/catalog';
import { Feature } from '../views/Feature';
import { AuthScreen } from '../views/AuthScreen';
import { WelcomeScreen } from '../views/WelcomeScreen';

const icons = [Shield, LockKeyhole, AlertTriangle, BookOpen, Users, Settings2];
const tabs = [
  { path: '/', key: 'home', icon: Home },
  { path: '/scan', key: 'scan', icon: ScanLine },
  { path: '/learning-centre', key: 'learn', icon: BookOpen },
  { path: '/digital-protection/security-alerts', key: 'alerts', icon: Bell },
  { path: '/settings/my-profile', key: 'profile', icon: UserRound },
];

function titleFor(path: string): string {
  if (path === '/') return 'Home';
  if (path === '/welcome') return 'Welcome';
  if (path === '/scan') return 'Scan a message or link';
  const parts = path.split('/').filter(Boolean);
  if (parts.length === 1) return CATEGORIES.find((category) => category.slug === parts[0])?.title ?? 'ScamShield';
  return parts.at(-1)?.replaceAll('-', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase()) ?? 'ScamShield';
}

export function App(): JSX.Element {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, i18n } = useTranslation();
  const [menu, setMenu] = useState<'language' | 'theme' | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('scamshield-theme');
    return saved === 'light' || saved === 'dark' ? saved : window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  });
  const routes = useRoutes([
    { path: '/', element: <Dashboard /> },
    { path: '/welcome', element: <WelcomeScreen /> },
    { path: '/scan', element: <Scanner /> },
    { path: '/auth/:action', element: <AuthScreen /> },
    { path: '/:category', element: <Category /> },
    { path: '/:category/:feature', element: <Feature /> },
    { path: '*', element: <Feature notFound /> },
  ]);

  const path = location.pathname;
  const isHome = path === '/';
  const isTab = tabs.some((tab) => tab.path === path);
  const isCategory = CATEGORIES.some((category) => `/${category.slug}` === path);
  const selectedSection = isTab ? path : path.startsWith('/scan') ? '/scan' : path.startsWith('/learn') ? '/learning-centre' : '/';

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    if (!menu) return;
    const closeOnOutsideClick = (event: MouseEvent): void => {
      if (event.target instanceof Element && !event.target.closest('.menu-wrap')) setMenu(null);
    };
    document.addEventListener('mousedown', closeOnOutsideClick);
    return () => document.removeEventListener('mousedown', closeOnOutsideClick);
  }, [menu]);

  function changeTheme(next: 'dark' | 'light'): void {
    setTheme(next);
    localStorage.setItem('scamshield-theme', next);
    document.documentElement.dataset.theme = next;
    setMenu(null);
  }

  function changeLanguage(language: 'en' | 'hi' | 'kn'): void {
    void i18n.changeLanguage(language);
    localStorage.setItem('scamshield-language', language);
    setMenu(null);
  }

  return (
    <div className="app-frame" onKeyDown={(event) => { if (event.key === 'Escape') setMenu(null); }}>
      <header className="topbar">
        <div className="brand-lockup">
          {!isHome && <button className="icon-button back-button" aria-label="Go back" onClick={() => { if (isCategory) navigate('/'); else navigate(-1); }}><ChevronLeft size={19} /></button>}
          <div className="brand-mark" aria-hidden="true"><Shield size={17} /></div>
          <div><div className="brand-name">ScamShield</div><div className="brand-subtitle">Digital safety, one step at a time</div></div>
        </div>
        <div className="top-actions">
          <button className="icon-button notification-button" aria-label="Notifications" onClick={() => navigate('/digital-protection/security-alerts')}><Bell size={18} /></button>
          <div className="menu-wrap">
            <button className="icon-button" aria-label="Choose language" aria-expanded={menu === 'language'} onClick={() => setMenu(menu === 'language' ? null : 'language')}><Languages size={18} /></button>
            {menu === 'language' && <div className="dropdown" role="menu">{(['en', 'hi', 'kn'] as const).map((language) => <button role="menuitem" key={language} onClick={() => changeLanguage(language)}>{language === 'en' ? 'English' : language === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</button>)}</div>}
          </div>
          <div className="menu-wrap">
            <button className="icon-button" aria-label="Choose theme" aria-expanded={menu === 'theme'} onClick={() => setMenu(menu === 'theme' ? null : 'theme')}>{theme === 'dark' ? <Moon size={17} /> : <Sun size={17} />}</button>
            {menu === 'theme' && <div className="dropdown" role="menu"><button role="menuitem" onClick={() => changeTheme('dark')}><Moon size={15} /> Dark theme</button><button role="menuitem" onClick={() => changeTheme('light')}><Sun size={15} /> Light theme</button></div>}
          </div>
          <button className="avatar-button" aria-label="Open profile" onClick={() => navigate('/settings/my-profile')}><UserRound size={16} /></button>
        </div>
      </header>
      <main className="main-content" key={path}>
        {!isHome && <div className="screen-heading"><div className="eyebrow">{isCategory ? 'EXPLORE' : 'SCAMSHIELD'}</div><h1>{titleFor(path)}</h1></div>}
        {routes}
      </main>
      <nav className="tabbar" aria-label="Main navigation">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = selectedSection === tab.path;
          return <button key={tab.path} className={`tab-item ${active ? 'active' : ''}`} aria-current={active ? 'page' : undefined} onClick={() => navigate(tab.path)}><Icon size={19} strokeWidth={active ? 2.3 : 1.8} /><span>{t(tab.key)}</span></button>;
        })}
      </nav>
    </div>
  );
}

export function Category(): JSX.Element {
  const { category } = useParamsSafe();
  const navigate = useNavigate();
  const item = CATEGORIES.find((entry) => entry.slug === category);
  if (!item) return <Feature notFound />;
  const Icon = icons[CATEGORIES.indexOf(item)] ?? Shield;
  return <section className="category-page"><div className="category-intro"><div className="category-icon"><Icon size={20} /></div><p>{item.description}</p></div><div className="feature-list">{item.features.map((feature, index) => {
    const FeatureIcon = [Search, QrCode, History, CircleHelp, Shield, LockKeyhole, AlertTriangle, BookOpen][index % 8] ?? Shield;
    return <button className="feature-row" key={feature.slug} onClick={() => navigate(`/${item.slug}/${feature.slug}`)}><span className="feature-icon"><FeatureIcon size={18} /></span><span className="feature-copy"><strong>{feature.title}</strong><small>{feature.description}</small></span><ChevronRight size={17} className="row-chevron" /></button>;
  })}</div></section>;
}

function useParamsSafe(): { category: string | undefined } {
  const parts = useLocation().pathname.split('/').filter(Boolean);
  return { category: parts[0] };
}

