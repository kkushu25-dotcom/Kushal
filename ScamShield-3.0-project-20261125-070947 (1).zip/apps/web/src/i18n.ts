import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: { translation: { appName: 'ScamShield', subtitle: 'Your personal digital safety assistant', home: 'Home', scan: 'Scan', learn: 'Learn', alerts: 'Alerts', profile: 'Profile' } },
  hi: { translation: { appName: 'ScamShield', subtitle: 'आपका डिजिटल सुरक्षा सहायक', home: 'होम', scan: 'जाँचें', learn: 'सीखें', alerts: 'अलर्ट', profile: 'प्रोफ़ाइल' } },
  kn: { translation: { appName: 'ScamShield', subtitle: 'ನಿಮ್ಮ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತಾ ಸಹಾಯಕ', home: 'ಮುಖಪುಟ', scan: 'ಪರಿಶೀಲಿಸಿ', learn: 'ಕಲಿಯಿರಿ', alerts: 'ಎಚ್ಚರಿಕೆಗಳು', profile: 'ಪ್ರೊಫೈಲ್' } },
};

export function initializeI18n(): void {
  const saved = localStorage.getItem('scamshield-language');
  const preferred = saved === 'hi' || saved === 'kn' ? saved : 'en';
  void i18next.use(initReactI18next).init({
    resources,
    lng: preferred,
    fallbackLng: 'en',
    interpolation: { escapeValue: true },
  });
}

