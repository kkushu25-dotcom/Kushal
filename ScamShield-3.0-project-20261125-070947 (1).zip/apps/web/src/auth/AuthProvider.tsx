import { createContext, useCallback, useContext, useEffect, useRef, useState, type JSX, type ReactNode } from 'react';
import {
  deleteCurrentUser,
  getCurrentUser,
  loginWeb,
  logoutWeb,
  refreshWeb,
  registerWeb,
  updateCurrentUser,
  type AuthUser,
  type Language,
  type WebAuthResult,
} from '@scamshield/api-client';

export type AuthSession = { accessToken: string; csrfToken: string; expiresIn: number; user: AuthUser };
type AuthContextValue = {
  ready: boolean;
  session: AuthSession | null;
  login: (email: string, password: string, rememberMe: boolean) => Promise<void>;
  register: (email: string, password: string, language: Language, rememberMe: boolean) => Promise<void>;
  logout: () => Promise<void>;
  reloadUser: () => Promise<void>;
  updateProfile: (changes: { display_name?: string | null; language?: Language }) => Promise<void>;
  deleteAccount: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);
let bootstrapSession: Promise<WebAuthResult | null> | undefined;

function csrfCookie(): string {
  const prefix = 'scamshield_csrf=';
  const cookie = document.cookie.split(';').map((item) => item.trim()).find((item) => item.startsWith(prefix));
  return cookie ? decodeURIComponent(cookie.slice(prefix.length)) : '';
}

function toSession(result: WebAuthResult): AuthSession {
  return { accessToken: result.access_token, csrfToken: result.csrf_token ?? csrfCookie(), expiresIn: result.expires_in, user: result.user };
}

async function initialSession(): Promise<WebAuthResult | null> {
  if (!bootstrapSession) {
    bootstrapSession = (async () => {
      const csrf = csrfCookie();
      return csrf ? refreshWeb(csrf).catch(() => null) : null;
    })();
  }
  return bootstrapSession;
}

export function AuthProvider({ children }: { children: ReactNode }): JSX.Element {
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<AuthSession | null>(null);
  const refreshRequest = useRef<Promise<WebAuthResult> | null>(null);

  const accept = useCallback((result: WebAuthResult) => {
    bootstrapSession = Promise.resolve(result);
    setSession(toSession(result));
    setReady(true);
  }, []);

  const refresh = useCallback(async (): Promise<void> => {
    if (refreshRequest.current) {
      accept(await refreshRequest.current);
      return;
    }
    const csrf = csrfCookie() || session?.csrfToken;
    if (!csrf) throw new Error('Session refresh is unavailable. Sign in again.');
    const request = refreshWeb(csrf);
    refreshRequest.current = request;
    try {
      accept(await request);
    } finally {
      refreshRequest.current = null;
    }
  }, [accept, session?.csrfToken]);

  useEffect(() => {
    let active = true;
    void initialSession().then((result) => {
      if (!active) return;
      if (result) setSession(toSession(result));
      setReady(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!session) return;
    const refreshInMs = Math.max(30_000, (session.expiresIn - 60) * 1000);
    const timer = window.setTimeout(() => {
      void refresh().catch(() => {
        setSession(null);
        bootstrapSession = Promise.resolve(null);
      });
    }, refreshInMs);
    return () => window.clearTimeout(timer);
  }, [refresh, session]);

  const login = useCallback(async (email: string, password: string, rememberMe: boolean) => {
    accept(await loginWeb(email, password, rememberMe));
  }, [accept]);

  const register = useCallback(async (email: string, password: string, language: Language, rememberMe: boolean) => {
    accept(await registerWeb(email, password, language, rememberMe));
  }, [accept]);

  const logout = useCallback(async () => {
    if (!session) return;
    await logoutWeb(session.accessToken, csrfCookie() || session.csrfToken);
    setSession(null);
    bootstrapSession = Promise.resolve(null);
  }, [session]);

  const reloadUser = useCallback(async () => {
    if (!session) return;
    const user = await getCurrentUser(session.accessToken);
    setSession({ ...session, user });
  }, [session]);

  const updateProfile = useCallback(async (changes: { display_name?: string | null; language?: Language }) => {
    if (!session) throw new Error('Sign in to update your profile.');
    const user = await updateCurrentUser(session.accessToken, changes);
    setSession({ ...session, user });
  }, [session]);

  const deleteAccount = useCallback(async () => {
    if (!session) return;
    await deleteCurrentUser(session.accessToken, session.csrfToken);
    setSession(null);
    bootstrapSession = Promise.resolve(null);
  }, [session]);

  return <AuthContext.Provider value={{ ready, session, login, register, logout, reloadUser, updateProfile, deleteAccount }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used within AuthProvider');
  return value;
}
