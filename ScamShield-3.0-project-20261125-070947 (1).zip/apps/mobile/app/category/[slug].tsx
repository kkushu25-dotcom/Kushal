import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../../locale/LanguageProvider';
import { categoryDescription, categoryTitle, featureTitle, findMobileCategory } from '../../navigation/catalog';

const copy: Record<Language, { home: string; explore: string; notFound: string; notFoundBody: string }> = {
  en: { home: 'Home', explore: 'EXPLORE', notFound: 'Section not found', notFoundBody: 'Return Home and choose one of the available sections.' },
  hi: { home: 'होम', explore: 'देखें', notFound: 'सेक्शन नहीं मिला', notFoundBody: 'होम पर लौटें और उपलब्ध सेक्शन चुनें।' },
  kn: { home: 'ಮುಖಪುಟ', explore: 'ಅನ್ವೇಷಿಸಿ', notFound: 'ವಿಭಾಗ ಕಂಡುಬಂದಿಲ್ಲ', notFoundBody: 'ಮುಖಪುಟಕ್ಕೆ ಹಿಂತಿರುಗಿ ಲಭ್ಯವಿರುವ ವಿಭಾಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ.' },
};

export default function CategoryScreen() {
  const params = useLocalSearchParams<{ slug?: string }>();
  const router = useRouter();
  const { language } = useAppLanguage();
  const labels = copy[language];
  const category = findMobileCategory(typeof params.slug === 'string' ? params.slug : undefined);

  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Pressable accessibilityRole="button" onPress={() => router.back()} style={styles.back}><Text style={styles.link}>← {labels.home}</Text></Pressable>
    {category ? <>
      <Text style={styles.eyebrow}>{labels.explore}</Text>
      <Text style={styles.title}>{categoryTitle(category, language)}</Text>
      <Text style={styles.body}>{categoryDescription(category, language)}</Text>
      <View style={styles.list}>
        {category.features.map((feature) => <Pressable key={feature.slug} accessibilityRole="button" onPress={() => router.push({ pathname: '/feature/[slug]', params: { slug: feature.slug, category: category.slug } })} style={styles.row}>
          <View style={styles.rowCopy}><Text style={styles.rowTitle}>{featureTitle(feature, language)}</Text><Text style={styles.rowBody}>{feature.description}</Text></View>
          <Text style={styles.chevron}>›</Text>
        </Pressable>)}
      </View>
    </> : <View style={styles.card}><Text style={styles.title}>{labels.notFound}</Text><Text style={styles.body}>{labels.notFoundBody}</Text></View>}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 42, paddingBottom: 48, gap: 14 },
  back: { minHeight: 44, alignSelf: 'flex-start', justifyContent: 'center', paddingHorizontal: 3 },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  eyebrow: { color: '#ff987a', letterSpacing: 1.4, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 28, lineHeight: 35, fontWeight: '300' },
  body: { color: '#aaa49b', fontSize: 13, lineHeight: 21 },
  list: { gap: 9, marginTop: 5 },
  row: { minHeight: 76, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 15, paddingVertical: 12, borderRadius: 15, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f' },
  rowCopy: { flex: 1, gap: 4 },
  rowTitle: { color: '#f4f2ef', fontSize: 14, fontWeight: '600' },
  rowBody: { color: '#938d84', fontSize: 11, lineHeight: 17 },
  chevron: { color: '#ffae9b', fontSize: 23 },
  card: { padding: 17, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 10 },
});
