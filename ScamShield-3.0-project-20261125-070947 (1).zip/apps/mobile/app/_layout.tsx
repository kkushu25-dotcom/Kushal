import { Stack, useRootNavigationState, useRouter } from 'expo-router';
import { useEffect } from 'react';
import { StatusBar, useColorScheme } from 'react-native';
import { ShareIntentProvider, useShareIntentContext } from 'expo-share-intent';
import { AuthProvider } from '../auth/AuthProvider';
import { LanguageProvider } from '../locale/LanguageProvider';

export default function RootLayout() {
  return <ShareIntentProvider><LanguageProvider><AuthProvider><RootStack /></AuthProvider></LanguageProvider></ShareIntentProvider>;
}

function RootStack() {
  const scheme = useColorScheme() ?? 'dark';
  const router = useRouter();
  const rootNavigationState = useRootNavigationState();
  const { hasShareIntent } = useShareIntentContext();

  useEffect(() => {
    if (hasShareIntent && rootNavigationState?.key) router.replace({ pathname: '/(tabs)/scan', params: { mode: 'shared' } });
  }, [hasShareIntent, rootNavigationState?.key, router]);

  return <><StatusBar barStyle={scheme === 'dark' ? 'light-content' : 'dark-content'} /><Stack screenOptions={{ headerShown: false }}><Stack.Screen name="(tabs)" /><Stack.Screen name="auth/reset-password" /><Stack.Screen name="security-checklist" /><Stack.Screen name="emergency" /><Stack.Screen name="category/[slug]" /><Stack.Screen name="feature/[slug]" /></Stack></>;
}

