import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import * as SecureStore from 'expo-secure-store';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../locale/LanguageProvider';

const storageKey = 'scamshield.mobile.security-checklist.v1';
const officialLinks = {
  google: 'https://myaccount.google.com/intro/security-checkup?hl=en-US',
  meta: 'https://www.meta.com/safety/topics/safety-basics/tools/security/',
};

const content: Record<Language, {
  back: string; eyebrow: string; title: string; intro: string; language: string; progress: string;
  completed: string; steps: { title: string; detail: string }[]; google: string; meta: string;
  official: string; reset: string; storageError: string; linkError: string; privacy: string;
}> = {
  en: {
    back: 'Back to Profile', eyebrow: 'ACCOUNT PROTECTION', title: 'Secure your accounts',
    intro: 'Work through these steps in the official service apps or websites. ScamShield cannot change settings or sign you out.',
    language: 'Content language', progress: 'steps complete', completed: 'Done',
    steps: [
      { title: 'Change an exposed or reused password', detail: 'Use the official service. Choose a unique password you do not use elsewhere.' },
      { title: 'Review signed-in devices', detail: 'Sign out sessions or remove devices you do not recognize in that service’s own settings.' },
      { title: 'Turn on stronger sign-in', detail: 'Enable two-step verification or a passkey when the service offers one.' },
      { title: 'Check recovery details', detail: 'Confirm the recovery email and phone belong to you and are still accessible.' },
      { title: 'Review connected apps', detail: 'Revoke access for apps or websites you do not recognize or no longer use.' },
      { title: 'Contact your bank through official channels', detail: 'If payment details may be exposed, use your bank’s official app or the number printed on your card.' },
    ],
    google: 'Open Google Security Checkup', meta: 'Open Meta account security',
    official: 'These links open official account-security guidance. ScamShield never receives your password, code, or account settings.',
    reset: 'Reset checklist', storageError: 'Secure on-device storage is unavailable. Progress will stay on this screen only.',
    linkError: 'Could not open that page. Open the official service app and find its Security settings.',
    privacy: 'Guidance only. ScamShield does not inspect your account or perform any security action for you.',
  },
  hi: {
    back: 'प्रोफ़ाइल पर वापस जाएँ', eyebrow: 'खाता सुरक्षा', title: 'अपने खाते सुरक्षित करें',
    intro: 'ये कदम संबंधित सेवा के आधिकारिक ऐप या वेबसाइट में करें। ScamShield सेटिंग नहीं बदल सकता और न ही आपको साइन आउट कर सकता है।',
    language: 'सामग्री की भाषा', progress: 'कदम पूरे', completed: 'पूरा',
    steps: [
      { title: 'उजागर या दोबारा उपयोग किया गया पासवर्ड बदलें', detail: 'आधिकारिक सेवा का उपयोग करें और हर जगह से अलग पासवर्ड चुनें।' },
      { title: 'साइन-इन डिवाइस देखें', detail: 'उस सेवा की सेटिंग में अनजान सत्रों से साइन आउट करें या डिवाइस हटाएँ।' },
      { title: 'मजबूत साइन-इन चालू करें', detail: 'उपलब्ध होने पर दो-चरणीय सत्यापन या पासकी चालू करें।' },
      { title: 'रिकवरी विवरण जाँचें', detail: 'पुष्टि करें कि रिकवरी ईमेल और फ़ोन आपके हैं और आपके उपयोग में हैं।' },
      { title: 'जुड़े हुए ऐप देखें', detail: 'अनजान या अब उपयोग न होने वाले ऐप और वेबसाइटों की पहुँच हटाएँ।' },
      { title: 'बैंक से आधिकारिक तरीके से संपर्क करें', detail: 'भुगतान विवरण उजागर हो सकते हों तो बैंक का आधिकारिक ऐप या कार्ड पर दिया नंबर इस्तेमाल करें।' },
    ],
    google: 'Google Security Checkup खोलें', meta: 'Meta खाता सुरक्षा खोलें',
    official: 'ये लिंक आधिकारिक खाता-सुरक्षा मार्गदर्शन खोलते हैं। ScamShield को आपका पासवर्ड, कोड या खाता सेटिंग नहीं मिलती।',
    reset: 'चेकलिस्ट फिर शुरू करें', storageError: 'डिवाइस का सुरक्षित भंडारण उपलब्ध नहीं है। प्रगति केवल इस स्क्रीन पर रहेगी।',
    linkError: 'पेज नहीं खुला। आधिकारिक सेवा ऐप खोलकर Security सेटिंग खोजें।',
    privacy: 'यह केवल मार्गदर्शन है। ScamShield आपके खाते की जाँच या कोई सुरक्षा कार्रवाई नहीं करता।',
  },
  kn: {
    back: 'ಪ್ರೊಫೈಲ್‌ಗೆ ಹಿಂತಿರುಗಿ', eyebrow: 'ಖಾತೆ ರಕ್ಷಣೆ', title: 'ನಿಮ್ಮ ಖಾತೆಗಳನ್ನು ಸುರಕ್ಷಿತಗೊಳಿಸಿ',
    intro: 'ಈ ಹಂತಗಳನ್ನು ಸಂಬಂಧಿತ ಅಧಿಕೃತ ಸೇವೆಯ ಆ್ಯಪ್ ಅಥವಾ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಮಾಡಿ. ScamShield ಸೆಟ್ಟಿಂಗ್ ಬದಲಾಯಿಸಲು ಅಥವಾ ನಿಮ್ಮನ್ನು ಸೈನ್ ಔಟ್ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ.',
    language: 'ವಿಷಯದ ಭಾಷೆ', progress: 'ಹಂತಗಳು ಪೂರ್ಣ', completed: 'ಪೂರ್ಣ',
    steps: [
      { title: 'ಬಹಿರಂಗವಾದ ಅಥವಾ ಮರುಬಳಕೆಯ ಗುಪ್ತಪದ ಬದಲಿಸಿ', detail: 'ಅಧಿಕೃತ ಸೇವೆಯನ್ನು ಬಳಸಿ. ಬೇರೆಡೆ ಬಳಸದ ವಿಶಿಷ್ಟ ಗುಪ್ತಪದ ಆರಿಸಿ.' },
      { title: 'ಸೈನ್-ಇನ್ ಸಾಧನಗಳನ್ನು ಪರಿಶೀಲಿಸಿ', detail: 'ಆ ಸೇವೆಯ ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಗುರುತಿಲ್ಲದ ಸತ್ರಗಳಿಂದ ಸೈನ್ ಔಟ್ ಮಾಡಿ ಅಥವಾ ಸಾಧನಗಳನ್ನು ತೆಗೆದುಹಾಕಿ.' },
      { title: 'ಬಲವಾದ ಸೈನ್-ಇನ್ ವಿಧಾನ ಸಕ್ರಿಯಗೊಳಿಸಿ', detail: 'ಲಭ್ಯವಿದ್ದರೆ ಎರಡು ಹಂತದ ಪರಿಶೀಲನೆ ಅಥವಾ ಪಾಸ್‌ಕೀ ಸಕ್ರಿಯಗೊಳಿಸಿ.' },
      { title: 'ಮರುಪಡೆಯುವ ವಿವರಗಳನ್ನು ಪರಿಶೀಲಿಸಿ', detail: 'ಮರುಪಡೆಯುವ ಇಮೇಲ್ ಮತ್ತು ಫೋನ್ ನಿಮ್ಮದೇ ಮತ್ತು ಬಳಕೆಯಲ್ಲಿವೆ ಎಂದು ಖಚಿತಪಡಿಸಿ.' },
      { title: 'ಸಂಪರ್ಕಿತ ಆ್ಯಪ್‌ಗಳನ್ನು ಪರಿಶೀಲಿಸಿ', detail: 'ಗುರುತಿಲ್ಲದ ಅಥವಾ ಇನ್ನು ಬಳಸದ ಆ್ಯಪ್‌ಗಳ ಪ್ರವೇಶವನ್ನು ರದ್ದುಗೊಳಿಸಿ.' },
      { title: 'ಅಧಿಕೃತ ಮಾರ್ಗದಲ್ಲಿ ಬ್ಯಾಂಕ್ ಸಂಪರ್ಕಿಸಿ', detail: 'ಪಾವತಿ ವಿವರಗಳು ಬಹಿರಂಗವಾಗಿರಬಹುದು ಎಂದಾದರೆ ಬ್ಯಾಂಕಿನ ಅಧಿಕೃತ ಆ್ಯಪ್ ಅಥವಾ ಕಾರ್ಡ್‌ನಲ್ಲಿರುವ ಸಂಖ್ಯೆಯನ್ನು ಬಳಸಿ.' },
    ],
    google: 'Google Security Checkup ತೆರೆಯಿರಿ', meta: 'Meta ಖಾತೆ ಸುರಕ್ಷತೆ ತೆರೆಯಿರಿ',
    official: 'ಈ ಲಿಂಕ್‌ಗಳು ಅಧಿಕೃತ ಖಾತೆ-ಸುರಕ್ಷತಾ ಮಾರ್ಗದರ್ಶನವನ್ನು ತೆರೆಯುತ್ತವೆ. ScamShield ನಿಮ್ಮ ಗುಪ್ತಪದ, ಕೋಡ್ ಅಥವಾ ಖಾತೆ ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಪಡೆಯುವುದಿಲ್ಲ.',
    reset: 'ಪಟ್ಟಿಯನ್ನು ಮರುಹೊಂದಿಸಿ', storageError: 'ಸುರಕ್ಷಿತ ಸಾಧನ ಸಂಗ್ರಹಣೆ ಲಭ್ಯವಿಲ್ಲ. ಪ್ರಗತಿ ಈ ಪರದೆಯಲ್ಲಿ ಮಾತ್ರ ಉಳಿಯುತ್ತದೆ.',
    linkError: 'ಪುಟ ತೆರೆಯಲಾಗಲಿಲ್ಲ. ಅಧಿಕೃತ ಸೇವಾ ಆ್ಯಪ್ ತೆರೆಯಿರಿ ಮತ್ತು Security ಸೆಟ್ಟಿಂಗ್ ಹುಡುಕಿ.',
    privacy: 'ಇದು ಮಾರ್ಗದರ್ಶನ ಮಾತ್ರ. ScamShield ನಿಮ್ಮ ಖಾತೆಯನ್ನು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ ಅಥವಾ ಭದ್ರತಾ ಕ್ರಮ ಕೈಗೊಳ್ಳುವುದಿಲ್ಲ.',
  },
};

function readProgress(value: string | null): number[] {
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed)
      ? [...new Set(parsed.filter((item): item is number => Number.isInteger(item) && item >= 0 && item < 6))]
      : [];
  } catch {
    return [];
  }
}

export default function SecurityChecklistScreen() {
  const router = useRouter();
  const { language, changeLanguage } = useAppLanguage();
  const [completed, setCompleted] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<'storage' | 'link' | null>(null);
  const [saving, setSaving] = useState(false);
  const writing = useRef(false);
  const labels = content[language];

  useEffect(() => {
    let mounted = true;
    void SecureStore.getItemAsync(storageKey).then((saved) => {
      if (mounted) setCompleted(readProgress(saved));
    }).catch(() => {
      if (mounted) setNotice('storage');
    }).finally(() => {
      if (mounted) setLoading(false);
    });
    return () => { mounted = false; };
  }, []);

  async function updateProgress(next: number[]): Promise<void> {
    if (writing.current) return;
    writing.current = true;
    setSaving(true);
    const prior = completed;
    setCompleted(next);
    setNotice(null);
    try {
      await SecureStore.setItemAsync(storageKey, JSON.stringify(next));
    } catch {
      setCompleted(prior);
      setNotice('storage');
    } finally {
      writing.current = false;
      setSaving(false);
    }
  }

  async function openOfficial(url: string): Promise<void> {
    setNotice(null);
    try {
      await Linking.openURL(url);
    } catch {
      setNotice('link');
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Pressable accessibilityRole="button" onPress={() => router.back()} style={styles.backButton}><Text style={styles.backText}>← {labels.back}</Text></Pressable>
    <Text style={styles.eyebrow}>{labels.eyebrow}</Text>
    <Text style={styles.title}>{labels.title}</Text>
    <Text style={styles.body}>{labels.intro}</Text>

    <Text style={styles.label}>{labels.language}</Text>
    <View style={styles.languageRow}>
      {(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.languageButton, language === code && styles.selected]}>
        <Text style={[styles.languageText, language === code && styles.selectedText]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text>
      </Pressable>)}
    </View>

    <View style={styles.card}>
      <View style={styles.progressHeader}><Text style={styles.sectionTitle}>{completed.length} / {labels.steps.length} {labels.progress}</Text>{loading && <ActivityIndicator color="#ff987a" />}</View>
      <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: labels.steps.length, now: completed.length }} style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${completed.length / labels.steps.length * 100}%` }]} />
      </View>
      {labels.steps.map((step, index) => {
        const checked = completed.includes(index);
        return <Pressable key={step.title} accessibilityRole="checkbox" accessibilityState={{ checked }} disabled={loading || saving} onPress={() => { void updateProgress(checked ? completed.filter((item) => item !== index) : [...completed, index]); }} style={styles.stepRow}>
          <View style={[styles.checkbox, checked && styles.checkboxChecked]}><Text style={styles.checkmark}>{checked ? '✓' : ''}</Text></View>
          <View style={styles.stepCopy}><Text style={styles.stepTitle}>{step.title}</Text><Text style={styles.stepDetail}>{step.detail}</Text></View>
        </Pressable>;
      })}
      <Pressable accessibilityRole="button" disabled={loading || saving || completed.length === 0} onPress={() => { void updateProgress([]); }} style={[styles.resetButton, (loading || saving || completed.length === 0) && styles.disabled]}><Text style={styles.link}>{labels.reset}</Text></Pressable>
    </View>

    <View style={styles.card}>
      <Text style={styles.sectionTitle}>{labels.official}</Text>
      <Pressable accessibilityRole="link" onPress={() => { void openOfficial(officialLinks.google); }} style={styles.linkButton}><Text style={styles.link}>{labels.google} ↗</Text></Pressable>
      <Pressable accessibilityRole="link" onPress={() => { void openOfficial(officialLinks.meta); }} style={styles.linkButton}><Text style={styles.link}>{labels.meta} ↗</Text></Pressable>
    </View>

    {!!notice && <Text accessibilityRole="alert" style={styles.error}>{notice === 'storage' ? labels.storageError : labels.linkError}</Text>}
    <Text style={styles.privacy}>{labels.privacy}</Text>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 48, paddingBottom: 48, gap: 14 },
  backButton: { minHeight: 44, justifyContent: 'center', alignSelf: 'flex-start', paddingHorizontal: 3 },
  backText: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  eyebrow: { color: '#ff987a', letterSpacing: 1.4, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 28, lineHeight: 34, fontWeight: '300' },
  body: { color: '#aaa49b', fontSize: 13, lineHeight: 21 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600' },
  languageRow: { flexDirection: 'row', gap: 8 },
  languageButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 13, borderRadius: 22, backgroundColor: '#171411' },
  languageText: { color: '#aaa49b', fontSize: 12 },
  selected: { borderWidth: 1, borderColor: '#ff987a', backgroundColor: '#32221b' },
  selectedText: { color: '#ff987a', fontWeight: '700' },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 12 },
  progressHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: '#f4f2ef', fontSize: 14, lineHeight: 20, fontWeight: '600' },
  progressTrack: { height: 5, overflow: 'hidden', borderRadius: 3, backgroundColor: '#322a24' },
  progressFill: { height: 5, backgroundColor: '#ff8060' },
  stepRow: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,.06)' },
  checkbox: { width: 21, height: 21, borderWidth: 1, borderColor: '#aaa49b', borderRadius: 5, alignItems: 'center', justifyContent: 'center' },
  checkboxChecked: { backgroundColor: '#ff8060', borderColor: '#ff8060' },
  checkmark: { color: '#23120d', fontSize: 13, fontWeight: '900' },
  stepCopy: { flex: 1, gap: 4 },
  stepTitle: { color: '#e9e3dc', fontSize: 13, lineHeight: 18, fontWeight: '600' },
  stepDetail: { color: '#aaa49b', fontSize: 11, lineHeight: 17 },
  resetButton: { minHeight: 44, alignSelf: 'flex-start', justifyContent: 'center', paddingHorizontal: 4 },
  disabled: { opacity: 0.45 },
  linkButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 13, borderRadius: 22, borderWidth: 1, borderColor: 'rgba(255,174,155,.32)' },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  error: { color: '#ff9ba5', fontSize: 12, lineHeight: 18 },
  privacy: { color: '#817b73', fontSize: 10, lineHeight: 16 },
});
