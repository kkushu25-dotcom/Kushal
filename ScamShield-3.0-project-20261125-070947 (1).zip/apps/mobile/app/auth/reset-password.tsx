import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useMobileAuth } from '../../auth/AuthProvider';

export default function ResetPasswordScreen() {
  const params = useLocalSearchParams<{ token?: string }>();
  const router = useRouter();
  const { confirmPasswordReset } = useMobileAuth();
  const [token] = useState(() => typeof params.token === 'string' ? params.token : '');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const [complete, setComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (params.token) router.replace('/auth/reset-password');
  }, [params.token, router]);

  async function submit(): Promise<void> {
    if (!token) {
      setError('This reset link is missing its token. Request a new link from Profile.');
      return;
    }
    if (password.length < 12 || password.length > 128) {
      setError('Use a password between 12 and 128 characters.');
      return;
    }
    if (password !== confirmation) {
      setError('The passwords do not match.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await confirmPasswordReset(token, password);
      setPassword('');
      setConfirmation('');
      setComplete(true);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'This reset link may have expired. Request a new one.');
    } finally {
      setBusy(false);
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.eyebrow}>ACCOUNT SUPPORT</Text>
    <Text style={styles.title}>Reset your password</Text>
    {complete ? <View style={styles.card}>
      <Text style={styles.body}>Your password has been updated. Sign in with your new password. Other sessions have been signed out.</Text>
      <Pressable accessibilityRole="button" onPress={() => router.replace('/(tabs)/profile')} style={styles.button}><Text style={styles.buttonText}>Return to Profile</Text></Pressable>
    </View> : <View style={styles.card}>
      <Text style={styles.body}>Choose a unique password with at least 12 characters. This one-time link expires and works once.</Text>
      {!token && <Text style={styles.error}>This reset link is missing its token. Request a new link from Profile.</Text>}
      <Text style={styles.label}>New password</Text>
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder="At least 12 characters"
        placeholderTextColor="#77716a"
        secureTextEntry
        autoCapitalize="none"
        autoComplete="new-password"
        textContentType="newPassword"
        maxLength={128}
        accessibilityLabel="New password"
        style={styles.input}
      />
      <Text style={styles.label}>Confirm new password</Text>
      <TextInput
        value={confirmation}
        onChangeText={setConfirmation}
        placeholder="Enter the new password again"
        placeholderTextColor="#77716a"
        secureTextEntry
        autoCapitalize="none"
        autoComplete="new-password"
        textContentType="newPassword"
        maxLength={128}
        accessibilityLabel="Confirm new password"
        style={styles.input}
      />
      {error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
      <Pressable accessibilityRole="button" disabled={busy || !token} onPress={() => { void submit(); }} style={[styles.button, (busy || !token) && styles.disabled]}>
        {busy ? <ActivityIndicator color="#23120d" /> : <Text style={styles.buttonText}>Save new password</Text>}
      </Pressable>
      <Pressable accessibilityRole="button" onPress={() => router.replace('/(tabs)/profile')} style={styles.linkButton}><Text style={styles.link}>Return to Profile</Text></Pressable>
    </View>}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { flexGrow: 1, justifyContent: 'center', padding: 22, gap: 14 },
  eyebrow: { color: '#ff987a', letterSpacing: 1.6, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 30, fontWeight: '300' },
  card: { padding: 17, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 13 },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600' },
  input: { minHeight: 48, paddingHorizontal: 13, borderRadius: 13, borderWidth: 1, borderColor: 'rgba(255,255,255,.13)', backgroundColor: '#0d0b09', color: '#f4f2ef', fontSize: 14 },
  button: { minHeight: 48, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 17, borderRadius: 26, backgroundColor: '#ff8060', marginTop: 4 },
  buttonText: { color: '#23120d', fontSize: 12, fontWeight: '700' },
  disabled: { opacity: 0.55 },
  error: { color: '#ff9ba5', lineHeight: 19, fontSize: 12 },
  linkButton: { minHeight: 42, justifyContent: 'center', alignItems: 'center' },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
});
