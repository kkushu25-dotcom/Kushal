import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Linking, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as SecureStore from 'expo-secure-store';
import type { Language } from '@scamshield/api-client/types';
import emergency from '../../../packages/content/emergency-resources.json';
import { useAppLanguage } from '../locale/LanguageProvider';

type Topic = 'money' | 'account';
type References = { bank: string; cybercrime: string };
type StoredProgress = { completed: number[]; references: References };
const referenceStoreKey = (topic: Topic) => `scamshield.mobile.emergency.v1.${topic}`;
const emptyReferences: References = { bank: '', cybercrime: '' };

const copy: Record<Language, {
  eyebrow: string; title: string; intro: string; language: string; money: string; account: string;
  urgent: string; portal: string; disclaimer: string; step: string; completed: string;
  markDone: string; markUndone: string; previous: string; next: string; finish: string;
  finished: string; review: string; reset: string; references: string; localOnly: string;
  bankReference: string; cyberReference: string; referencePlaceholder: string; saveReferences: string;
  saved: string; secretWarning: string; storageError: string; verified: string;
}> = {
  en: {
    eyebrow: 'OFFLINE EMERGENCY GUIDANCE', title: 'Take one step at a time',
    intro: 'Choose what happened. This checklist is guidance, not a bank or police service.', language: 'Content language',
    money: 'Money may be lost', account: 'Account may be hacked', urgent: 'Call 1930', portal: 'Open official reporting portal',
    disclaimer: emergency.disclaimer.en, step: 'Step', completed: 'completed', markDone: 'Mark this step complete',
    markUndone: 'Mark this step incomplete', previous: 'Previous', next: 'Next step', finish: 'Finish checklist',
    finished: 'You reached the end of this checklist. Follow up with your bank or the official reporting portal as needed.',
    review: 'Review steps', reset: 'Start over', references: 'Keep report references',
    localOnly: 'Optional. Saved only on this device; never sent to ScamShield.', bankReference: 'Bank complaint reference',
    cyberReference: 'Cybercrime acknowledgement number', referencePlaceholder: 'Reference only', saveReferences: 'Save references',
    saved: 'References saved on this device.',
    secretWarning: 'Enter only a complaint or acknowledgement reference. Do not enter an OTP, UPI PIN, CVV, password, or account/card number.',
    storageError: 'Secure on-device storage is unavailable. Your checklist still works until you leave this screen.',
    verified: `Official contact and portal checked ${emergency.lastVerified}.`,
  },
  hi: {
    eyebrow: 'ऑफ़लाइन आपातकालीन मार्गदर्शन', title: 'एक समय में एक कदम लें',
    intro: 'क्या हुआ चुनें। यह चेकलिस्ट मार्गदर्शन है, बैंक या पुलिस सेवा नहीं।', language: 'सामग्री की भाषा',
    money: 'पैसे का नुकसान हो सकता है', account: 'खाता हैक हो सकता है', urgent: '1930 पर कॉल करें', portal: 'आधिकारिक रिपोर्टिंग पोर्टल खोलें',
    disclaimer: emergency.disclaimer.hi, step: 'कदम', completed: 'पूरे', markDone: 'इस कदम को पूरा चिह्नित करें',
    markUndone: 'इस कदम को अधूरा चिह्नित करें', previous: 'पिछला', next: 'अगला कदम', finish: 'चेकलिस्ट पूरी करें',
    finished: 'आप इस चेकलिस्ट के अंत तक पहुँच गए हैं। ज़रूरत के अनुसार बैंक या आधिकारिक रिपोर्टिंग पोर्टल से संपर्क करें।',
    review: 'कदम फिर देखें', reset: 'फिर से शुरू करें', references: 'रिपोर्ट संदर्भ सहेजें',
    localOnly: 'वैकल्पिक। केवल इस डिवाइस पर सहेजा जाता है; ScamShield को नहीं भेजा जाता।', bankReference: 'बैंक शिकायत संदर्भ',
    cyberReference: 'साइबर अपराध पावती संख्या', referencePlaceholder: 'केवल संदर्भ संख्या', saveReferences: 'संदर्भ सहेजें',
    saved: 'संदर्भ इस डिवाइस पर सहेजे गए।',
    secretWarning: 'केवल शिकायत या पावती संदर्भ दर्ज करें। OTP, UPI PIN, CVV, पासवर्ड या खाता/कार्ड नंबर न डालें।',
    storageError: 'डिवाइस का सुरक्षित भंडारण उपलब्ध नहीं है। स्क्रीन छोड़ने तक चेकलिस्ट काम करती रहेगी।',
    verified: `आधिकारिक संपर्क और पोर्टल की जाँच ${emergency.lastVerified} को हुई।`,
  },
  kn: {
    eyebrow: 'ಆಫ್‌ಲೈನ್ ತುರ್ತು ಮಾರ್ಗದರ್ಶನ', title: 'ಒಂದೊಂದು ಹಂತವಾಗಿ ಮುಂದುವರಿಯಿರಿ',
    intro: 'ಏನಾಯಿತು ಎಂದು ಆಯ್ಕೆಮಾಡಿ. ಇದು ಮಾರ್ಗದರ್ಶನ ಮಾತ್ರ; ಬ್ಯಾಂಕ್ ಅಥವಾ ಪೊಲೀಸ್ ಸೇವೆಯಲ್ಲ.', language: 'ವಿಷಯದ ಭಾಷೆ',
    money: 'ಹಣ ಕಳೆದುಹೋಗಿರಬಹುದು', account: 'ಖಾತೆ ಹ್ಯಾಕ್ ಆಗಿರಬಹುದು', urgent: '1930ಕ್ಕೆ ಕರೆ ಮಾಡಿ', portal: 'ಅಧಿಕೃತ ವರದಿ ಪೋರ್ಟಲ್ ತೆರೆಯಿರಿ',
    disclaimer: emergency.disclaimer.kn, step: 'ಹಂತ', completed: 'ಪೂರ್ಣ', markDone: 'ಈ ಹಂತವನ್ನು ಪೂರ್ಣವೆಂದು ಗುರುತಿಸಿ',
    markUndone: 'ಈ ಹಂತವನ್ನು ಅಪೂರ್ಣವೆಂದು ಗುರುತಿಸಿ', previous: 'ಹಿಂದಿನದು', next: 'ಮುಂದಿನ ಹಂತ', finish: 'ಪಟ್ಟಿಯನ್ನು ಮುಗಿಸಿ',
    finished: 'ಈ ಪಟ್ಟಿಯ ಕೊನೆಯವರೆಗೆ ಬಂದಿದ್ದೀರಿ. ಅಗತ್ಯವಿದ್ದರೆ ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಧಿಕೃತ ವರದಿ ಪೋರ್ಟಲ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ.',
    review: 'ಹಂತಗಳನ್ನು ಪರಿಶೀಲಿಸಿ', reset: 'ಮತ್ತೆ ಪ್ರಾರಂಭಿಸಿ', references: 'ವರದಿ ಉಲ್ಲೇಖಗಳನ್ನು ಉಳಿಸಿ',
    localOnly: 'ಐಚ್ಛಿಕ. ಈ ಸಾಧನದಲ್ಲಿ ಮಾತ್ರ ಉಳಿಸಲಾಗುತ್ತದೆ; ScamShield ಗೆ ಕಳುಹಿಸುವುದಿಲ್ಲ.', bankReference: 'ಬ್ಯಾಂಕ್ ದೂರು ಉಲ್ಲೇಖ',
    cyberReference: 'ಸೈಬರ್ ಅಪರಾಧ ಸ್ವೀಕೃತಿ ಸಂಖ್ಯೆ', referencePlaceholder: 'ಉಲ್ಲೇಖ ಮಾತ್ರ', saveReferences: 'ಉಲ್ಲೇಖಗಳನ್ನು ಉಳಿಸಿ',
    saved: 'ಉಲ್ಲೇಖಗಳು ಈ ಸಾಧನದಲ್ಲಿ ಉಳಿಸಲಾಗಿದೆ.',
    secretWarning: 'ದೂರು ಅಥವಾ ಸ್ವೀಕೃತಿ ಉಲ್ಲೇಖ ಮಾತ್ರ ನಮೂದಿಸಿ. OTP, UPI PIN, CVV, ಗುಪ್ತಪದ ಅಥವಾ ಖಾತೆ/ಕಾರ್ಡ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಬೇಡಿ.',
    storageError: 'ಸುರಕ್ಷಿತ ಸಾಧನ ಸಂಗ್ರಹಣೆ ಲಭ್ಯವಿಲ್ಲ. ಈ ಪರದೆಯನ್ನು ಬಿಡುವವರೆಗೆ ಪಟ್ಟಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.',
    verified: `ಅಧಿಕೃತ ಸಂಪರ್ಕ ಮತ್ತು ಪೋರ್ಟಲ್ ಪರಿಶೀಲಿಸಿದ ದಿನಾಂಕ ${emergency.lastVerified}.`,
  },
};

function readStored(value: string | null, stepsCount: number): StoredProgress {
  if (!value) return { completed: [], references: emptyReferences };
  try {
    const parsed: unknown = JSON.parse(value);
    if (!parsed || typeof parsed !== 'object') return { completed: [], references: emptyReferences };
    const data = parsed as Partial<StoredProgress>;
    const completed = Array.isArray(data.completed)
      ? [...new Set(data.completed.filter((index): index is number => Number.isInteger(index) && index >= 0 && index < stepsCount))]
      : [];
    const references = data.references && typeof data.references === 'object'
      ? {
          bank: typeof data.references.bank === 'string' ? data.references.bank.slice(0, 64) : '',
          cybercrime: typeof data.references.cybercrime === 'string' ? data.references.cybercrime.slice(0, 64) : '',
        }
      : emptyReferences;
    return { completed, references };
  } catch {
    return { completed: [], references: emptyReferences };
  }
}

export default function EmergencyScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ topic?: string }>();
  const { language, changeLanguage } = useAppLanguage();
  const [topic, setTopic] = useState<Topic>(() => params.topic === 'account' ? 'account' : 'money');
  const [stepIndex, setStepIndex] = useState(0);
  const [completed, setCompleted] = useState<number[]>([]);
  const [references, setReferences] = useState<References>(emptyReferences);
  const [savedReferences, setSavedReferences] = useState<References>(emptyReferences);
  const [finished, setFinished] = useState(false);
  const [referenceError, setReferenceError] = useState('');
  const [note, setNote] = useState('');
  const [referencesSaved, setReferencesSaved] = useState(false);
  const [loadingSaved, setLoadingSaved] = useState(true);
  const labels = copy[language];
  const steps = useMemo(() => topic === 'money' ? emergency.steps[language] : emergency.accountHacked[language], [language, topic]);
  const activeStep = steps[stepIndex] ?? steps[0];
  const isComplete = completed.includes(stepIndex);

  useEffect(() => {
    if (params.topic === 'money' || params.topic === 'account') setTopic(params.topic);
  }, [params.topic]);

  useEffect(() => {
    let mounted = true;
    setStepIndex(0);
    setCompleted([]);
    setReferences(emptyReferences);
    setSavedReferences(emptyReferences);
    setReferencesSaved(false);
    setFinished(false);
    setNote('');
    setLoadingSaved(true);
    void SecureStore.getItemAsync(referenceStoreKey(topic)).then((saved) => {
      if (!mounted) return;
      const restored = readStored(saved, steps.length);
      setCompleted(restored.completed);
      setReferences(restored.references);
      setSavedReferences(restored.references);
      setReferencesSaved(Boolean(restored.references.bank || restored.references.cybercrime));
      setLoadingSaved(false);
    }).catch(() => {
      if (!mounted) return;
      setNote(labels.storageError);
      setLoadingSaved(false);
    });
    return () => { mounted = false; };
  }, [labels.storageError, steps.length, topic]);

  async function saveLocal(nextCompleted: number[], nextReferences = references): Promise<boolean> {
    setNote('');
    try {
      await SecureStore.setItemAsync(referenceStoreKey(topic), JSON.stringify({ completed: nextCompleted, references: nextReferences }));
      return true;
    } catch {
      setNote(labels.storageError);
      return false;
    }
  }

  async function toggleCurrentStep(): Promise<void> {
    const next = isComplete ? completed.filter((index) => index !== stepIndex) : [...completed, stepIndex];
    setCompleted(next);
    await saveLocal(next);
  }

  async function resetChecklist(): Promise<void> {
    setStepIndex(0);
    setCompleted([]);
    setFinished(false);
    await saveLocal([], savedReferences);
  }

  async function saveReferences(): Promise<void> {
    const values = [references.bank.trim(), references.cybercrime.trim()];
    const invalidFormat = values.some((value) => value && !/^[A-Za-z0-9][A-Za-z0-9 ._/-]{0,63}$/.test(value));
    const secretLike = values.some((value) => /^\d{4,8}$|^\d{13,19}$/.test(value.replaceAll(' ', '')));
    if (invalidFormat || secretLike) {
      setReferenceError(labels.secretWarning);
      setReferencesSaved(false);
      return;
    }
    const cleaned: References = { bank: values[0] ?? '', cybercrime: values[1] ?? '' };
    setReferences(cleaned);
    setReferenceError('');
    const saved = await saveLocal(completed, cleaned);
    if (saved) {
      setSavedReferences(cleaned);
      setReferencesSaved(Boolean(cleaned.bank || cleaned.cybercrime));
    } else {
      setReferencesSaved(false);
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Pressable accessibilityRole="button" onPress={() => router.back()} style={styles.backButton}><Text style={styles.backText}>← Home</Text></Pressable>
    <Text style={styles.eyebrow}>{labels.eyebrow}</Text>
    <Text style={styles.title}>{labels.title}</Text>
    <Text style={styles.body}>{labels.intro}</Text>
    <View style={styles.disclaimer}><Text style={styles.disclaimerText}>{labels.disclaimer}</Text></View>

    <Text style={styles.label}>{labels.language}</Text>
    <View style={styles.languageRow}>
      {(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.languageButton, language === code && styles.selectedButton]}><Text style={[styles.languageText, language === code && styles.selectedText]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text></Pressable>)}
    </View>

    <View style={styles.topicRow}>
      {(['money', 'account'] as const).map((item) => <Pressable key={item} accessibilityRole="tab" accessibilityState={{ selected: topic === item }} onPress={() => { setTopic(item); setNote(''); setReferenceError(''); }} style={[styles.topicButton, topic === item && styles.selectedButton]}><Text style={[styles.topicText, topic === item && styles.selectedText]}>{item === 'money' ? labels.money : labels.account}</Text></Pressable>)}
    </View>

    <View style={styles.card}>
      <View style={styles.progressTop}><Text style={styles.sectionTitle}>{labels.step} {Math.min(stepIndex + 1, steps.length)} / {steps.length}</Text><Text style={styles.small}>{completed.length} {labels.completed}</Text></View>
      <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: steps.length, now: completed.length }} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${steps.length ? completed.length / steps.length * 100 : 0}%` }]} /></View>
      {loadingSaved ? <ActivityIndicator color="#ff987a" /> : finished ? <View style={styles.finishedBox}>
        <Text style={styles.sectionTitle}>{labels.finished}</Text>
        <Pressable accessibilityRole="button" onPress={() => { setFinished(false); setStepIndex(0); }} style={styles.outlineButton}><Text style={styles.link}>{labels.review}</Text></Pressable>
      </View> : <>
        <Text accessibilityLiveRegion="polite" style={styles.currentStep}>{activeStep}</Text>
        <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: isComplete }} onPress={() => { void toggleCurrentStep(); }} style={styles.completeToggle}>
          <View style={[styles.checkbox, isComplete && styles.checkboxChecked]}><Text style={styles.checkmark}>{isComplete ? '✓' : ''}</Text></View>
          <Text style={styles.toggleText}>{isComplete ? labels.markUndone : labels.markDone}</Text>
        </Pressable>
        <View style={styles.navigation}>
          <Pressable accessibilityRole="button" disabled={stepIndex === 0} onPress={() => setStepIndex((index) => Math.max(0, index - 1))} style={[styles.outlineButton, stepIndex === 0 && styles.disabled]}><Text style={styles.link}>{labels.previous}</Text></Pressable>
          {stepIndex < steps.length - 1
            ? <Pressable accessibilityRole="button" disabled={!isComplete} onPress={() => setStepIndex((index) => index + 1)} style={[styles.button, !isComplete && styles.disabled]}><Text style={styles.buttonText}>{labels.next}</Text></Pressable>
            : <Pressable accessibilityRole="button" disabled={!isComplete} onPress={() => setFinished(true)} style={[styles.button, !isComplete && styles.disabled]}><Text style={styles.buttonText}>{labels.finish}</Text></Pressable>}
        </View>
      </>}
      <Pressable accessibilityRole="button" onPress={() => { void resetChecklist(); }} style={styles.resetButton}><Text style={styles.small}>{labels.reset}</Text></Pressable>
    </View>

    <View style={styles.actions}>
      <Pressable accessibilityRole="button" style={styles.button} onPress={() => { void Linking.openURL(`tel:${emergency.helpline}`).catch(() => undefined); }}><Text style={styles.buttonText}>{labels.urgent}</Text></Pressable>
      <Pressable accessibilityRole="link" style={styles.outlineButton} onPress={() => { void Linking.openURL(emergency.portal).catch(() => undefined); }}><Text style={styles.link}>{labels.portal}</Text></Pressable>
    </View>

    <View style={styles.referenceCard}>
      <Text style={styles.sectionTitle}>{labels.references}</Text>
      <Text style={styles.small}>{labels.localOnly}</Text>
      <Text style={styles.label}>{labels.bankReference}</Text>
      <TextInput value={references.bank} onChangeText={(value) => { setReferences((prior) => ({ ...prior, bank: value })); setReferencesSaved(false); }} placeholder={labels.referencePlaceholder} placeholderTextColor="#77716a" autoCapitalize="none" autoCorrect={false} maxLength={64} style={styles.input} />
      <Text style={styles.label}>{labels.cyberReference}</Text>
      <TextInput value={references.cybercrime} onChangeText={(value) => { setReferences((prior) => ({ ...prior, cybercrime: value })); setReferencesSaved(false); }} placeholder={labels.referencePlaceholder} placeholderTextColor="#77716a" autoCapitalize="none" autoCorrect={false} maxLength={64} style={styles.input} />
      {!!referenceError && <Text accessibilityRole="alert" style={styles.error}>{referenceError}</Text>}
      <Pressable accessibilityRole="button" onPress={() => { void saveReferences(); }} style={styles.outlineButton}><Text style={styles.link}>{labels.saveReferences}</Text></Pressable>
      {referencesSaved && <Text accessibilityRole="alert" style={styles.saved}>{labels.saved}</Text>}
    </View>
    {!!note && <Text accessibilityRole="alert" style={styles.small}>{note}</Text>}
    <Text style={styles.verified}>{labels.verified} {emergency.portal}</Text>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 34, paddingBottom: 48, gap: 14 },
  backButton: { minHeight: 44, justifyContent: 'center', alignSelf: 'flex-start', paddingHorizontal: 3 },
  backText: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  eyebrow: { color: '#ff987a', letterSpacing: 1.4, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 28, lineHeight: 34, fontWeight: '300' },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600' },
  small: { color: '#858078', fontSize: 11, lineHeight: 17 },
  disclaimer: { borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,188,112,.25)', backgroundColor: 'rgba(255,188,112,.07)', padding: 13 },
  disclaimerText: { color: '#dfc9aa', lineHeight: 19, fontSize: 12 },
  languageRow: { flexDirection: 'row', gap: 8 },
  languageButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 22, backgroundColor: '#171411' },
  languageText: { color: '#aaa49b', fontSize: 12 },
  topicRow: { flexDirection: 'row', gap: 8 },
  topicButton: { flex: 1, minHeight: 48, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 10, borderRadius: 14, backgroundColor: '#171411' },
  topicText: { color: '#aaa49b', textAlign: 'center', fontSize: 12, fontWeight: '600' },
  selectedButton: { backgroundColor: '#32221b', borderColor: '#ff987a', borderWidth: 1 },
  selectedText: { color: '#ff987a', fontWeight: '700' },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 13 },
  progressTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { color: '#f4f2ef', fontSize: 14, lineHeight: 20, fontWeight: '600' },
  progressTrack: { height: 5, overflow: 'hidden', borderRadius: 3, backgroundColor: '#322a24' },
  progressFill: { height: 5, backgroundColor: '#ff8060' },
  currentStep: { color: '#e9e3dc', fontSize: 15, lineHeight: 23, minHeight: 68 },
  completeToggle: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 },
  checkbox: { width: 20, height: 20, borderRadius: 5, borderWidth: 1, borderColor: '#aaa49b', alignItems: 'center', justifyContent: 'center' },
  checkboxChecked: { backgroundColor: '#ff8060', borderColor: '#ff8060' },
  checkmark: { color: '#23120d', fontSize: 13, fontWeight: '900' },
  toggleText: { flex: 1, color: '#d9d2ca', fontSize: 12 },
  navigation: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  outlineButton: { minHeight: 44, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 13, borderRadius: 23, borderWidth: 1, borderColor: 'rgba(255,174,155,.32)' },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600', textAlign: 'center' },
  button: { minHeight: 44, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 16, borderRadius: 23, backgroundColor: '#ff8060' },
  buttonText: { color: '#23120d', fontWeight: '700', fontSize: 12, textAlign: 'center' },
  disabled: { opacity: 0.45 },
  resetButton: { alignSelf: 'flex-start', minHeight: 44, justifyContent: 'center', paddingHorizontal: 2 },
  finishedBox: { gap: 12, paddingVertical: 8 },
  actions: { gap: 8 },
  referenceCard: { gap: 10, padding: 15, borderRadius: 17, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f' },
  input: { minHeight: 46, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,.13)', backgroundColor: '#0d0b09', color: '#f4f2ef', fontSize: 13 },
  error: { color: '#ff9ba5', fontSize: 12, lineHeight: 18 },
  saved: { color: '#a9dcba', fontSize: 11, lineHeight: 17 },
  verified: { color: '#817b73', fontSize: 10, lineHeight: 16 },
});
