import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../../locale/LanguageProvider';
import { categoryTitle, featureTitle, findMobileFeature } from '../../navigation/catalog';
import type { MobileAction } from '../../navigation/catalog';

const copy: Record<Language, { category: string; unavailable: string; unavailableBody: string; guidance: string; available: string; open: string; footer: string; notFound: string; notFoundBody: string }> = {
  en: { category: 'Category', unavailable: 'Not available in this build', unavailableBody: 'This feature is not active. ScamShield will not pretend to store, send, or monitor anything here.', guidance: 'Guidance only', available: 'Available in this build', open: 'Open', footer: 'Educational guidance is separate from scan results. Never share an OTP, UPI PIN, CVV, password, or full account/card number.', notFound: 'Feature not found', notFoundBody: 'Return to the category and choose an available feature.' },
  hi: { category: 'श्रेणी', unavailable: 'इस बिल्ड में उपलब्ध नहीं', unavailableBody: 'यह सुविधा सक्रिय नहीं है। ScamShield यहाँ कुछ सहेजने, भेजने या निगरानी करने का दावा नहीं करता।', guidance: 'केवल मार्गदर्शन', available: 'इस बिल्ड में उपलब्ध', open: 'खोलें', footer: 'शैक्षिक मार्गदर्शन स्कैन परिणामों से अलग है। OTP, UPI PIN, CVV, पासवर्ड या पूरा खाता/कार्ड नंबर साझा न करें।', notFound: 'सुविधा नहीं मिली', notFoundBody: 'श्रेणी पर लौटें और उपलब्ध सुविधा चुनें।' },
  kn: { category: 'ವರ್ಗ', unavailable: 'ಈ ಬಿಲ್ಡ್‌ನಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲ', unavailableBody: 'ಈ ವೈಶಿಷ್ಟ್ಯ ಸಕ್ರಿಯವಾಗಿಲ್ಲ. ಇಲ್ಲಿ ಏನನ್ನೂ ಉಳಿಸುವ, ಕಳುಹಿಸುವ ಅಥವಾ ಗಮನಿಸುವುದಾಗಿ ScamShield ಹೇಳುವುದಿಲ್ಲ.', guidance: 'ಮಾರ್ಗದರ್ಶನ ಮಾತ್ರ', available: 'ಈ ಬಿಲ್ಡ್‌ನಲ್ಲಿ ಲಭ್ಯ', open: 'ತೆರೆಯಿರಿ', footer: 'ಶೈಕ್ಷಣಿಕ ಮಾರ್ಗದರ್ಶನ ಸ್ಕ್ಯಾನ್ ಫಲಿತಾಂಶಗಳಿಂದ ಪ್ರತ್ಯೇಕವಾಗಿದೆ. OTP, UPI PIN, CVV, ಗುಪ್ತಪದ ಅಥವಾ ಪೂರ್ಣ ಖಾತೆ/ಕಾರ್ಡ್ ಸಂಖ್ಯೆಯನ್ನು ಹಂಚಬೇಡಿ.', notFound: 'ವೈಶಿಷ್ಟ್ಯ ಕಂಡುಬಂದಿಲ್ಲ', notFoundBody: 'ವರ್ಗಕ್ಕೆ ಹಿಂತಿರುಗಿ ಲಭ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ.' },
};

function openFeature(router: ReturnType<typeof useRouter>, action: MobileAction): void {
  switch (action) {
    case 'message': router.push('/(tabs)/scan'); return;
    case 'url': router.push({ pathname: '/(tabs)/scan', params: { mode: 'url' } }); return;
    case 'qr': router.push({ pathname: '/(tabs)/scan', params: { mode: 'qr' } }); return;
    case 'history':
    case 'profile': router.push('/(tabs)/profile'); return;
    case 'alerts': router.push('/(tabs)/alerts'); return;
    case 'security': router.push('/security-checklist'); return;
    case 'emergency-money': router.push({ pathname: '/emergency', params: { topic: 'money' } }); return;
    case 'emergency-account': router.push({ pathname: '/emergency', params: { topic: 'account' } }); return;
    case 'emergency': router.push('/emergency'); return;
    case 'learn': router.push('/(tabs)/learn'); return;
  }
}

export default function FeatureScreen() {
  const params = useLocalSearchParams<{ slug?: string }>();
  const router = useRouter();
  const { language } = useAppLanguage();
  const labels = copy[language];
  const result = findMobileFeature(typeof params.slug === 'string' ? params.slug : undefined);
  const feature = result?.feature;

  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Pressable accessibilityRole="button" onPress={() => router.back()} style={styles.back}><Text style={styles.link}>← {result ? categoryTitle(result.category, language) : labels.category}</Text></Pressable>
    {feature ? <>
      <Text style={styles.eyebrow}>{categoryTitle(result.category, language).toUpperCase()}</Text>
      <Text style={styles.title}>{featureTitle(feature, language)}</Text>
      <Text style={styles.body}>{feature.description}</Text>
      {feature.availability === 'unavailable' || (!feature.action && !feature.guidance)
        ? <View style={styles.unavailable}><Text style={styles.status}>{labels.unavailable}</Text><Text style={styles.body}>{labels.unavailableBody}</Text></View>
        : <View style={styles.card}>
          <Text style={styles.status}>{feature.availability === 'guidance' ? labels.guidance : labels.available}</Text>
          {feature.guidance?.map((item) => <Text key={item} style={styles.point}>•  {item}</Text>)}
          {!!feature.action && <Pressable accessibilityRole="button" onPress={() => openFeature(router, feature.action!)} style={styles.button}><Text style={styles.buttonText}>{labels.open} {featureTitle(feature, language)}</Text></Pressable>}
        </View>}
      <Text style={styles.footer}>{labels.footer}</Text>
    </> : <View style={styles.card}><Text style={styles.title}>{labels.notFound}</Text><Text style={styles.body}>{labels.notFoundBody}</Text></View>}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 42, paddingBottom: 48, gap: 14 },
  back: { minHeight: 44, alignSelf: 'flex-start', justifyContent: 'center', paddingHorizontal: 3 },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  eyebrow: { color: '#ff987a', letterSpacing: 1.3, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 28, lineHeight: 35, fontWeight: '300' },
  body: { color: '#aaa49b', fontSize: 13, lineHeight: 21 },
  card: { padding: 17, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 12 },
  unavailable: { padding: 16, borderRadius: 15, borderWidth: 1, borderColor: 'rgba(255,188,112,.25)', backgroundColor: 'rgba(255,188,112,.07)', gap: 9 },
  status: { color: '#ffcf8f', fontSize: 13, lineHeight: 19, fontWeight: '700' },
  point: { color: '#d8d1c8', fontSize: 12, lineHeight: 19 },
  button: { minHeight: 46, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, borderRadius: 24, backgroundColor: '#ff8060' },
  buttonText: { color: '#23120d', fontSize: 12, fontWeight: '700' },
  footer: { color: '#817b73', fontSize: 10, lineHeight: 16 },
});
