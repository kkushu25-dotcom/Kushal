import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import type { Language } from '@scamshield/api-client/types';
import learning from '../../../../packages/content/learning-content.json';
import { useAppLanguage } from '../../locale/LanguageProvider';

type Lesson = (typeof learning.en)[number];
const progressKey = 'scamshield.mobile.learning-progress.v1';
const lessonIds = new Set(learning.en.map((lesson) => lesson.id));
const learnCopy: Record<Language, { eyebrow: string; title: string; intro: string; language: string; progress: (complete: number, total: number) => string; progressReadError: string; progressUnavailable: string; progressSaveError: string; progressClearError: string; reset: string; completed: string; open: string; back: string; scenario: string; remember: string; check: string; correct: string; review: string; saferChoice: string; finish: string }> = {
  en: { eyebrow: 'PRACTICE DIGITAL SAFETY', title: 'Learn to spot pressure', intro: 'Short examples and quizzes explain common warning signs. These are educational scenarios, not live scam checks.', language: 'Content language', progress: (complete, total) => `Saved on this device: ${complete} of ${total}. This is learning activity, not a safety score.`, progressReadError: 'Saved learning progress could not be read. You can reset it below.', progressUnavailable: 'Saved progress is unavailable. Completions will stay on this screen only.', progressSaveError: 'Progress could not be saved. It will last only while this screen remains open.', progressClearError: 'Saved progress could not be cleared from this device.', reset: 'Reset this device’s progress', completed: 'Completed', open: 'Open lesson and quiz', back: '← All lessons', scenario: 'Synthetic example · Not a live message', remember: 'Remember', check: 'Check answer', correct: 'That is a safer next step.', review: 'Review the safer next step.', saferChoice: 'Safer choice', finish: 'Mark lesson complete' },
  hi: { eyebrow: 'डिजिटल सुरक्षा का अभ्यास', title: 'दबाव के संकेत पहचानें', intro: 'छोटे उदाहरण और क्विज़ आम चेतावनी संकेत समझाते हैं। ये सीखने के उदाहरण हैं, लाइव स्कैम जाँच नहीं।', language: 'सामग्री की भाषा', progress: (complete, total) => `इस डिवाइस पर सहेजा: ${total} में से ${complete}। यह सीखने की गतिविधि है, सुरक्षा स्कोर नहीं।`, progressReadError: 'सहेजी गई सीखने की प्रगति पढ़ी नहीं जा सकी। नीचे इसे रीसेट कर सकते हैं।', progressUnavailable: 'सहेजी गई प्रगति उपलब्ध नहीं है। पूरा किया गया पाठ केवल इसी स्क्रीन पर रहेगा।', progressSaveError: 'प्रगति सहेजी नहीं जा सकी। यह स्क्रीन खुली रहने तक ही रहेगी।', progressClearError: 'इस डिवाइस से सहेजी गई प्रगति हटाई नहीं जा सकी।', reset: 'इस डिवाइस की प्रगति रीसेट करें', completed: 'पूरा', open: 'पाठ और क्विज़ खोलें', back: '← सभी पाठ', scenario: 'बनाया गया उदाहरण · असली संदेश नहीं', remember: 'याद रखें', check: 'उत्तर जाँचें', correct: 'यह अधिक सुरक्षित अगला कदम है।', review: 'सुरक्षित अगले कदम पर फिर से विचार करें।', saferChoice: 'सुरक्षित विकल्प', finish: 'पाठ पूरा चिह्नित करें' },
  kn: { eyebrow: 'ಡಿಜಿಟಲ್ ಸುರಕ್ಷತೆ ಅಭ್ಯಾಸ', title: 'ಒತ್ತಡದ ಸೂಚನೆಗಳನ್ನು ಗುರುತಿಸಿ', intro: 'ಚಿಕ್ಕ ಉದಾಹರಣೆಗಳು ಮತ್ತು ರಸಪ್ರಶ್ನೆಗಳು ಸಾಮಾನ್ಯ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳನ್ನು ವಿವರಿಸುತ್ತವೆ. ಇವು ಕಲಿಕೆಯ ಸನ್ನಿವೇಶಗಳು; ನೈಜ ಸ್ಕ್ಯಾನ್‌ಗಳಲ್ಲ.', language: 'ವಿಷಯದ ಭಾಷೆ', progress: (complete, total) => `ಈ ಸಾಧನದಲ್ಲಿ ಉಳಿಸಲಾಗಿದೆ: ${total}ರಲ್ಲಿ ${complete}. ಇದು ಕಲಿಕೆಯ ಚಟುವಟಿಕೆ; ಸುರಕ್ಷತಾ ಅಂಕವಲ್ಲ.`, progressReadError: 'ಉಳಿಸಿದ ಕಲಿಕೆಯ ಪ್ರಗತಿಯನ್ನು ಓದಲಾಗಲಿಲ್ಲ. ಕೆಳಗೆ ಮರುಹೊಂದಿಸಬಹುದು.', progressUnavailable: 'ಉಳಿಸಿದ ಪ್ರಗತಿ ಲಭ್ಯವಿಲ್ಲ. ಪೂರ್ಣಗೊಳಿಸುವಿಕೆ ಈ ಪರದೆ ತೆರೆದಿರುವವರೆಗೆ ಮಾತ್ರ ಇರುತ್ತದೆ.', progressSaveError: 'ಪ್ರಗತಿ ಉಳಿಸಲಾಗಲಿಲ್ಲ. ಈ ಪರದೆ ತೆರೆದಿರುವವರೆಗೆ ಮಾತ್ರ ಇರುತ್ತದೆ.', progressClearError: 'ಈ ಸಾಧನದಿಂದ ಉಳಿಸಿದ ಪ್ರಗತಿಯನ್ನು ತೆರವುಗೊಳಿಸಲಾಗಲಿಲ್ಲ.', reset: 'ಈ ಸಾಧನದ ಪ್ರಗತಿ ಮರುಹೊಂದಿಸಿ', completed: 'ಪೂರ್ಣಗೊಂಡಿದೆ', open: 'ಪಾಠ ಮತ್ತು ರಸಪ್ರಶ್ನೆ ತೆರೆಯಿರಿ', back: '← ಎಲ್ಲಾ ಪಾಠಗಳು', scenario: 'ಕಲ್ಪಿತ ಉದಾಹರಣೆ · ನೈಜ ಸಂದೇಶವಲ್ಲ', remember: 'ನೆನಪಿಡಿ', check: 'ಉತ್ತರ ಪರಿಶೀಲಿಸಿ', correct: 'ಇದು ಹೆಚ್ಚು ಸುರಕ್ಷಿತ ಮುಂದಿನ ಹೆಜ್ಜೆ.', review: 'ಸುರಕ್ಷಿತ ಮುಂದಿನ ಹೆಜ್ಜೆಯನ್ನು ಮತ್ತೆ ಪರಿಶೀಲಿಸಿ.', saferChoice: 'ಸುರಕ್ಷಿತ ಆಯ್ಕೆ', finish: 'ಪಾಠ ಪೂರ್ಣಗೊಳಿಸಿ' },
};

export default function LearnScreen() {
  const { language, changeLanguage } = useAppLanguage();
  const copy = learnCopy[language];
  const [activeId, setActiveId] = useState<string | null>(null);
  const [choice, setChoice] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const [completed, setCompleted] = useState<string[]>([]);
  const [progressNote, setProgressNote] = useState<string | null>(null);
  const lessons = learning[language] as Lesson[];
  const active = lessons.find((lesson) => lesson.id === activeId);
  const correct = active !== undefined && choice === active.answerIndex;

  useEffect(() => {
    let mounted = true;
    void SecureStore.getItemAsync(progressKey).then((saved) => {
      if (!mounted || !saved) return;
      try {
        const parsed: unknown = JSON.parse(saved);
        if (Array.isArray(parsed)) setCompleted(parsed.filter((item): item is string => typeof item === 'string' && lessonIds.has(item)));
      } catch {
        setProgressNote(learnCopy[language].progressReadError);
      }
    }).catch(() => {
      if (mounted) setProgressNote(learnCopy[language].progressUnavailable);
    });
    return () => { mounted = false; };
  }, [language]);

  function openLesson(id: string) {
    setActiveId(id);
    setChoice(null);
    setChecked(false);
  }

  async function completeLesson(id: string): Promise<void> {
    const next = completed.includes(id) ? completed : [...completed, id];
    setCompleted(next);
    setActiveId(null);
    setProgressNote(null);
    try {
      await SecureStore.setItemAsync(progressKey, JSON.stringify(next));
    } catch {
      setProgressNote(copy.progressSaveError);
    }
  }

  async function resetProgress(): Promise<void> {
    setCompleted([]);
    setProgressNote(null);
    try {
      await SecureStore.deleteItemAsync(progressKey);
    } catch {
      setProgressNote(copy.progressClearError);
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Text style={styles.eyebrow}>{copy.eyebrow}</Text>
    <Text style={styles.title}>{active ? active.title : copy.title}</Text>
    <Text style={styles.body}>{active ? active.summary : copy.intro}</Text>
    {!active && <>
      <Text style={styles.label}>{copy.language}</Text>
      <View style={styles.languageRow}>{(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.language, language === code && styles.languageActive]}><Text style={[styles.languageText, language === code && styles.languageTextActive]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text></Pressable>)}</View>
      <Text style={styles.progress}>{copy.progress(completed.length, lessons.length)}</Text>
      {!!progressNote && <Text style={styles.small}>{progressNote}</Text>}
      {completed.length > 0 && <Pressable accessibilityRole="button" onPress={() => { void resetProgress(); }} style={styles.reset}><Text style={styles.link}>{copy.reset}</Text></Pressable>}
      {lessons.map((lesson) => <View style={styles.card} key={lesson.id}>
        <Text style={styles.cardTitle}>{lesson.title}{completed.includes(lesson.id) ? ` · ${copy.completed}` : ''}</Text>
        <Text style={styles.body}>{lesson.summary}</Text>
        <Pressable accessibilityRole="button" onPress={() => openLesson(lesson.id)} style={styles.button}><Text style={styles.buttonText}>{copy.open}</Text></Pressable>
      </View>)}
    </>}
    {active && <>
      <Pressable accessibilityRole="button" onPress={() => setActiveId(null)} style={styles.back}><Text style={styles.link}>{copy.back}</Text></Pressable>
      <View style={styles.scenario}><Text style={styles.scenarioTitle}>{copy.scenario}</Text><Text style={styles.body}>{active.scenario}</Text></View>
      <Text style={styles.sectionTitle}>{copy.remember}</Text>
      {active.keyPoints.map((point) => <Text style={styles.point} key={point}>•  {point}</Text>)}
      <Text style={styles.sectionTitle}>{active.question}</Text>
      {active.choices.map((option, index) => <Pressable key={option} accessibilityRole="radio" accessibilityState={{ selected: choice === index }} onPress={() => { setChoice(index); setChecked(false); }} style={[styles.choice, choice === index && styles.choiceSelected]}><Text style={styles.body}>{option}</Text></Pressable>)}
      {!checked ? <Pressable accessibilityRole="button" disabled={choice === null} onPress={() => setChecked(true)} style={[styles.button, choice === null && styles.disabled]}><Text style={styles.buttonText}>{copy.check}</Text></Pressable> : <View style={styles.feedback} accessibilityLiveRegion="polite"><Text style={styles.cardTitle}>{correct ? copy.correct : copy.review}</Text><Text style={styles.body}>{active.explanation}</Text>{!correct && <Text style={styles.body}>{copy.saferChoice}: {active.choices[active.answerIndex]}</Text>}<Pressable accessibilityRole="button" onPress={() => { void completeLesson(active.id); }} style={styles.button}><Text style={styles.buttonText}>{copy.finish}</Text></Pressable></View>}
    </>}
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 54, paddingBottom: 46, gap: 13 },
  eyebrow: { color: '#ff987a', letterSpacing: 1.6, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 27, lineHeight: 33, fontWeight: '300' },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  label: { color: '#e7e3de', fontWeight: '600', marginTop: 4 },
  languageRow: { flexDirection: 'row', gap: 8 },
  language: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 20, backgroundColor: '#171411' },
  languageActive: { backgroundColor: '#32221b' },
  languageText: { color: '#aaa49b', fontSize: 12 },
  languageTextActive: { color: '#ff987a', fontWeight: '700' },
  progress: { color: '#817b73', fontSize: 11, lineHeight: 17 },
  small: { color: '#858078', fontSize: 11, lineHeight: 17 },
  reset: { alignSelf: 'flex-start', paddingVertical: 7 },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 10 },
  cardTitle: { color: '#f4f2ef', fontSize: 15, fontWeight: '600' },
  button: { alignSelf: 'flex-start', paddingHorizontal: 16, paddingVertical: 11, borderRadius: 24, backgroundColor: '#ff8060', marginTop: 4 },
  buttonText: { color: '#23120d', fontWeight: '700', fontSize: 12 },
  disabled: { opacity: 0.45 },
  back: { alignSelf: 'flex-start', paddingVertical: 7 },
  link: { color: '#ffae9b', fontWeight: '600' },
  scenario: { padding: 14, borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,188,112,.25)', backgroundColor: 'rgba(255,188,112,.07)', gap: 7 },
  scenarioTitle: { color: '#f2c36d', fontWeight: '700', fontSize: 11 },
  sectionTitle: { marginTop: 5, color: '#f4f2ef', fontSize: 15, fontWeight: '600' },
  point: { color: '#aaa49b', lineHeight: 20, fontSize: 12 },
  choice: { padding: 13, borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f' },
  choiceSelected: { borderColor: '#ff987a', backgroundColor: '#211814' },
  feedback: { padding: 14, borderRadius: 14, backgroundColor: '#15120f', gap: 9 },
});
