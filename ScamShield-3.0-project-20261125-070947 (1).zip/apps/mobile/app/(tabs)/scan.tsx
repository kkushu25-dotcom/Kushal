import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useShareIntentContext } from 'expo-share-intent';
import type { Language, ScanResult } from '@scamshield/api-client/types';
import { QRScannerView } from '../../components/QRScannerView';
import { useMobileAuth } from '../../auth/AuthProvider';
import { useAppLanguage } from '../../locale/LanguageProvider';

type Mode = 'message' | 'url' | 'qr';
const scanCopy: Record<Language, { eyebrow: string; title: string; intro: string; privacy: string; message: string; link: string; qr: string; messageLabel: string; linkLabel: string; messagePlaceholder: string; linkPlaceholder: string; historyToggle: string; guest: string; checkMessage: string; checkLink: string; missingMessage: string; missingLink: string; shareMissing: string; shareTooLong: string; resultScam: string; resultSuspicious: string; resultClear: string; strength: string; rulesOnly: string; saved: string; disclaimer: string }> = {
  en: { eyebrow: 'PRIVATE BY DEFAULT', title: 'Check before you act', intro: 'Paste suspicious text or a link. ScamShield will assess warning signs without opening a URL.', privacy: 'Your text is sent for this check and is not saved by default. Never paste OTPs, UPI PINs, CVVs, passwords, or full card or account numbers.', message: 'Message', link: 'Link', qr: 'QR', messageLabel: 'Message to check', linkLabel: 'Link to inspect as text', messagePlaceholder: 'Paste suspicious SMS or chat text…', linkPlaceholder: 'https://example.com', historyToggle: 'Save assessment details to my account history', guest: 'Guest scans are never saved. Sign in from Profile to enable optional history.', checkMessage: 'Check message', checkLink: 'Check link', missingMessage: 'Paste a message to check.', missingLink: 'Paste a link to check.', shareMissing: 'The shared item did not contain readable text or a link.', shareTooLong: 'The shared item is too long to assess.', resultScam: 'Strong warning signs found', resultSuspicious: 'Some warning signs found', resultClear: 'No configured warning signs found', strength: 'Rule match strength', rulesOnly: 'Rules-only check · No AI provider is connected', saved: 'Assessment summary saved. The original text and detected entities were not saved.', disclaimer: 'A scan is a risk assessment, not proof that something is safe or fraudulent.' },
  hi: { eyebrow: 'डिफ़ॉल्ट रूप से निजी', title: 'कार्रवाई से पहले जाँचें', intro: 'संदिग्ध टेक्स्ट या लिंक डालें। ScamShield URL खोले बिना चेतावनी संकेतों का आकलन करेगा।', privacy: 'इस जाँच के लिए आपका टेक्स्ट भेजा जाता है और डिफ़ॉल्ट रूप से सहेजा नहीं जाता। OTP, UPI PIN, CVV, पासवर्ड या पूरे कार्ड/खाता नंबर कभी न डालें।', message: 'संदेश', link: 'लिंक', qr: 'QR', messageLabel: 'जाँचने के लिए संदेश', linkLabel: 'टेक्स्ट के रूप में लिंक जाँचें', messagePlaceholder: 'संदिग्ध SMS या चैट टेक्स्ट डालें…', linkPlaceholder: 'https://example.com', historyToggle: 'आकलन का विवरण मेरे खाते के इतिहास में सहेजें', guest: 'मेहमान के स्कैन कभी सहेजे नहीं जाते। वैकल्पिक इतिहास के लिए प्रोफ़ाइल से साइन इन करें।', checkMessage: 'संदेश जाँचें', checkLink: 'लिंक जाँचें', missingMessage: 'जाँचने के लिए संदेश डालें।', missingLink: 'जाँचने के लिए लिंक डालें।', shareMissing: 'साझा आइटम में पढ़ने योग्य टेक्स्ट या लिंक नहीं था।', shareTooLong: 'साझा आइटम आकलन के लिए बहुत लंबा है।', resultScam: 'मजबूत चेतावनी संकेत मिले', resultSuspicious: 'कुछ चेतावनी संकेत मिले', resultClear: 'कॉन्फ़िगर किए गए चेतावनी संकेत नहीं मिले', strength: 'नियम मिलान शक्ति', rulesOnly: 'केवल नियमों से जाँच · कोई AI सेवा जुड़ी नहीं है', saved: 'आकलन सारांश सहेजा गया। मूल टेक्स्ट और पहचाने गए विवरण सहेजे नहीं गए।', disclaimer: 'स्कैन जोखिम का आकलन है; यह सुरक्षा या धोखाधड़ी का प्रमाण नहीं है।' },
  kn: { eyebrow: 'ಡೀಫಾಲ್ಟ್ ಆಗಿ ಖಾಸಗಿ', title: 'ಕ್ರಮ ಕೈಗೊಳ್ಳುವ ಮೊದಲು ಪರಿಶೀಲಿಸಿ', intro: 'ಅನುಮಾನಾಸ್ಪದ ಪಠ್ಯ ಅಥವಾ ಲಿಂಕ್ ಅಂಟಿಸಿ. ScamShield URL ತೆರೆಯದೆ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ.', privacy: 'ಈ ಪರಿಶೀಲನೆಗಾಗಿ ನಿಮ್ಮ ಪಠ್ಯ ಕಳುಹಿಸಲಾಗುತ್ತದೆ; ಡೀಫಾಲ್ಟ್ ಆಗಿ ಉಳಿಸಲಾಗುವುದಿಲ್ಲ. OTP, UPI PIN, CVV, ಪಾಸ್‌ವರ್ಡ್ ಅಥವಾ ಪೂರ್ಣ ಕಾರ್ಡ್/ಖಾತೆ ಸಂಖ್ಯೆಯನ್ನು ಎಂದಿಗೂ ಅಂಟಿಸಬೇಡಿ.', message: 'ಸಂದೇಶ', link: 'ಲಿಂಕ್', qr: 'QR', messageLabel: 'ಪರಿಶೀಲಿಸಬೇಕಾದ ಸಂದೇಶ', linkLabel: 'ಪಠ್ಯವಾಗಿ ಲಿಂಕ್ ಪರಿಶೀಲಿಸಿ', messagePlaceholder: 'ಅನುಮಾನಾಸ್ಪದ SMS ಅಥವಾ ಚಾಟ್ ಪಠ್ಯ ಅಂಟಿಸಿ…', linkPlaceholder: 'https://example.com', historyToggle: 'ಮೌಲ್ಯಮಾಪನ ವಿವರಗಳನ್ನು ನನ್ನ ಖಾತೆ ಇತಿಹಾಸದಲ್ಲಿ ಉಳಿಸಿ', guest: 'ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ. ಐಚ್ಛಿಕ ಇತಿಹಾಸಕ್ಕಾಗಿ ಪ್ರೊಫೈಲ್‌ನಿಂದ ಸೈನ್ ಇನ್ ಮಾಡಿ.', checkMessage: 'ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ', checkLink: 'ಲಿಂಕ್ ಪರಿಶೀಲಿಸಿ', missingMessage: 'ಪರಿಶೀಲಿಸಲು ಸಂದೇಶ ಅಂಟಿಸಿ.', missingLink: 'ಪರಿಶೀಲಿಸಲು ಲಿಂಕ್ ಅಂಟಿಸಿ.', shareMissing: 'ಹಂಚಿದ ವಿಷಯದಲ್ಲಿ ಓದಬಹುದಾದ ಪಠ್ಯ ಅಥವಾ ಲಿಂಕ್ ಇರಲಿಲ್ಲ.', shareTooLong: 'ಹಂಚಿದ ವಿಷಯ ಪರಿಶೀಲಿಸಲು ತುಂಬಾ ಉದ್ದವಾಗಿದೆ.', resultScam: 'ಬಲವಾದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultSuspicious: 'ಕೆಲವು ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultClear: 'ಕಾನ್ಫಿಗರ್ ಮಾಡಿದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ', strength: 'ನಿಯಮ ಹೊಂದಾಣಿಕೆಯ ಬಲ', rulesOnly: 'ನಿಯಮ ಆಧಾರಿತ ಪರಿಶೀಲನೆ ಮಾತ್ರ · AI ಸೇವೆ ಸಂಪರ್ಕಗೊಂಡಿಲ್ಲ', saved: 'ಮೌಲ್ಯಮಾಪನ ಸಾರಾಂಶ ಉಳಿಸಲಾಗಿದೆ. ಮೂಲ ಪಠ್ಯ ಮತ್ತು ಪತ್ತೆಯಾದ ವಿವರಗಳನ್ನು ಉಳಿಸಿಲ್ಲ.', disclaimer: 'ಸ್ಕ್ಯಾನ್ ಅಪಾಯದ ಮೌಲ್ಯಮಾಪನ ಮಾತ್ರ; ಸುರಕ್ಷತೆ ಅಥವಾ ವಂಚನೆಗೆ ಪುರಾವೆಯಲ್ಲ.' },
};
export default function ScanScreen() {
  const { ready: authReady, session, authorizedFetch } = useMobileAuth();
  const { language } = useAppLanguage();
  const labels = scanCopy[language];
  const { hasShareIntent, shareIntent, resetShareIntent } = useShareIntentContext();
  const params = useLocalSearchParams<{ mode?: string }>();
  const [mode, setMode] = useState<Mode>(() => params.mode === 'qr' ? 'qr' : params.mode === 'url' ? 'url' : 'message');
  const [message, setMessage] = useState('');
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saveHistory, setSaveHistory] = useState(false);
  const [savedToHistory, setSavedToHistory] = useState(false);
  useEffect(() => {
    if (params.mode === 'qr' || params.mode === 'url' || params.mode === 'message') setMode(params.mode);
  }, [params.mode]);
  useEffect(() => {
    if (!hasShareIntent) return;
    const sharedUrl = shareIntent?.webUrl?.trim();
    const sharedText = shareIntent?.text?.trim();
    const standaloneSharedUrl = Boolean(sharedText && /^https?:\/\//i.test(sharedText) && !/\s/.test(sharedText));
    const isUrl = standaloneSharedUrl || (!sharedText && Boolean(sharedUrl));
    const value = standaloneSharedUrl ? sharedText ?? '' : sharedText || sharedUrl || '';
    if (!value) {
      setError(scanCopy[language].shareMissing);
      resetShareIntent();
      return;
    }
    if (value.length > (isUrl ? 2048 : 4000)) {
      setError(scanCopy[language].shareTooLong);
      resetShareIntent();
      return;
    }
    setMode(isUrl ? 'url' : 'message');
    if (isUrl) setUrl(value);
    else setMessage(value);
    setResult(null);
    setSavedToHistory(false);
    setError(null);
    resetShareIntent();
  }, [hasShareIntent, language, resetShareIntent, shareIntent]);
  useEffect(() => {
    setSaveHistory(false);
    setSavedToHistory(false);
  }, [session?.user.id]);
  const currentText = mode === 'message' ? message : url;

  async function checkText() {
    const value = currentText.trim();
    if (!value) {
      setError(mode === 'message' ? labels.missingMessage : labels.missingLink);
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    setSavedToHistory(false);
    try {
      const response = await authorizedFetch(`/scans/${mode === 'message' ? 'messages' : 'urls'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mode === 'message' ? { message: value, language, save_history: Boolean(session && saveHistory) } : { url: value, language, save_history: Boolean(session && saveHistory) }),
      });
      const data = await response.json() as ScanResult & { error?: { message?: string }; detail?: string };
      if (!response.ok) throw new Error(data.error?.message ?? data.detail ?? `Request failed (${response.status})`);
      setResult(data);
      setSavedToHistory(Boolean(session && saveHistory));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'We could not reach ScamShield. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.eyebrow}>{labels.eyebrow}</Text>
    <Text style={styles.title}>{labels.title}</Text>
    <Text style={styles.body}>{labels.intro}</Text>
    <View style={styles.privacy}><Text style={styles.privacyText}>{labels.privacy}</Text></View>
    <View style={styles.switcher} accessibilityRole="tablist">
      {(['message', 'url', 'qr'] as const).map((item) => <Pressable key={item} accessibilityRole="tab" accessibilityState={{ selected: mode === item }} onPress={() => { setMode(item); setResult(null); setSavedToHistory(false); setError(null); }} style={[styles.switch, mode === item && styles.switchSelected]}><Text style={[styles.switchText, mode === item && styles.switchTextSelected]}>{item === 'message' ? labels.message : item === 'url' ? labels.link : labels.qr}</Text></Pressable>)}
    </View>
    {mode === 'qr' ? <QRScannerView language={language} /> : <>
    <Text style={styles.label}>{mode === 'message' ? labels.messageLabel : labels.linkLabel}</Text>
    <TextInput
      value={currentText}
      onChangeText={mode === 'message' ? setMessage : setUrl}
      placeholder={mode === 'message' ? labels.messagePlaceholder : labels.linkPlaceholder}
      placeholderTextColor="#77716a"
      multiline={mode === 'message'}
      autoCapitalize="none"
      autoCorrect={false}
      inputMode={mode === 'url' ? 'url' : 'text'}
      maxLength={mode === 'message' ? 4000 : 2048}
      accessibilityLabel={mode === 'message' ? 'Message to check' : 'Link to inspect as text'}
      style={[styles.input, mode === 'message' && styles.messageInput]}
    />
    <Text style={styles.counter}>{currentText.length}/{mode === 'message' ? '4,000' : '2,048'}</Text>
    {authReady && session && <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: saveHistory }} onPress={() => setSaveHistory((value) => !value)} style={styles.saveToggle}><View style={[styles.checkbox, saveHistory && styles.checkboxSelected]} /><Text style={styles.saveText}>{labels.historyToggle}</Text></Pressable>}
    {authReady && !session && <Text style={styles.small}>{labels.guest}</Text>}
    <Pressable accessibilityRole="button" onPress={checkText} disabled={loading || !currentText.trim()} style={[styles.button, (loading || !currentText.trim()) && styles.buttonDisabled]}>
      {loading ? <ActivityIndicator color="#23120d" /> : <Text style={styles.buttonText}>{mode === 'message' ? labels.checkMessage : labels.checkLink}</Text>}
    </Pressable>
    {error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
    {result && <ResultCard result={result} language={language} />}
    {savedToHistory && <Text style={styles.saved}>{labels.saved}</Text>}
    <Text style={styles.disclaimer}>{labels.disclaimer}</Text>
    </>}
  </ScrollView>;
}

function ResultCard({ result, language }: { result: ScanResult; language: Language }) {
  const labels = scanCopy[language];
  const color = result.verdict === 'SCAM' ? '#ff8290' : result.verdict === 'SUSPICIOUS' ? '#ffb879' : '#95d6a6';
  const title = result.verdict === 'SCAM' ? labels.resultScam : result.verdict === 'SUSPICIOUS' ? labels.resultSuspicious : labels.resultClear;
  return <View style={styles.result} accessibilityLiveRegion="polite">
    <Text style={[styles.resultVerdict, { color }]}>{title}</Text>
    <Text style={styles.body}>{result.uncertainty}</Text>
    <Text style={styles.small}>{labels.strength}: {Math.round(result.confidence * 100)}/100 · Not statistically calibrated</Text>
    {result.indicators.map((indicator) => <View key={`${indicator.id}-${indicator.start}`} style={styles.indicator}><Text style={styles.indicatorLabel}>{indicator.label}</Text><Text style={styles.body}>{indicator.why}</Text></View>)}
    {result.entities.map((entity) => <Text key={`${entity.type}-${entity.start}`} style={styles.small}>{entity.type}: {entity.value}</Text>)}
    {result.recommended_actions.map((action) => <Text key={action} style={styles.action}>{action}</Text>)}
    {result.llm_status === 'not_configured' && <Text style={styles.small}>{labels.rulesOnly}</Text>}
  </View>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 52, paddingBottom: 46, gap: 14 },
  eyebrow: { color: '#ff987a', letterSpacing: 1.8, fontSize: 11, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 30, fontWeight: '300' },
  body: { color: '#aaa49b', lineHeight: 22 },
  privacy: { borderWidth: 1, borderColor: 'rgba(255,188,112,.27)', borderRadius: 14, backgroundColor: 'rgba(255,188,112,.07)', padding: 14 },
  privacyText: { color: '#dfc9aa', lineHeight: 20, fontSize: 13 },
  switcher: { flexDirection: 'row', padding: 4, borderRadius: 14, backgroundColor: '#171411', gap: 6, marginTop: 6 },
  switch: { flex: 1, alignItems: 'center', paddingVertical: 11, borderRadius: 11 },
  switchSelected: { backgroundColor: '#32221b' },
  switchText: { color: '#aaa49b', fontWeight: '600' },
  switchTextSelected: { color: '#ff987a' },
  label: { color: '#e7e3de', fontWeight: '600', marginTop: 3 },
  input: { backgroundColor: '#15120f', borderColor: 'rgba(255,255,255,.12)', borderWidth: 1, borderRadius: 15, minHeight: 52, paddingHorizontal: 14, paddingVertical: 13, color: '#f4f2ef', fontSize: 15 },
  messageInput: { minHeight: 145, textAlignVertical: 'top' },
  counter: { color: '#858078', fontSize: 12, textAlign: 'right', marginTop: -8 },
  saveToggle: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 },
  checkbox: { width: 19, height: 19, borderWidth: 1, borderColor: '#a39a90', borderRadius: 5 },
  checkboxSelected: { backgroundColor: '#ff8060', borderColor: '#ff8060' },
  saveText: { color: '#e5ded6', flex: 1, fontSize: 12 },
  saved: { color: '#a9dcba', fontSize: 12, lineHeight: 18 },
  button: { alignItems: 'center', justifyContent: 'center', minHeight: 48, borderRadius: 30, backgroundColor: '#ff8060', marginTop: 4 },
  buttonDisabled: { opacity: 0.55 },
  buttonText: { color: '#23120d', fontWeight: '700' },
  error: { color: '#ff9ba5', lineHeight: 21 },
  result: { borderWidth: 1, borderColor: 'rgba(255,255,255,.13)', borderRadius: 20, backgroundColor: '#15120f', padding: 17, gap: 12, marginTop: 8 },
  resultVerdict: { fontSize: 18, fontWeight: '700' },
  indicator: { borderLeftColor: '#ff987a', borderLeftWidth: 2, paddingLeft: 11, gap: 3 },
  indicatorLabel: { color: '#f4f2ef', fontWeight: '700' },
  action: { color: '#e8c7b9', lineHeight: 21 },
  small: { color: '#858078', fontSize: 12, lineHeight: 18 },
  disclaimer: { color: '#817b73', fontSize: 12, lineHeight: 18, marginTop: 5 },
});
