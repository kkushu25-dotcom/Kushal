import { Link } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../../locale/LanguageProvider';

const copy: Record<Language, {
  eyebrow: string; title: string; status: string; body: string; empty: string; note: string;
  language: string; scan: string; emergency: string; secure: string; disclaimer: string;
}> = {
  en: {
    eyebrow: 'ON-DEMAND SAFETY', title: 'Alerts', status: 'Push alerts are not enabled in this build.',
    body: 'ScamShield does not monitor SMS, WhatsApp, calls, or bank activity in the background. Device registration and alert delivery are not configured.',
    empty: 'No in-app alerts are available yet.',
    note: 'A scan gives an on-demand risk assessment. It does not create a confirmed fraud report or prove that content is safe.',
    language: 'Content language', scan: 'Start a scan', emergency: 'Open emergency steps', secure: 'Secure an account',
    disclaimer: 'ScamShield will not invent alerts or contact you about activity it cannot see.',
  },
  hi: {
    eyebrow: 'ज़रूरत पर सुरक्षा जाँच', title: 'अलर्ट', status: 'इस संस्करण में पुश अलर्ट चालू नहीं हैं।',
    body: 'ScamShield बैकग्राउंड में SMS, WhatsApp, कॉल या बैंक गतिविधि नहीं देखता। डिवाइस पंजीकरण और अलर्ट भेजना कॉन्फ़िगर नहीं है।',
    empty: 'अभी कोई इन-ऐप अलर्ट उपलब्ध नहीं है।',
    note: 'स्कैन ज़रूरत पर जोखिम का आकलन देता है। यह धोखाधड़ी की पुष्टि नहीं करता और न ही सामग्री को सुरक्षित साबित करता है।',
    language: 'सामग्री की भाषा', scan: 'स्कैन शुरू करें', emergency: 'आपातकालीन कदम खोलें', secure: 'खाता सुरक्षित करें',
    disclaimer: 'ScamShield मनगढ़ंत अलर्ट नहीं बनाएगा और ऐसी गतिविधि के बारे में संपर्क नहीं करेगा जिसे वह देख नहीं सकता।',
  },
  kn: {
    eyebrow: 'ಅಗತ್ಯವಿದ್ದಾಗ ಸುರಕ್ಷತಾ ಪರಿಶೀಲನೆ', title: 'ಎಚ್ಚರಿಕೆಗಳು', status: 'ಈ ಆವೃತ್ತಿಯಲ್ಲಿ ಪುಷ್ ಎಚ್ಚರಿಕೆಗಳು ಸಕ್ರಿಯವಾಗಿಲ್ಲ.',
    body: 'ScamShield ಹಿನ್ನೆಲೆಯಲ್ಲೇ SMS, WhatsApp, ಕರೆಗಳು ಅಥವಾ ಬ್ಯಾಂಕ್ ಚಟುವಟಿಕೆಯನ್ನು ಗಮನಿಸುವುದಿಲ್ಲ. ಸಾಧನ ನೋಂದಣಿ ಮತ್ತು ಎಚ್ಚರಿಕೆ ವಿತರಣೆ ಹೊಂದಿಸಲಾಗಿಲ್ಲ.',
    empty: 'ಇನ್ನೂ ಯಾವುದೇ ಆ್ಯಪ್‌ನೊಳಗಿನ ಎಚ್ಚರಿಕೆ ಲಭ್ಯವಿಲ್ಲ.',
    note: 'ಸ್ಕ್ಯಾನ್ ಅಗತ್ಯವಿದ್ದಾಗ ಅಪಾಯದ ಮೌಲ್ಯಮಾಪನ ನೀಡುತ್ತದೆ. ಇದು ವಂಚನೆಯನ್ನು ದೃಢೀಕರಿಸುವುದಿಲ್ಲ ಅಥವಾ ವಿಷಯ ಸುರಕ್ಷಿತವೆಂದು ಸಾಬೀತುಪಡಿಸುವುದಿಲ್ಲ.',
    language: 'ವಿಷಯದ ಭಾಷೆ', scan: 'ಸ್ಕ್ಯಾನ್ ಪ್ರಾರಂಭಿಸಿ', emergency: 'ತುರ್ತು ಹಂತಗಳನ್ನು ತೆರೆಯಿರಿ', secure: 'ಖಾತೆ ಸುರಕ್ಷಿತಗೊಳಿಸಿ',
    disclaimer: 'ScamShield ಕಲ್ಪಿತ ಎಚ್ಚರಿಕೆಗಳನ್ನು ರಚಿಸುವುದಿಲ್ಲ ಅಥವಾ ನೋಡಲಾಗದ ಚಟುವಟಿಕೆಯ ಬಗ್ಗೆ ನಿಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸುವುದಿಲ್ಲ.',
  },
};

export default function AlertsScreen() {
  const { language, changeLanguage } = useAppLanguage();
  const labels = copy[language];
  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Text style={styles.eyebrow}>{labels.eyebrow}</Text>
    <Text style={styles.title}>{labels.title}</Text>
    <Text style={styles.body}>{labels.body}</Text>
    <Text style={styles.label}>{labels.language}</Text>
    <View style={styles.languageRow}>
      {(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.languageButton, language === code && styles.languageSelected]}>
        <Text style={[styles.languageText, language === code && styles.languageTextSelected]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text>
      </Pressable>)}
    </View>
    <View style={styles.card}>
      <Text style={styles.status}>{labels.status}</Text>
      <Text style={styles.sectionTitle}>{labels.empty}</Text>
      <Text style={styles.body}>{labels.note}</Text>
    </View>
    <View style={styles.actions}>
      <Link href="/(tabs)/scan" asChild><Pressable accessibilityRole="button" style={styles.primary}><Text style={styles.primaryText}>{labels.scan}</Text></Pressable></Link>
      <Link href="/emergency" asChild><Pressable accessibilityRole="button" style={styles.secondary}><Text style={styles.link}>{labels.emergency}</Text></Pressable></Link>
      <Link href="/security-checklist" asChild><Pressable accessibilityRole="button" style={styles.secondary}><Text style={styles.link}>{labels.secure}</Text></Pressable></Link>
    </View>
    <Text style={styles.disclaimer}>{labels.disclaimer}</Text>
  </ScrollView>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 54, paddingBottom: 48, gap: 14 },
  eyebrow: { color: '#ff987a', letterSpacing: 1.4, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 30, fontWeight: '300' },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600' },
  languageRow: { flexDirection: 'row', gap: 8 },
  languageButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 22, backgroundColor: '#171411' },
  languageSelected: { borderWidth: 1, borderColor: '#ff987a', backgroundColor: '#32221b' },
  languageText: { color: '#aaa49b', fontSize: 12 },
  languageTextSelected: { color: '#ff987a', fontWeight: '700' },
  card: { padding: 17, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 12 },
  status: { color: '#ffcf8f', fontSize: 13, lineHeight: 19, fontWeight: '700' },
  sectionTitle: { color: '#f4f2ef', fontSize: 15, lineHeight: 21, fontWeight: '600' },
  actions: { gap: 8 },
  primary: { minHeight: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 25, backgroundColor: '#ff8060' },
  primaryText: { color: '#23120d', fontWeight: '700', fontSize: 13 },
  secondary: { minHeight: 46, alignItems: 'center', justifyContent: 'center', borderRadius: 24, borderWidth: 1, borderColor: 'rgba(255,174,155,.32)' },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  disclaimer: { color: '#817b73', fontSize: 10, lineHeight: 16 },
});
