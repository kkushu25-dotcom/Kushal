import { Link } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import type { SavedScan, SavedScanPage } from '@scamshield/api-client/types';
import emergency from '../../../../packages/content/emergency-resources.json';
import { useMobileAuth } from '../../auth/AuthProvider';
import { categoryDescription, categoryTitle, mobileCategories } from '../../navigation/catalog';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../../locale/LanguageProvider';

const homeCopy: Record<Language, { eyebrow: string; title: string; intro: string; language: string; heroTitle: string; heroBody: string; message: string; url: string; qr: string; urgent: string; urgentBody: string; emergency: string; explore: string; note: string }> = {
  en: { eyebrow: 'SCAMSHIELD', title: 'Your digital safety, one step at a time.', intro: 'Check suspicious messages and links before taking action. A scan is a risk assessment, never proof.', language: 'App content language', heroTitle: 'Take a closer look', heroBody: 'Paste a message or URL to see warning signs and safer next steps.', message: 'Scan message', url: 'Check URL', qr: 'Scan QR', urgent: 'Need urgent help?', urgentBody: "If money may be lost, contact your bank and call India's cyber fraud helpline.", emergency: 'View emergency steps →', explore: 'Explore ScamShield', note: 'ScamShield does not monitor messages or bank activity in the background.' },
  hi: { eyebrow: 'SCAMSHIELD', title: 'आपकी डिजिटल सुरक्षा, एक-एक कदम।', intro: 'कार्रवाई से पहले संदिग्ध संदेश और लिंक जाँचें। स्कैन जोखिम का आकलन है, प्रमाण नहीं।', language: 'ऐप की सामग्री की भाषा', heroTitle: 'ध्यान से जाँचें', heroBody: 'चेतावनी के संकेत और सुरक्षित अगले कदम देखने के लिए संदेश या URL डालें।', message: 'संदेश जाँचें', url: 'URL जाँचें', qr: 'QR जाँचें', urgent: 'तत्काल सहायता चाहिए?', urgentBody: 'पैसे का नुकसान हो सकता है तो अपने बैंक से संपर्क करें और भारत की साइबर धोखाधड़ी हेल्पलाइन पर कॉल करें।', emergency: 'आपातकालीन कदम देखें →', explore: 'ScamShield देखें', note: 'ScamShield बैकग्राउंड में संदेशों या बैंक गतिविधि की निगरानी नहीं करता।' },
  kn: { eyebrow: 'SCAMSHIELD', title: 'ನಿಮ್ಮ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತೆ, ಒಂದೊಂದು ಹಂತವಾಗಿ.', intro: 'ಕ್ರಮ ಕೈಗೊಳ್ಳುವ ಮೊದಲು ಅನುಮಾನಾಸ್ಪದ ಸಂದೇಶಗಳು ಮತ್ತು ಲಿಂಕ್‌ಗಳನ್ನು ಪರಿಶೀಲಿಸಿ. ಸ್ಕ್ಯಾನ್ ಅಪಾಯದ ಮೌಲ್ಯಮಾಪನ ಮಾತ್ರ; ಪುರಾವೆಯಲ್ಲ.', language: 'ಆ್ಯಪ್ ವಿಷಯದ ಭಾಷೆ', heroTitle: 'ಹತ್ತಿರದಿಂದ ಪರಿಶೀಲಿಸಿ', heroBody: 'ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಮತ್ತು ಸುರಕ್ಷಿತ ಮುಂದಿನ ಹಂತಗಳಿಗಾಗಿ ಸಂದೇಶ ಅಥವಾ URL ನಮೂದಿಸಿ.', message: 'ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ', url: 'URL ಪರಿಶೀಲಿಸಿ', qr: 'QR ಪರಿಶೀಲಿಸಿ', urgent: 'ತುರ್ತು ಸಹಾಯ ಬೇಕೇ?', urgentBody: 'ಹಣ ಕಳೆದುಹೋಗಿರಬಹುದು ಎಂದಾದರೆ ಬ್ಯಾಂಕ್ ಸಂಪರ್ಕಿಸಿ ಮತ್ತು ಭಾರತದ ಸೈಬರ್ ವಂಚನೆ ಸಹಾಯವಾಣಿಗೆ ಕರೆಮಾಡಿ.', emergency: 'ತುರ್ತು ಹಂತಗಳನ್ನು ನೋಡಿ →', explore: 'ScamShield ಅನ್ವೇಷಿಸಿ', note: 'ScamShield ಹಿನ್ನೆಲೆಯಲ್ಲೇ ಸಂದೇಶಗಳು ಅಥವಾ ಬ್ಯಾಂಕ್ ಚಟುವಟಿಕೆಯನ್ನು ಗಮನಿಸುವುದಿಲ್ಲ.' },
};
const homeDataCopy: Record<Language, { recent: string; noRecent: string; guest: string; showHistory: string; checklist: string; money: string; account: string; steps: string; unavailable: string }> = {
  en: { recent: 'Recent saved scans', noRecent: 'No assessment summaries saved yet.', guest: 'Guest scans are not stored. Sign in and opt in to history to see saved summaries here.', showHistory: 'View full history →', checklist: 'Emergency checklist progress', money: 'Money may be lost', account: 'Account may be hacked', steps: 'steps complete', unavailable: 'On-device progress is unavailable.' },
  hi: { recent: 'हाल के सहेजे गए स्कैन', noRecent: 'अभी कोई आकलन सारांश नहीं सहेजा गया।', guest: 'मेहमान के स्कैन सहेजे नहीं जाते। यहाँ सारांश देखने के लिए साइन इन करें और इतिहास सहेजने की अनुमति दें।', showHistory: 'पूरा इतिहास देखें →', checklist: 'आपातकालीन चेकलिस्ट की प्रगति', money: 'पैसे का नुकसान हो सकता है', account: 'खाता हैक हो सकता है', steps: 'कदम पूरे', unavailable: 'डिवाइस पर प्रगति उपलब्ध नहीं है।' },
  kn: { recent: 'ಇತ್ತೀಚಿನ ಉಳಿಸಿದ ಸ್ಕ್ಯಾನ್‌ಗಳು', noRecent: 'ಇನ್ನೂ ಯಾವುದೇ ಮೌಲ್ಯಮಾಪನ ಸಾರಾಂಶ ಉಳಿಸಿಲ್ಲ.', guest: 'ಅತಿಥಿ ಸ್ಕ್ಯಾನ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ. ಇಲ್ಲಿ ಸಾರಾಂಶ ನೋಡಲು ಸೈನ್ ಇನ್ ಮಾಡಿ ಮತ್ತು ಇತಿಹಾಸ ಉಳಿಸಲು ಆಯ್ಕೆಮಾಡಿ.', showHistory: 'ಪೂರ್ಣ ಇತಿಹಾಸ ನೋಡಿ →', checklist: 'ತುರ್ತು ಪರಿಶೀಲನಾ ಪಟ್ಟಿಯ ಪ್ರಗತಿ', money: 'ಹಣ ಕಳೆದುಹೋಗಿರಬಹುದು', account: 'ಖಾತೆ ಹ್ಯಾಕ್ ಆಗಿರಬಹುದು', steps: 'ಹಂತಗಳು ಪೂರ್ಣ', unavailable: 'ಸಾಧನದ ಪ್ರಗತಿ ಲಭ್ಯವಿಲ್ಲ.' },
};
export default function HomeScreen() {
  const { language, changeLanguage } = useAppLanguage();
  const labels = homeCopy[language];
  return <ScrollView style={styles.page} contentContainerStyle={styles.content}>
    <Text style={styles.eyebrow}>{labels.eyebrow}</Text>
    <Text style={styles.title}>{labels.title}</Text>
    <Text style={styles.body}>{labels.intro}</Text>
    <Text style={styles.label}>{labels.language}</Text>
    <View style={styles.languageRow}>{(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.languageButton, language === code && styles.languageSelected]}><Text style={[styles.languageText, language === code && styles.languageTextSelected]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text></Pressable>)}</View>
    <View style={styles.hero}><Text style={styles.heroTitle}>{labels.heroTitle}</Text><Text style={styles.body}>{labels.heroBody}</Text><View style={styles.quickActions}>
      <Link href={{ pathname: '/(tabs)/scan', params: { mode: 'message' } }} asChild><Pressable accessibilityRole="button" style={styles.quickAction}><Text style={styles.quickActionText}>{labels.message}</Text></Pressable></Link>
      <Link href={{ pathname: '/(tabs)/scan', params: { mode: 'url' } }} asChild><Pressable accessibilityRole="button" style={styles.quickAction}><Text style={styles.quickActionText}>{labels.url}</Text></Pressable></Link>
      <Link href={{ pathname: '/(tabs)/scan', params: { mode: 'qr' } }} asChild><Pressable accessibilityRole="button" style={styles.quickAction}><Text style={styles.quickActionText}>{labels.qr}</Text></Pressable></Link>
    </View></View>
    <View style={styles.emergency}><Text style={styles.sectionTitle}>{labels.urgent}</Text><Text style={styles.body}>{labels.urgentBody}</Text><Link href="/emergency" style={styles.link}>{labels.emergency}</Link></View>
    <RecentSavedScans language={language} />
    <EmergencyProgress language={language} />
    <Text style={styles.sectionTitle}>{labels.explore}</Text>
    <View style={styles.categoryGrid}>
      {mobileCategories.map((category) => <Link key={category.slug} href={{ pathname: '/category/[slug]', params: { slug: category.slug } }} asChild>
        <Pressable accessibilityRole="button" style={styles.categoryTile}><Text style={styles.categoryTitle}>{categoryTitle(category, language)}</Text><Text style={styles.categoryDescription}>{categoryDescription(category, language)}</Text></Pressable>
      </Link>)}
    </View>
    <Text style={styles.note}>{labels.note}</Text>
  </ScrollView>;
}

function RecentSavedScans({ language }: { language: Language }) {
  const { ready, session, authorizedFetch } = useMobileAuth();
  const [items, setItems] = useState<SavedScan[]>([]);
  const [loadedUserId, setLoadedUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const copy = homeDataCopy[language];

  useEffect(() => {
    let mounted = true;
    if (!ready || !session) {
      setItems([]);
      setLoadedUserId(null);
      setLoading(false);
      setError('');
      return () => { mounted = false; };
    }
    setItems([]);
    setLoadedUserId(null);
    setLoading(true);
    setError('');
    const userId = session.user.id;
    void authorizedFetch('/scans?limit=3').then(async (response) => {
      const result = await response.json() as SavedScanPage & { detail?: string };
      if (!response.ok) throw new Error(result.detail ?? `Request failed (${response.status})`);
      if (mounted) {
        setItems(result.items);
        setLoadedUserId(userId);
      }
    }).catch((cause: unknown) => {
      if (mounted) {
        setError(cause instanceof Error ? cause.message : 'Could not load saved scan summaries.');
        setLoadedUserId(userId);
      }
    }).finally(() => {
      if (mounted) setLoading(false);
    });
    return () => { mounted = false; };
  }, [authorizedFetch, ready, session?.user.id]);

  return <View style={styles.homeCard}>
    <Text style={styles.homeCardTitle}>{copy.recent}</Text>
    {!ready || loading || (session && loadedUserId !== session.user.id && !error) ? <ActivityIndicator color="#ff987a" /> : !session ? <Text style={styles.homeSmall}>{copy.guest}</Text> : error ? <Text accessibilityRole="alert" style={styles.homeError}>{error}</Text> : items.length === 0 ? <Text style={styles.homeSmall}>{copy.noRecent}</Text> : items.map((item) => <View key={item.id} style={styles.recentRow}>
      <Text style={styles.recentTitle}>{item.scan_type === 'message' ? (language === 'hi' ? 'संदेश' : language === 'kn' ? 'ಸಂದೇಶ' : 'Message') : (language === 'hi' ? 'लिंक' : language === 'kn' ? 'ಲಿಂಕ್' : 'Link')} · {item.verdict}</Text>
      <Text style={styles.homeSmall}>{item.category ?? '—'} · {new Date(item.created_at).toLocaleDateString()}</Text>
    </View>)}
    {session && <Link href="/(tabs)/profile" style={styles.link}>{copy.showHistory}</Link>}
  </View>;
}

function completedCount(value: string | null, stepsCount: number): number {
  if (!value) return 0;
  try {
    const parsed: unknown = JSON.parse(value);
    if (!parsed || typeof parsed !== 'object') return 0;
    const completed = (parsed as { completed?: unknown }).completed;
    return Array.isArray(completed) ? new Set(completed.filter((index) => Number.isInteger(index) && index >= 0 && index < stepsCount)).size : 0;
  } catch {
    return 0;
  }
}

function EmergencyProgress({ language }: { language: Language }) {
  const [progress, setProgress] = useState<{ money: number; account: number } | null | undefined>(undefined);
  const copy = homeDataCopy[language];
  useEffect(() => {
    let mounted = true;
    void Promise.all([
      SecureStore.getItemAsync('scamshield.mobile.emergency.v1.money'),
      SecureStore.getItemAsync('scamshield.mobile.emergency.v1.account'),
    ]).then(([money, account]) => {
      if (mounted) setProgress({ money: completedCount(money, emergency.steps.en.length), account: completedCount(account, emergency.accountHacked.en.length) });
    }).catch(() => {
      if (mounted) setProgress(null);
    });
    return () => { mounted = false; };
  }, []);

  return <View style={styles.homeCard}>
    <Text style={styles.homeCardTitle}>{copy.checklist}</Text>
    {progress === undefined ? <ActivityIndicator color="#ff987a" /> : progress === null ? <Text style={styles.homeSmall}>{copy.unavailable}</Text> : <>
      <Link href={{ pathname: '/emergency', params: { topic: 'money' } }} asChild><Pressable accessibilityRole="button" style={styles.progressRow}><Text style={styles.homeSmall}>{copy.money}</Text><Text style={styles.progressCount}>{progress.money}/{emergency.steps.en.length} {copy.steps}</Text></Pressable></Link>
      <Link href={{ pathname: '/emergency', params: { topic: 'account' } }} asChild><Pressable accessibilityRole="button" style={styles.progressRow}><Text style={styles.homeSmall}>{copy.account}</Text><Text style={styles.progressCount}>{progress.account}/{emergency.accountHacked.en.length} {copy.steps}</Text></Pressable></Link>
    </>}
  </View>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 54, gap: 17 },
  eyebrow: { color: '#ff987a', letterSpacing: 2, fontSize: 11, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 32, lineHeight: 38, fontWeight: '300' },
  body: { color: '#aaa49b', lineHeight: 22 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600' },
  languageRow: { flexDirection: 'row', gap: 8 },
  languageButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 12, borderRadius: 22, backgroundColor: '#171411' },
  languageSelected: { borderWidth: 1, borderColor: '#ff987a', backgroundColor: '#32221b' },
  languageText: { color: '#aaa49b', fontSize: 12 },
  languageTextSelected: { color: '#ff987a', fontWeight: '700' },
  hero: { padding: 20, borderRadius: 24, backgroundColor: '#16110e', borderColor: 'rgba(255,255,255,.1)', borderWidth: 1, gap: 12 },
  heroTitle: { color: '#f4f2ef', fontSize: 20 },
  quickActions: { flexDirection: 'row', gap: 7, marginTop: 2 },
  quickAction: { flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5, borderRadius: 23, backgroundColor: '#ff8060' },
  quickActionText: { color: '#23120d', fontSize: 10, fontWeight: '700', textAlign: 'center' },
  emergency: { padding: 19, borderRadius: 20, backgroundColor: 'rgba(255,93,108,.12)', borderColor: 'rgba(255,93,108,.3)', borderWidth: 1, gap: 10 },
  sectionTitle: { color: '#ff9aa4', fontSize: 18, fontWeight: '600' },
  link: { color: '#ffae9b', fontWeight: '600' },
  homeCard: { padding: 16, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 10 },
  homeCardTitle: { color: '#f4f2ef', fontSize: 14, lineHeight: 20, fontWeight: '600' },
  homeSmall: { color: '#aaa49b', fontSize: 11, lineHeight: 17 },
  homeError: { color: '#ff9ba5', fontSize: 12, lineHeight: 18 },
  recentRow: { gap: 3, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,.06)' },
  recentTitle: { color: '#e9e3dc', fontSize: 12, fontWeight: '600' },
  progressRow: { minHeight: 44, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  progressCount: { color: '#ffae9b', fontSize: 10, fontWeight: '600' },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 9 },
  categoryTile: { width: '48%', minHeight: 110, padding: 13, justifyContent: 'center', gap: 6, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f' },
  categoryTitle: { color: '#f4f2ef', fontSize: 13, fontWeight: '700' },
  categoryDescription: { color: '#938d84', fontSize: 10, lineHeight: 15 },
  note: { color: '#79756f', fontSize: 12, lineHeight: 18, paddingBottom: 20 },
});

