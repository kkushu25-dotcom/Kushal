import { Tabs } from 'expo-router';
import { Home, ScanLine, BookOpen, Bell, UserRound } from 'lucide-react-native';
import type { Language } from '@scamshield/api-client/types';
import { useAppLanguage } from '../../locale/LanguageProvider';

const palette = { active: '#ff805d', inactive: '#aaa49b', background: '#100e0c' };
const tabTitles: Record<Language, { home: string; scan: string; learn: string; alerts: string; profile: string }> = {
  en: { home: 'Home', scan: 'Scan', learn: 'Learn', alerts: 'Alerts', profile: 'Profile' },
  hi: { home: 'होम', scan: 'जाँचें', learn: 'सीखें', alerts: 'अलर्ट', profile: 'प्रोफ़ाइल' },
  kn: { home: 'ಮುಖಪುಟ', scan: 'ಪರಿಶೀಲಿಸಿ', learn: 'ಕಲಿಯಿರಿ', alerts: 'ಎಚ್ಚರಿಕೆಗಳು', profile: 'ಪ್ರೊಫೈಲ್' },
};

export default function TabLayout() {
  const { language } = useAppLanguage();
  const titles = tabTitles[language];
  return <Tabs screenOptions={{ headerShown: false, tabBarStyle: { backgroundColor: palette.background, borderTopColor: 'rgba(255,255,255,.1)' }, tabBarActiveTintColor: palette.active, tabBarInactiveTintColor: palette.inactive }}>
    <Tabs.Screen name="index" options={{ title: titles.home, tabBarIcon: ({ color }) => <Home color={color} size={19} /> }} />
    <Tabs.Screen name="scan" options={{ title: titles.scan, tabBarIcon: ({ color }) => <ScanLine color={color} size={19} /> }} />
    <Tabs.Screen name="learn" options={{ title: titles.learn, tabBarIcon: ({ color }) => <BookOpen color={color} size={19} /> }} />
    <Tabs.Screen name="alerts" options={{ title: titles.alerts, tabBarIcon: ({ color }) => <Bell color={color} size={19} /> }} />
    <Tabs.Screen name="profile" options={{ title: titles.profile, tabBarIcon: ({ color }) => <UserRound color={color} size={19} /> }} />
  </Tabs>;
}

