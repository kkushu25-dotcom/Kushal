import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Link } from 'expo-router';
import type { Language, SavedScan, SavedScanPage } from '@scamshield/api-client/types';
import { useMobileAuth } from '../../auth/AuthProvider';
import { useAppLanguage } from '../../locale/LanguageProvider';

type FormMode = 'login' | 'register' | 'reset';
const profileCopy: Record<Language, { eyebrow: string; title: string; securityTitle: string; securityBody: string; language: string; languageUnavailable: string; checking: string; signedIn: string; tokenInfo: string; signOut: string; deleteData: string; deleteTitle: string; deleteBody: string; cancel: string; delete: string; resetIntro: string; guestIntro: string; signIn: string; create: string; resetLabel: string; email: string; password: string; emailPlaceholder: string; newPassword: string; currentPassword: string; showPassword: string; hidePassword: string; passwordHint: string; resetSent: string; createAction: string; sendReset: string; forgot: string; backToSignIn: string; tokenHint: string; footer: string; invalidEmail: string; shortPassword: string; passwordRequired: string; submitFailed: string; signOutFailed: string; deleteFailed: string }> = {
  en: { eyebrow: 'ACCOUNT AND PRIVACY', title: 'Profile', securityTitle: 'Secure My Account', securityBody: 'Open a saved, on-device checklist with links to official account-security guidance.', language: 'App content language', languageUnavailable: 'Language will stay selected only while this app is open because secure storage is unavailable.', checking: 'Checking your account…', signedIn: 'Signed in as', tokenInfo: 'Your refresh token is stored in device secure storage. The short-lived access token stays in memory.', signOut: 'Sign out', deleteData: 'Delete account and saved data', deleteTitle: 'Delete your account?', deleteBody: 'This permanently deletes your profile and saved assessment summaries, and signs out this device.', cancel: 'Cancel', delete: 'Delete account', resetIntro: 'Request a one-time password reset link. If your account exists and email delivery is enabled, instructions will be sent.', guestIntro: 'Use an account to access private features. Guest scans remain available without signing in.', signIn: 'Sign in', create: 'Create account', resetLabel: 'Reset your password', email: 'Email', password: 'Password', emailPlaceholder: 'you@example.com', newPassword: 'At least 12 characters', currentPassword: 'Your password', showPassword: 'Show password', hidePassword: 'Hide password', passwordHint: 'Use 12–128 characters. ScamShield will not ask for your OTP, UPI PIN, CVV, or banking password.', resetSent: 'If an account with that email exists and reset email is enabled, a one-time link was sent. Open it on this device to choose a new password.', createAction: 'Create account', sendReset: 'Send reset link', forgot: 'Forgot password?', backToSignIn: 'Back to sign in', tokenHint: 'Access tokens stay in memory. The rotating refresh token is kept in the device’s secure storage.', footer: 'ScamShield does not monitor your messages or accounts in the background.', invalidEmail: 'Enter a valid email address.', shortPassword: 'Use at least 12 characters for a new password.', passwordRequired: 'Enter your password.', submitFailed: 'We could not complete sign-in. Try again.', signOutFailed: 'Could not finish signing out on this device.', deleteFailed: 'Could not delete this account. Try again.' },
  hi: { eyebrow: 'खाता और गोपनीयता', title: 'प्रोफ़ाइल', securityTitle: 'मेरा खाता सुरक्षित करें', securityBody: 'आधिकारिक खाता-सुरक्षा मार्गदर्शन के लिंक वाली डिवाइस पर सहेजी गई चेकलिस्ट खोलें।', language: 'ऐप की सामग्री की भाषा', languageUnavailable: 'सुरक्षित स्टोरेज उपलब्ध नहीं है, इसलिए भाषा केवल ऐप खुला रहने तक चुनी रहेगी।', checking: 'आपका खाता जाँचा जा रहा है…', signedIn: 'इस खाते से साइन इन', tokenInfo: 'रीफ़्रेश टोकन डिवाइस के सुरक्षित स्टोरेज में रहता है। थोड़े समय का एक्सेस टोकन केवल मेमोरी में रहता है।', signOut: 'साइन आउट', deleteData: 'खाता और सहेजा डेटा हटाएँ', deleteTitle: 'खाता हटाएँ?', deleteBody: 'इससे आपकी प्रोफ़ाइल और सहेजे गए आकलन सारांश स्थायी रूप से हटेंगे और यह डिवाइस साइन आउट हो जाएगा।', cancel: 'रद्द करें', delete: 'खाता हटाएँ', resetIntro: 'एक बार उपयोग होने वाला पासवर्ड रीसेट लिंक माँगें। यदि खाता मौजूद है और ईमेल भेजना चालू है, तो निर्देश भेजे जाएँगे।', guestIntro: 'निजी सुविधाओं के लिए खाते का उपयोग करें। मेहमान के स्कैन बिना साइन इन के भी उपलब्ध हैं।', signIn: 'साइन इन', create: 'खाता बनाएँ', resetLabel: 'पासवर्ड रीसेट करें', email: 'ईमेल', password: 'पासवर्ड', emailPlaceholder: 'you@example.com', newPassword: 'कम से कम 12 अक्षर', currentPassword: 'आपका पासवर्ड', showPassword: 'पासवर्ड दिखाएँ', hidePassword: 'पासवर्ड छिपाएँ', passwordHint: '12–128 अक्षर रखें। ScamShield आपसे OTP, UPI PIN, CVV या बैंकिंग पासवर्ड नहीं माँगेगा।', resetSent: 'यदि इस ईमेल का खाता मौजूद है और रीसेट ईमेल चालू है, तो एक बार का लिंक भेजा गया। नया पासवर्ड चुनने के लिए इसे इसी डिवाइस पर खोलें।', createAction: 'खाता बनाएँ', sendReset: 'रीसेट लिंक भेजें', forgot: 'पासवर्ड भूल गए?', backToSignIn: 'साइन इन पर वापस जाएँ', tokenHint: 'एक्सेस टोकन मेमोरी में रहते हैं। बदलता हुआ रीफ़्रेश टोकन डिवाइस के सुरक्षित स्टोरेज में रखा जाता है।', footer: 'ScamShield बैकग्राउंड में आपके संदेशों या खातों की निगरानी नहीं करता।', invalidEmail: 'मान्य ईमेल पता दर्ज करें।', shortPassword: 'नए पासवर्ड में कम से कम 12 अक्षर रखें।', passwordRequired: 'अपना पासवर्ड दर्ज करें।', submitFailed: 'साइन इन पूरा नहीं हो सका। फिर से कोशिश करें।', signOutFailed: 'इस डिवाइस पर साइन आउट पूरा नहीं हो सका।', deleteFailed: 'खाता हटाया नहीं जा सका। फिर से कोशिश करें।' },
  kn: { eyebrow: 'ಖಾತೆ ಮತ್ತು ಗೌಪ್ಯತೆ', title: 'ಪ್ರೊಫೈಲ್', securityTitle: 'ನನ್ನ ಖಾತೆ ಸುರಕ್ಷಿತಗೊಳಿಸಿ', securityBody: 'ಅಧಿಕೃತ ಖಾತೆ ಸುರಕ್ಷತಾ ಮಾರ್ಗದರ್ಶನದ ಲಿಂಕ್‌ಗಳಿರುವ ಸಾಧನದಲ್ಲೇ ಉಳಿಸಿದ ಪಟ್ಟಿಯನ್ನು ತೆರೆಯಿರಿ.', language: 'ಆ್ಯಪ್ ವಿಷಯದ ಭಾಷೆ', languageUnavailable: 'ಸುರಕ್ಷಿತ ಸಂಗ್ರಹಣೆ ಲಭ್ಯವಿಲ್ಲದ ಕಾರಣ ಆ್ಯಪ್ ತೆರೆದಿರುವಾಗ ಮಾತ್ರ ಭಾಷೆ ಆಯ್ಕೆ ಉಳಿಯುತ್ತದೆ.', checking: 'ನಿಮ್ಮ ಖಾತೆ ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ…', signedIn: 'ಈ ಖಾತೆಯಾಗಿ ಸೈನ್ ಇನ್ ಆಗಿದೆ', tokenInfo: 'ರಿಫ್ರೆಶ್ ಟೋಕನ್ ಸಾಧನದ ಸುರಕ್ಷಿತ ಸಂಗ್ರಹಣೆಯಲ್ಲಿರುತ್ತದೆ. ಅಲ್ಪಾವಧಿಯ ಆಕ್ಸೆಸ್ ಟೋಕನ್ ಮೆಮೊರಿಯಲ್ಲಿ ಮಾತ್ರ ಇರುತ್ತದೆ.', signOut: 'ಸೈನ್ ಔಟ್', deleteData: 'ಖಾತೆ ಮತ್ತು ಉಳಿಸಿದ ಡೇಟಾ ಅಳಿಸಿ', deleteTitle: 'ನಿಮ್ಮ ಖಾತೆ ಅಳಿಸಬೇಕೇ?', deleteBody: 'ಇದು ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಮತ್ತು ಉಳಿಸಿದ ಮೌಲ್ಯಮಾಪನ ಸಾರಾಂಶಗಳನ್ನು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿ, ಈ ಸಾಧನದಿಂದ ಸೈನ್ ಔಟ್ ಮಾಡುತ್ತದೆ.', cancel: 'ರದ್ದುಮಾಡಿ', delete: 'ಖಾತೆ ಅಳಿಸಿ', resetIntro: 'ಒಮ್ಮೆ ಮಾತ್ರ ಬಳಸಬಹುದಾದ ಪಾಸ್‌ವರ್ಡ್ ಮರುಹೊಂದಿಕೆ ಲಿಂಕ್ ಕೇಳಿ. ಖಾತೆ ಇದ್ದು ಇಮೇಲ್ ಸಕ್ರಿಯವಾಗಿದ್ದರೆ ಸೂಚನೆ ಕಳುಹಿಸಲಾಗುತ್ತದೆ.', guestIntro: 'ಖಾಸಗಿ ವೈಶಿಷ್ಟ್ಯಗಳಿಗಾಗಿ ಖಾತೆ ಬಳಸಿ. ಸೈನ್ ಇನ್ ಮಾಡದೆಯೂ ಅತಿಥಿ ಸ್ಕ್ಯಾನ್ ಲಭ್ಯವಿದೆ.', signIn: 'ಸೈನ್ ಇನ್', create: 'ಖಾತೆ ರಚಿಸಿ', resetLabel: 'ಪಾಸ್‌ವರ್ಡ್ ಮರುಹೊಂದಿಸಿ', email: 'ಇಮೇಲ್', password: 'ಪಾಸ್‌ವರ್ಡ್', emailPlaceholder: 'you@example.com', newPassword: 'ಕನಿಷ್ಠ 12 ಅಕ್ಷರಗಳು', currentPassword: 'ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್', showPassword: 'ಪಾಸ್‌ವರ್ಡ್ ತೋರಿಸಿ', hidePassword: 'ಪಾಸ್‌ವರ್ಡ್ ಮರೆಮಾಡಿ', passwordHint: '12–128 ಅಕ್ಷರ ಬಳಸಿ. ScamShield ನಿಮ್ಮ OTP, UPI PIN, CVV ಅಥವಾ ಬ್ಯಾಂಕಿಂಗ್ ಪಾಸ್‌ವರ್ಡ್ ಕೇಳುವುದಿಲ್ಲ.', resetSent: 'ಈ ಇಮೇಲ್‌ಗೆ ಖಾತೆ ಇದ್ದು ಮರುಹೊಂದಿಕೆ ಇಮೇಲ್ ಸಕ್ರಿಯವಾಗಿದ್ದರೆ, ಒಮ್ಮೆ ಬಳಸುವ ಲಿಂಕ್ ಕಳುಹಿಸಲಾಗಿದೆ. ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ ಆಯ್ಕೆ ಮಾಡಲು ಈ ಸಾಧನದಲ್ಲೇ ತೆರೆಯಿರಿ.', createAction: 'ಖಾತೆ ರಚಿಸಿ', sendReset: 'ಮರುಹೊಂದಿಕೆ ಲಿಂಕ್ ಕಳುಹಿಸಿ', forgot: 'ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ?', backToSignIn: 'ಸೈನ್ ಇನ್‌ಗೆ ಹಿಂತಿರುಗಿ', tokenHint: 'ಆಕ್ಸೆಸ್ ಟೋಕನ್ ಮೆಮೊರಿಯಲ್ಲೇ ಇರುತ್ತವೆ. ಬದಲಾಗುವ ರಿಫ್ರೆಶ್ ಟೋಕನ್ ಸಾಧನದ ಸುರಕ್ಷಿತ ಸಂಗ್ರಹಣೆಯಲ್ಲಿ ಇರುತ್ತದೆ.', footer: 'ScamShield ಹಿನ್ನೆಲೆಯಲ್ಲೇ ನಿಮ್ಮ ಸಂದೇಶಗಳು ಅಥವಾ ಖಾತೆಗಳನ್ನು ಗಮನಿಸುವುದಿಲ್ಲ.', invalidEmail: 'ಸರಿಯಾದ ಇಮೇಲ್ ವಿಳಾಸ ನಮೂದಿಸಿ.', shortPassword: 'ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ ಕನಿಷ್ಠ 12 ಅಕ್ಷರ ಇರಲಿ.', passwordRequired: 'ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ.', submitFailed: 'ಸೈನ್ ಇನ್ ಪೂರ್ಣಗೊಳ್ಳಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.', signOutFailed: 'ಈ ಸಾಧನದಿಂದ ಸೈನ್ ಔಟ್ ಪೂರ್ಣಗೊಳಿಸಲಾಗಲಿಲ್ಲ.', deleteFailed: 'ಈ ಖಾತೆ ಅಳಿಸಲಾಗಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.' },
};

export default function ProfileScreen() {
  const { ready, session, error: sessionError, login, register, logout, deleteAccount, requestPasswordReset } = useMobileAuth();
  const { language, changeLanguage, persistenceUnavailable } = useAppLanguage();
  const copy = profileCopy[language];
  const [mode, setMode] = useState<FormMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resetRequested, setResetRequested] = useState(false);

  async function submit(): Promise<void> {
    const normalizedEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      setError(copy.invalidEmail);
      return;
    }
    if (mode === 'register' && password.length < 12) {
      setError(copy.shortPassword);
      return;
    }
    if (mode !== 'reset' && !password) {
      setError(copy.passwordRequired);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      if (mode === 'reset') {
        await requestPasswordReset(normalizedEmail);
        setResetRequested(true);
      } else {
        if (mode === 'register') await register(normalizedEmail, password, language);
        else await login(normalizedEmail, password);
        setPassword('');
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : copy.submitFailed);
    } finally {
      setBusy(false);
    }
  }

  async function signOut(): Promise<void> {
    setBusy(true);
    setError(null);
    try {
      await logout();
      setEmail('');
      setPassword('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : copy.signOutFailed);
    } finally {
      setBusy(false);
    }
  }

  function confirmDeleteAccount(): void {
    Alert.alert(
      copy.deleteTitle,
      copy.deleteBody,
      [
        { text: copy.cancel, style: 'cancel' },
        {
          text: copy.delete,
          style: 'destructive',
          onPress: () => { void performDeleteAccount(); },
        },
      ],
    );
  }

  async function performDeleteAccount(): Promise<void> {
    setBusy(true);
    setError(null);
    try {
      await deleteAccount();
      setEmail('');
      setPassword('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : copy.deleteFailed);
    } finally {
      setBusy(false);
    }
  }

  return <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.eyebrow}>{copy.eyebrow}</Text>
    <Text style={styles.title}>{copy.title}</Text>
    <Link href="/security-checklist" asChild>
      <Pressable accessibilityRole="button" style={styles.securityLink}>
        <Text style={styles.securityTitle}>{copy.securityTitle}</Text>
        <Text style={styles.small}>{copy.securityBody}</Text>
      </Pressable>
    </Link>
    <View style={styles.languagePanel}>
      <Text style={styles.label}>{copy.language}</Text>
      <View style={styles.languageRow}>{(['en', 'hi', 'kn'] as const).map((code) => <Pressable key={code} accessibilityRole="button" accessibilityState={{ selected: language === code }} onPress={() => { void changeLanguage(code); }} style={[styles.languageButton, language === code && styles.modeSelected]}><Text style={[styles.modeText, language === code && styles.modeTextSelected]}>{code === 'en' ? 'English' : code === 'hi' ? 'हिन्दी' : 'ಕನ್ನಡ'}</Text></Pressable>)}</View>
      {persistenceUnavailable && <Text accessibilityRole="alert" style={styles.small}>{copy.languageUnavailable}</Text>}
    </View>
    {!ready ? <View style={styles.loading}><ActivityIndicator color="#ff987a" /><Text style={styles.body}>{copy.checking}</Text></View> : session ? <View style={styles.card}>
      <Text style={styles.label}>{copy.signedIn}</Text>
      <Text selectable style={styles.email}>{session.user.email}</Text>
      <Text style={styles.body}>{copy.tokenInfo}</Text>
      {(error || sessionError) && <Text accessibilityRole="alert" style={styles.error}>{error ?? sessionError}</Text>}
      <Pressable accessibilityRole="button" disabled={busy} onPress={() => { void signOut(); }} style={[styles.button, busy && styles.disabled]}>
        {busy ? <ActivityIndicator color="#23120d" /> : <Text style={styles.buttonText}>{copy.signOut}</Text>}
      </Pressable>
      <Pressable accessibilityRole="button" disabled={busy} onPress={confirmDeleteAccount} style={styles.deleteAccountButton}>
        <Text style={styles.deleteText}>{copy.deleteData}</Text>
      </Pressable>
      <AccountHistory language={language} />
    </View> : <View style={styles.card}>
      <Text style={styles.body}>{mode === 'reset' ? copy.resetIntro : copy.guestIntro}</Text>
      {sessionError && <Text accessibilityRole="alert" style={styles.error}>{sessionError}</Text>}
      {mode !== 'reset' && <View style={styles.modeRow} accessibilityRole="tablist">
        {(['login', 'register'] as const).map((item) => <Pressable key={item} accessibilityRole="tab" accessibilityState={{ selected: mode === item }} onPress={() => { setMode(item); setError(null); }} style={[styles.modeButton, mode === item && styles.modeSelected]}><Text style={[styles.modeText, mode === item && styles.modeTextSelected]}>{item === 'login' ? copy.signIn : copy.create}</Text></Pressable>)}
      </View>}
      {mode === 'reset' && <Text style={styles.label}>{copy.resetLabel}</Text>}
      <Text style={styles.label}>{copy.email}</Text>
      <TextInput
        value={email}
        onChangeText={setEmail}
        placeholder={copy.emailPlaceholder}
        placeholderTextColor="#77716a"
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        autoComplete="email"
        textContentType="emailAddress"
        accessibilityLabel={copy.email}
        style={styles.input}
      />
      {mode !== 'reset' && <>
      <Text style={styles.label}>{copy.password}</Text>
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder={mode === 'register' ? copy.newPassword : copy.currentPassword}
        placeholderTextColor="#77716a"
        secureTextEntry={!showPassword}
        autoCapitalize="none"
        autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
        textContentType={mode === 'register' ? 'newPassword' : 'password'}
        accessibilityLabel={copy.password}
        style={styles.input}
      />
      <Pressable accessibilityRole="button" accessibilityState={{ selected: showPassword }} onPress={() => setShowPassword((value) => !value)} style={styles.showPassword}>
        <Text style={styles.link}>{showPassword ? copy.hidePassword : copy.showPassword}</Text>
      </Pressable>
      </>}
      {mode === 'register' && <Text style={styles.small}>{copy.passwordHint}</Text>}
      {mode === 'reset' && resetRequested && <Text accessibilityRole="alert" style={styles.saved}>{copy.resetSent}</Text>}
      {error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
      {!resetRequested && <Pressable accessibilityRole="button" disabled={busy} onPress={() => { void submit(); }} style={[styles.button, busy && styles.disabled]}>
        {busy ? <ActivityIndicator color="#23120d" /> : <Text style={styles.buttonText}>{mode === 'register' ? copy.createAction : mode === 'reset' ? copy.sendReset : copy.signIn}</Text>}
      </Pressable>}
      {mode === 'login' && <Pressable accessibilityRole="button" onPress={() => { setMode('reset'); setError(null); setResetRequested(false); }} style={styles.showPassword}><Text style={styles.link}>{copy.forgot}</Text></Pressable>}
      {mode === 'reset' && <Pressable accessibilityRole="button" onPress={() => { setMode('login'); setError(null); setResetRequested(false); }} style={styles.showPassword}><Text style={styles.link}>{copy.backToSignIn}</Text></Pressable>}
      {mode !== 'reset' && <Text style={styles.small}>{copy.tokenHint}</Text>}
    </View>}
    <Text style={styles.footer}>{copy.footer}</Text>
  </ScrollView>;
}

function AccountHistory({ language }: { language: Language }) {
  const { authorizedFetch } = useMobileAuth();
  const [items, setItems] = useState<SavedScan[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [pageLoading, setPageLoading] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadPage = useCallback(async (cursor?: string) => {
    cursor ? setPageLoading(true) : setLoading(true);
    setError(null);
    try {
      const query = new URLSearchParams({ limit: '20' });
      if (cursor) query.set('cursor', cursor);
      const response = await authorizedFetch(`/scans?${query.toString()}`);
      const body = await response.json() as SavedScanPage & { detail?: string };
      if (!response.ok) throw new Error(body.detail ?? `Request failed (${response.status})`);
      setItems((prior) => cursor ? [...prior, ...body.items] : body.items);
      setNextCursor(body.next_cursor);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not load saved assessments.');
    } finally {
      setLoading(false);
      setPageLoading(false);
    }
  }, [authorizedFetch]);

  useEffect(() => { void loadPage(); }, [loadPage]);

  async function remove(item: SavedScan): Promise<void> {
    setDeleting(item.id);
    setError(null);
    try {
      const response = await authorizedFetch(`/scans/${encodeURIComponent(item.id)}`, { method: 'DELETE' });
      if (!response.ok) throw new Error(`Request failed (${response.status})`);
      setItems((prior) => prior.filter((scan) => scan.id !== item.id));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not delete this saved assessment.');
    } finally {
      setDeleting(null);
    }
  }

  return <View style={styles.history}>
    <Text style={styles.historyTitle}>{language === 'hi' ? 'सहेजे गए आकलन का इतिहास' : language === 'kn' ? 'ಉಳಿಸಿದ ಮೌಲ್ಯಮಾಪನ ಇತಿಹಾಸ' : 'Saved assessment history'}</Text>
    <Text style={styles.small}>{language === 'hi' ? 'यहाँ केवल वे सारांश हैं जिन्हें आपने सहेजने की अनुमति दी। मूल टेक्स्ट और पहचाने गए विवरण शामिल नहीं हैं।' : language === 'kn' ? 'ನೀವು ಉಳಿಸಲು ಆಯ್ಕೆ ಮಾಡಿದ ಸಾರಾಂಶಗಳು ಮಾತ್ರ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ. ಮೂಲ ಪಠ್ಯ ಮತ್ತು ಪತ್ತೆಯಾದ ವಿವರಗಳು ಸೇರಿಲ್ಲ.' : 'Only summaries you opted to save appear here. Original text and detected entities are excluded.'}</Text>
    {loading ? <ActivityIndicator color="#ff987a" /> : items.length === 0 ? <Text style={styles.body}>{language === 'hi' ? 'अभी कोई आकलन सहेजा नहीं गया।' : language === 'kn' ? 'ಇನ್ನೂ ಯಾವುದೇ ಮೌಲ್ಯಮಾಪನ ಉಳಿಸಿಲ್ಲ.' : 'No saved assessments yet.'}</Text> : items.map((item) => <View key={item.id} style={styles.historyRow}>
      <View style={styles.historyInfo}>
        <Text style={styles.historyLabel}>{item.scan_type === 'message' ? (language === 'hi' ? 'संदेश' : language === 'kn' ? 'ಸಂದೇಶ' : 'Message') : (language === 'hi' ? 'लिंक' : language === 'kn' ? 'ಲಿಂಕ್' : 'Link')} · {item.verdict} · {item.risk_level} {language === 'hi' ? 'जोखिम' : language === 'kn' ? 'ಅಪಾಯ' : 'risk'}</Text>
        <Text style={styles.small}>{item.category ?? (language === 'hi' ? 'श्रेणी नहीं' : language === 'kn' ? 'ವರ್ಗವಿಲ್ಲ' : 'No category')} · {new Date(item.created_at).toLocaleString()}</Text>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel={`Delete ${item.scan_type} assessment from history`} disabled={deleting === item.id} onPress={() => { void remove(item); }} style={styles.deleteButton}>
        {deleting === item.id ? <ActivityIndicator color="#ff9ba5" size="small" /> : <Text style={styles.deleteText}>{language === 'hi' ? 'हटाएँ' : language === 'kn' ? 'ಅಳಿಸಿ' : 'Delete'}</Text>}
      </Pressable>
    </View>)}
    {error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
    {nextCursor && <Pressable accessibilityRole="button" disabled={pageLoading} onPress={() => { void loadPage(nextCursor); }} style={styles.loadMore}>
      {pageLoading ? <ActivityIndicator color="#ff987a" /> : <Text style={styles.link}>{language === 'hi' ? 'और देखें' : language === 'kn' ? 'ಇನ್ನಷ್ಟು ನೋಡಿ' : 'Load more'}</Text>}
    </Pressable>}
  </View>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#080706' },
  content: { padding: 22, paddingTop: 54, paddingBottom: 46, gap: 14 },
  eyebrow: { color: '#ff987a', letterSpacing: 1.6, fontSize: 10, fontWeight: '700' },
  title: { color: '#f4f2ef', fontSize: 30, fontWeight: '300' },
  card: { padding: 17, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 11 },
  securityLink: { minHeight: 64, justifyContent: 'center', gap: 5, padding: 14, borderRadius: 15, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f' },
  securityTitle: { color: '#ffae9b', fontSize: 13, fontWeight: '700' },
  languagePanel: { padding: 14, borderRadius: 15, borderWidth: 1, borderColor: 'rgba(255,255,255,.1)', backgroundColor: '#15120f', gap: 9 },
  languageRow: { flexDirection: 'row', gap: 8 },
  languageButton: { minHeight: 44, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 12, borderRadius: 22, backgroundColor: '#0d0b09' },
  history: { gap: 11, marginTop: 8, paddingTop: 15, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,.1)' },
  historyTitle: { color: '#f4f2ef', fontSize: 15, fontWeight: '600' },
  historyRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,.07)' },
  historyInfo: { flex: 1, gap: 4 },
  historyLabel: { color: '#e5ded6', fontSize: 12, fontWeight: '600' },
  deleteButton: { minHeight: 40, justifyContent: 'center', paddingHorizontal: 10 },
  deleteAccountButton: { minHeight: 42, justifyContent: 'center', alignItems: 'center', borderColor: 'rgba(255,155,165,.35)', borderWidth: 1, borderRadius: 24 },
  deleteText: { color: '#ff9ba5', fontSize: 11, fontWeight: '600' },
  loadMore: { minHeight: 42, justifyContent: 'center', alignItems: 'center' },
  loading: { minHeight: 160, alignItems: 'center', justifyContent: 'center', gap: 12 },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  label: { color: '#e7e3de', fontSize: 12, fontWeight: '600', marginTop: 3 },
  email: { color: '#f4f2ef', fontSize: 15, fontWeight: '600' },
  input: { minHeight: 48, paddingHorizontal: 13, borderRadius: 13, borderWidth: 1, borderColor: 'rgba(255,255,255,.13)', backgroundColor: '#0d0b09', color: '#f4f2ef', fontSize: 14 },
  modeRow: { flexDirection: 'row', gap: 7, padding: 4, borderRadius: 13, backgroundColor: '#0d0b09' },
  modeButton: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 10 },
  modeSelected: { backgroundColor: '#32221b' },
  modeText: { color: '#aaa49b', fontSize: 12, fontWeight: '600' },
  modeTextSelected: { color: '#ff987a' },
  showPassword: { alignSelf: 'flex-start', paddingVertical: 4 },
  link: { color: '#ffae9b', fontSize: 12, fontWeight: '600' },
  small: { color: '#858078', fontSize: 11, lineHeight: 17 },
  saved: { color: '#a9dcba', lineHeight: 18, fontSize: 12 },
  button: { minHeight: 48, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 17, borderRadius: 26, backgroundColor: '#ff8060', marginTop: 4 },
  buttonText: { color: '#23120d', fontSize: 12, fontWeight: '700' },
  disabled: { opacity: 0.55 },
  error: { color: '#ff9ba5', lineHeight: 19, fontSize: 12 },
  footer: { color: '#817b73', fontSize: 11, lineHeight: 17 },
});
