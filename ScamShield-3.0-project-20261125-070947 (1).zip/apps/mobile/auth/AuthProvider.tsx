import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type PropsWithChildren } from 'react';
import * as SecureStore from 'expo-secure-store';
import type { AuthUser, Language, MobileAuthResult } from '@scamshield/api-client/types';

const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://10.0.2.2:8000/api/v1';
const REFRESH_TOKEN_KEY = 'scamshield.mobile.refresh-token.v1';

type MobileSession = {
  accessToken: string;
  expiresAt: number;
  user: AuthUser;
};

type AuthContextValue = {
  ready: boolean;
  session: MobileSession | null;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, language: Language) => Promise<void>;
  logout: () => Promise<void>;
  deleteAccount: () => Promise<void>;
  requestPasswordReset: (email: string) => Promise<void>;
  confirmPasswordReset: (token: string, newPassword: string) => Promise<void>;
  refresh: () => Promise<MobileSession | null>;
  authorizedFetch: (path: string, init?: RequestInit) => Promise<Response>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

async function readError(response: Response): Promise<string> {
  const body = await response.json().catch(() => null) as { error?: { message?: string }; detail?: string } | null;
  return body?.error?.message ?? body?.detail ?? `Request failed (${response.status})`;
}

function toSession(result: MobileAuthResult): MobileSession {
  return {
    accessToken: result.access_token,
    expiresAt: Date.now() + result.expires_in * 1000,
    user: result.user,
  };
}

export function AuthProvider({ children }: PropsWithChildren) {
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<MobileSession | null>(null);
  const [error, setError] = useState<string | null>(null);
  const sessionRef = useRef<MobileSession | null>(null);
  const refreshPromise = useRef<Promise<MobileSession | null> | null>(null);

  const commitSession = useCallback((next: MobileSession | null) => {
    sessionRef.current = next;
    setSession(next);
  }, []);

  const refresh = useCallback((): Promise<MobileSession | null> => {
    if (refreshPromise.current) return refreshPromise.current;
    const operation = (async () => {
      const refreshToken = await SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
      if (!refreshToken) {
        commitSession(null);
        return null;
      }
      const response = await fetch(`${API_BASE}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ client_type: 'mobile', refresh_token: refreshToken }),
      });
      if (response.status === 401) {
        await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
        commitSession(null);
        return null;
      }
      if (!response.ok) throw new Error(await readError(response));
      const result = await response.json() as MobileAuthResult;
      if (!result.refresh_token) throw new Error('The server did not return a mobile refresh token.');
      await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, result.refresh_token);
      const next = toSession(result);
      commitSession(next);
      setError(null);
      return next;
    })();
    refreshPromise.current = operation;
    void operation.finally(() => {
      if (refreshPromise.current === operation) refreshPromise.current = null;
    }).catch(() => undefined);
    return operation;
  }, [commitSession]);

  useEffect(() => {
    let mounted = true;
    void refresh().catch((cause: unknown) => {
      if (mounted) setError(cause instanceof Error ? cause.message : 'Could not restore this account session.');
    }).finally(() => {
      if (mounted) setReady(true);
    });
    return () => { mounted = false; };
  }, [refresh]);

  const authenticate = useCallback(async (path: 'login' | 'register', payload: Record<string, unknown>) => {
    setError(null);
    const response = await fetch(`${API_BASE}/auth/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, client_type: 'mobile' }),
    });
    if (!response.ok) throw new Error(await readError(response));
    const result = await response.json() as MobileAuthResult;
    if (!result.refresh_token) throw new Error('The server did not return a mobile refresh token.');
    await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, result.refresh_token);
    commitSession(toSession(result));
  }, [commitSession]);

  const login = useCallback((email: string, password: string) => authenticate('login', { email, password }), [authenticate]);
  const register = useCallback((email: string, password: string, language: Language) => authenticate('register', { email, password, language }), [authenticate]);

  const logout = useCallback(async () => {
    let current = sessionRef.current;
    let accessToken = current?.accessToken;
    let refreshFailed = false;
    if (current && current.expiresAt <= Date.now() + 5000) {
      try {
        current = await refresh();
        accessToken = current?.accessToken;
      } catch {
        refreshFailed = true;
      }
    }
    commitSession(null);
    try {
      await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
    } catch {
      setError('The account was signed out, but secure storage could not be cleared.');
    }
    if (!accessToken) {
      if (refreshFailed) setError('Signed out on this device. The server could not be reached to revoke the session.');
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!response.ok) setError('Signed out on this device. The server could not revoke the session.');
    } catch {
      setError('Signed out on this device. The server could not be reached to revoke the session.');
    }
  }, [commitSession, refresh]);

  const requestPasswordReset = useCallback(async (email: string) => {
    const response = await fetch(`${API_BASE}/auth/password-reset/request`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, client_type: 'mobile' }),
    });
    if (!response.ok) throw new Error(await readError(response));
  }, []);

  const confirmPasswordReset = useCallback(async (token: string, newPassword: string) => {
    const response = await fetch(`${API_BASE}/auth/password-reset/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, new_password: newPassword }),
    });
    if (!response.ok) throw new Error(await readError(response));
    commitSession(null);
    try {
      await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
      setError(null);
    } catch {
      setError('Your password changed, but this device could not clear its saved sign-in token.');
    }
  }, [commitSession]);

  const authorizedFetch = useCallback(async (path: string, init: RequestInit = {}) => {
    const send = (accessToken?: string) => {
      const headers = new Headers(init.headers);
      if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
      return fetch(`${API_BASE}${path}`, { ...init, headers });
    };
    const current = sessionRef.current;
    if (!current) return send();
    const response = await send(current.accessToken);
    if (response.status !== 401) return response;
    try {
      const refreshed = await refresh();
      return refreshed ? send(refreshed.accessToken) : response;
    } catch {
      return response;
    }
  }, [refresh]);

  const deleteAccount = useCallback(async () => {
    const response = await authorizedFetch('/users/me', { method: 'DELETE' });
    if (!response.ok) throw new Error(await readError(response));
    commitSession(null);
    try {
      await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
      setError(null);
    } catch {
      setError('Your account was deleted, but this device could not clear its saved sign-in token.');
    }
  }, [authorizedFetch, commitSession]);

  const value = useMemo(() => ({ ready, session, error, login, register, logout, deleteAccount, requestPasswordReset, confirmPasswordReset, refresh, authorizedFetch }), [ready, session, error, login, register, logout, deleteAccount, requestPasswordReset, confirmPasswordReset, refresh, authorizedFetch]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useMobileAuth(): AuthContextValue {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useMobileAuth must be used inside AuthProvider');
  return value;
}
