import type { Language } from '@scamshield/api-client/types';

export type MobileAction = 'message' | 'url' | 'qr' | 'history' | 'alerts' | 'security' | 'emergency-money' | 'emergency-account' | 'emergency' | 'learn' | 'profile';
export type MobileFeature = {
  slug: string;
  title: string;
  description: string;
  action?: MobileAction;
  availability?: 'guidance' | 'unavailable';
  guidance?: string[];
};
export type MobileCategory = {
  slug: string;
  title: string;
  description: string;
  features: MobileFeature[];
};

export const mobileCategories: MobileCategory[] = [
  {
    slug: 'scam-detection', title: 'Scam detection', description: 'Check a message, link, or QR payload before taking action.', features: [
      { slug: 'message-scanner', title: 'Message Scanner', description: 'Assess suspicious SMS or chat text on demand.', action: 'message' },
      { slug: 'url-scanner', title: 'URL Scanner', description: 'Inspect a link as text without opening it.', action: 'url' },
      { slug: 'qr-scanner', title: 'QR Code Scanner', description: 'Decode QR content on this device; review before sending it for assessment.', action: 'qr' },
      { slug: 'scan-history', title: 'Scan History', description: 'Review or delete assessment summaries you chose to save.', action: 'history' },
    ],
  },
  {
    slug: 'digital-protection', title: 'Digital protection', description: 'Review account and privacy guidance.', features: [
      { slug: 'security-alerts', title: 'Security Alerts', description: 'Review alert availability and on-demand scanning status.', action: 'alerts', availability: 'guidance' },
      { slug: 'privacy-centre', title: 'Privacy Centre', description: 'See what ScamShield does and does not inspect.', availability: 'guidance', guidance: ['ScamShield checks only content you submit for an on-demand scan.', 'This app does not inspect browser cookies, other websites, or your bank activity.', 'Guest scans are not saved. Account history is optional and stores assessment metadata only.'] },
      { slug: 'cookie-guidance', title: 'Cookie & Tracker Guidance', description: 'Learn how to review site data in your own browser.', availability: 'guidance', guidance: ['ScamShield does not inspect cookies or trackers on other websites.', 'Use your browser’s own privacy settings to review site data.', 'Clear data only for a site you recognize; this may sign you out. HTTPS does not prove a site is trustworthy.'] },
      { slug: 'secure-my-account', title: 'Secure My Account', description: 'Work through account-hardening steps in the official service.', action: 'security' },
    ],
  },
  {
    slug: 'emergency-centre', title: 'Emergency centre', description: 'Take practical steps if money or account access is at risk.', features: [
      { slug: 'lost-money', title: 'I Lost Money', description: 'Contact your bank through official channels and report suspected cyber fraud.', action: 'emergency-money' },
      { slug: 'account-hacked', title: 'Account Hacked', description: 'Reduce further access and secure recovery details.', action: 'emergency-account' },
      { slug: 'report-cyber-fraud', title: 'Report Cyber Fraud', description: 'Open the official reporting guidance and hotline action.', action: 'emergency' },
      { slug: 'emergency-history', title: 'Emergency History', description: 'Server-backed case history is not available in this build.', availability: 'unavailable' },
    ],
  },
  {
    slug: 'learning-centre', title: 'Learning centre', description: 'Practice with educational examples, not live scam checks.', features: [
      { slug: 'scam-lessons', title: 'Scam Lessons', description: 'Learn about common scam patterns.', action: 'learn' },
      { slug: 'interactive-quizzes', title: 'Interactive Quizzes', description: 'Check your learning with explanations.', action: 'learn' },
      { slug: 'scam-simulator', title: 'Scam Simulator', description: 'Review clearly labeled synthetic scenarios.', action: 'learn' },
      { slug: 'learning-progress', title: 'My Learning Progress', description: 'Track learning activity saved on this device.', action: 'learn' },
    ],
  },
  {
    slug: 'family-safety', title: 'Family safety', description: 'Family sharing requires explicit, revocable consent.', features: [
      { slug: 'trusted-contacts', title: 'Trusted Contacts', description: 'Contact storage and consent workflows are not available in this build.', availability: 'unavailable' },
      { slug: 'family-protection', title: 'Family Protection', description: 'Family alerts are not enabled. No scan content is shared.', availability: 'unavailable' },
    ],
  },
  {
    slug: 'settings', title: 'Settings', description: 'Manage your profile and review privacy choices.', features: [
      { slug: 'my-profile', title: 'My Profile', description: 'Sign in or manage your account and saved assessment history.', action: 'profile' },
      { slug: 'language', title: 'Language', description: 'Choose a content language within Learn, Alerts, and emergency guidance.', availability: 'guidance', guidance: ['English, Hindi, and Kannada content choices are available in supported sections.', 'A single app-wide language preference is not available yet.'] },
      { slug: 'notifications', title: 'Notifications', description: 'Push registration and delivery are not available in this build.', action: 'alerts', availability: 'guidance' },
      { slug: 'privacy-settings', title: 'Privacy Settings', description: 'Review current data handling and account choices.', availability: 'guidance', guidance: ['Guest scans are not retained. Saved account assessment summaries are optional.', 'Account data can be deleted from Profile after signing in.'] },
    ],
  },
];

const categoryTranslations: Partial<Record<Language, Record<string, { title: string; description: string }>>> = {
  hi: {
    'scam-detection': { title: 'धोखाधड़ी पहचान', description: 'कार्रवाई से पहले संदेश, लिंक या QR की जाँच करें।' },
    'digital-protection': { title: 'डिजिटल सुरक्षा', description: 'खाता और गोपनीयता से जुड़ी सलाह देखें।' },
    'emergency-centre': { title: 'आपातकालीन केंद्र', description: 'पैसे या खाते का जोखिम हो तो व्यावहारिक कदम लें।' },
    'learning-centre': { title: 'सीखने का केंद्र', description: 'शैक्षिक उदाहरणों से अभ्यास करें; ये लाइव जाँच नहीं हैं।' },
    'family-safety': { title: 'परिवार की सुरक्षा', description: 'परिवार के साथ साझा करने के लिए स्पष्ट और वापस ली जा सकने वाली सहमति चाहिए।' },
    settings: { title: 'सेटिंग', description: 'प्रोफ़ाइल और गोपनीयता विकल्प देखें।' },
  },
  kn: {
    'scam-detection': { title: 'ವಂಚನೆ ಪತ್ತೆ', description: 'ಕ್ರಮ ಕೈಗೊಳ್ಳುವ ಮೊದಲು ಸಂದೇಶ, ಲಿಂಕ್ ಅಥವಾ QR ಪರಿಶೀಲಿಸಿ.' },
    'digital-protection': { title: 'ಡಿಜಿಟಲ್ ರಕ್ಷಣೆ', description: 'ಖಾತೆ ಮತ್ತು ಗೌಪ್ಯತೆ ಮಾರ್ಗದರ್ಶನವನ್ನು ನೋಡಿ.' },
    'emergency-centre': { title: 'ತುರ್ತು ಕೇಂದ್ರ', description: 'ಹಣ ಅಥವಾ ಖಾತೆಗೆ ಅಪಾಯವಿದ್ದರೆ ಕ್ರಮಗಳನ್ನು ಕೈಗೊಳ್ಳಿ.' },
    'learning-centre': { title: 'ಕಲಿಕಾ ಕೇಂದ್ರ', description: 'ಶೈಕ್ಷಣಿಕ ಉದಾಹರಣೆಗಳೊಂದಿಗೆ ಅಭ್ಯಾಸ ಮಾಡಿ; ಇವು ನೈಜ ಪರಿಶೀಲನೆಗಳಲ್ಲ.' },
    'family-safety': { title: 'ಕುಟುಂಬದ ಸುರಕ್ಷತೆ', description: 'ಕುಟುಂಬದೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಲು ಸ್ಪಷ್ಟ ಮತ್ತು ಹಿಂಪಡೆಯಬಹುದಾದ ಒಪ್ಪಿಗೆ ಅಗತ್ಯ.' },
    settings: { title: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು', description: 'ಪ್ರೊಫೈಲ್ ಮತ್ತು ಗೌಪ್ಯತೆ ಆಯ್ಕೆಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.' },
  },
};
const featureTitles: Partial<Record<Language, Record<string, string>>> = {
  hi: {
    'message-scanner': 'संदेश स्कैनर', 'url-scanner': 'लिंक जाँच', 'qr-scanner': 'QR कोड स्कैनर', 'scan-history': 'स्कैन इतिहास',
    'security-alerts': 'सुरक्षा अलर्ट', 'privacy-centre': 'गोपनीयता केंद्र', 'cookie-guidance': 'कुकी और ट्रैकर मार्गदर्शन', 'secure-my-account': 'खाता सुरक्षित करें',
    'lost-money': 'पैसे का नुकसान हुआ', 'account-hacked': 'खाता हैक हुआ', 'report-cyber-fraud': 'साइबर धोखाधड़ी रिपोर्ट करें', 'emergency-history': 'आपातकालीन इतिहास',
    'scam-lessons': 'धोखाधड़ी के पाठ', 'interactive-quizzes': 'इंटरैक्टिव प्रश्नोत्तरी', 'scam-simulator': 'धोखाधड़ी सिम्युलेटर', 'learning-progress': 'सीखने की प्रगति',
    'trusted-contacts': 'विश्वसनीय संपर्क', 'family-protection': 'परिवार की सुरक्षा', 'my-profile': 'मेरी प्रोफ़ाइल', language: 'भाषा', notifications: 'सूचनाएँ', 'privacy-settings': 'गोपनीयता सेटिंग',
  },
  kn: {
    'message-scanner': 'ಸಂದೇಶ ಸ್ಕ್ಯಾನರ್', 'url-scanner': 'ಲಿಂಕ್ ಪರಿಶೀಲನೆ', 'qr-scanner': 'QR ಕೋಡ್ ಸ್ಕ್ಯಾನರ್', 'scan-history': 'ಸ್ಕ್ಯಾನ್ ಇತಿಹಾಸ',
    'security-alerts': 'ಭದ್ರತಾ ಎಚ್ಚರಿಕೆಗಳು', 'privacy-centre': 'ಗೌಪ್ಯತೆ ಕೇಂದ್ರ', 'cookie-guidance': 'ಕುಕಿ ಮತ್ತು ಟ್ರ್ಯಾಕರ್ ಮಾರ್ಗದರ್ಶನ', 'secure-my-account': 'ನನ್ನ ಖಾತೆ ಸುರಕ್ಷಿತಗೊಳಿಸಿ',
    'lost-money': 'ಹಣ ಕಳೆದುಹೋಗಿದೆ', 'account-hacked': 'ಖಾತೆ ಹ್ಯಾಕ್ ಆಗಿದೆ', 'report-cyber-fraud': 'ಸೈಬರ್ ವಂಚನೆ ವರದಿ ಮಾಡಿ', 'emergency-history': 'ತುರ್ತು ಇತಿಹಾಸ',
    'scam-lessons': 'ವಂಚನೆ ಪಾಠಗಳು', 'interactive-quizzes': 'ಸಂವಾದಾತ್ಮಕ ರಸಪ್ರಶ್ನೆಗಳು', 'scam-simulator': 'ವಂಚನೆ ಸಿಮ್ಯುಲೇಟರ್', 'learning-progress': 'ಕಲಿಕೆಯ ಪ್ರಗತಿ',
    'trusted-contacts': 'ನಂಬಿಕೆಯ ಸಂಪರ್ಕಗಳು', 'family-protection': 'ಕುಟುಂಬದ ರಕ್ಷಣೆ', 'my-profile': 'ನನ್ನ ಪ್ರೊಫೈಲ್', language: 'ಭಾಷೆ', notifications: 'ಅಧಿಸೂಚನೆಗಳು', 'privacy-settings': 'ಗೌಪ್ಯತೆ ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
  },
};

export function categoryTitle(category: MobileCategory, language: Language): string {
  return categoryTranslations[language]?.[category.slug]?.title ?? category.title;
}

export function categoryDescription(category: MobileCategory, language: Language): string {
  return categoryTranslations[language]?.[category.slug]?.description ?? category.description;
}

export function featureTitle(feature: MobileFeature, language: Language): string {
  return featureTitles[language]?.[feature.slug] ?? feature.title;
}

export function findMobileCategory(slug: string | undefined): MobileCategory | undefined {
  return mobileCategories.find((category) => category.slug === slug);
}

export function findMobileFeature(slug: string | undefined): { category: MobileCategory; feature: MobileFeature } | undefined {
  for (const category of mobileCategories) {
    const feature = category.features.find((item) => item.slug === slug);
    if (feature) return { category, feature };
  }
  return undefined;
}
