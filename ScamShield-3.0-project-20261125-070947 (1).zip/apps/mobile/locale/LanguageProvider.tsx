import { createContext, useCallback, useContext, useEffect, useRef, useState, type JSX, type ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';
import type { Language } from '@scamshield/api-client/types';

const languageKey = 'scamshield.mobile.language.v1';
type LanguageContextValue = {
  language: Language;
  ready: boolean;
  persistenceUnavailable: boolean;
  changeLanguage: (language: Language) => Promise<void>;
};
const LanguageContext = createContext<LanguageContextValue | null>(null);

function isLanguage(value: string | null): value is Language {
  return value === 'en' || value === 'hi' || value === 'kn';
}

export function LanguageProvider({ children }: { children: ReactNode }): JSX.Element {
  const [language, setLanguage] = useState<Language>('en');
  const [ready, setReady] = useState(false);
  const [persistenceUnavailable, setPersistenceUnavailable] = useState(false);
  const changedBeforeLoad = useRef(false);

  useEffect(() => {
    let mounted = true;
    void SecureStore.getItemAsync(languageKey).then((saved) => {
      if (mounted && !changedBeforeLoad.current && isLanguage(saved)) setLanguage(saved);
    }).catch(() => {
      if (mounted) setPersistenceUnavailable(true);
    }).finally(() => {
      if (mounted) setReady(true);
    });
    return () => { mounted = false; };
  }, []);

  const changeLanguage = useCallback(async (next: Language) => {
    changedBeforeLoad.current = true;
    setLanguage(next);
    setPersistenceUnavailable(false);
    try {
      await SecureStore.setItemAsync(languageKey, next);
    } catch {
      setPersistenceUnavailable(true);
    }
  }, []);

  return <LanguageContext.Provider value={{ language, ready, persistenceUnavailable, changeLanguage }}>{children}</LanguageContext.Provider>;
}

export function useAppLanguage(): LanguageContextValue {
  const value = useContext(LanguageContext);
  if (!value) throw new Error('useAppLanguage must be used within LanguageProvider');
  return value;
}
