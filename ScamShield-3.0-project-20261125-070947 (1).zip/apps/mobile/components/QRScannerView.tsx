import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, AppState, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useIsFocused } from 'expo-router';
import type { Language, QrScanResult } from '@scamshield/api-client/types';

const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://10.0.2.2:8000/api/v1';

const qrCopy: Record<Language, { payment: string; web: string; text: string; permissionLoading: string; heading: string; permissionBody: string; allow: string; settings: string; denied: string; cameraError: string; cameraBody: string; paused: string; decoded: string; payee: string; amount: string; note: string; missing: string; tooLong: string; assessInfo: string; assess: string; risk: string; resultScam: string; resultSuspicious: string; resultClear: string; paymentCaution: string; scanAnother: string; retry: string; footer: string }> = {
  en: { payment: 'UPI payment request', web: 'Web address', text: 'Text', permissionLoading: 'Checking camera permission…', heading: 'Scan a QR code', permissionBody: 'Camera access is used only to decode a QR code on this device. ScamShield will not open its contents or initiate a payment.', allow: 'Allow camera access', settings: 'Open device settings', denied: 'Camera permission is off. You can enable it in device settings, or use the message and link scanners.', cameraError: 'Camera could not start', cameraBody: 'The camera decodes locally. ScamShield never opens a link or starts a payment.', paused: 'Camera paused while this screen is not active.', decoded: 'DECODED ON THIS DEVICE', payee: 'Payee', amount: 'Amount', note: 'Note', missing: 'This QR code did not contain readable text. Try another code.', tooLong: 'This QR code contains more than 2,048 characters, so ScamShield cannot assess it.', assessInfo: 'The decoded text is sent to ScamShield only if you choose to assess it. The QR payload is not saved.', assess: 'Assess QR content', risk: 'Risk assessment', resultScam: 'Strong warning signs found', resultSuspicious: 'Some warning signs found', resultClear: 'No configured warning signs found', paymentCaution: 'Parsed payment details are unverified. Confirm the recipient and amount in your payment app before taking action.', scanAnother: 'Scan another code', retry: 'Try scanning again', footer: 'A QR code may contain a link, text, or payment request. A QR result is an assessment, not proof of safety or fraud.' },
  hi: { payment: 'UPI भुगतान अनुरोध', web: 'वेब पता', text: 'टेक्स्ट', permissionLoading: 'कैमरा अनुमति जाँची जा रही है…', heading: 'QR कोड स्कैन करें', permissionBody: 'कैमरे का उपयोग केवल इस डिवाइस पर QR कोड पढ़ने के लिए होता है। ScamShield इसकी सामग्री नहीं खोलेगा और भुगतान शुरू नहीं करेगा।', allow: 'कैमरा अनुमति दें', settings: 'डिवाइस सेटिंग खोलें', denied: 'कैमरा अनुमति बंद है। आप इसे डिवाइस सेटिंग में चालू कर सकते हैं या संदेश और लिंक स्कैनर इस्तेमाल कर सकते हैं।', cameraError: 'कैमरा शुरू नहीं हो सका', cameraBody: 'कैमरा कोड इसी डिवाइस पर पढ़ता है। ScamShield कोई लिंक नहीं खोलता और भुगतान शुरू नहीं करता।', paused: 'यह स्क्रीन सक्रिय न होने पर कैमरा रुका हुआ है।', decoded: 'इस डिवाइस पर पढ़ा गया', payee: 'प्राप्तकर्ता', amount: 'राशि', note: 'टिप्पणी', missing: 'इस QR कोड में पढ़ने योग्य टेक्स्ट नहीं था। दूसरा कोड आज़माएँ।', tooLong: 'इस QR कोड में 2,048 से अधिक अक्षर हैं, इसलिए ScamShield इसका आकलन नहीं कर सकता।', assessInfo: 'पढ़ा गया टेक्स्ट ScamShield को तभी भेजा जाता है जब आप आकलन चुनते हैं। QR सामग्री सहेजी नहीं जाती।', assess: 'QR सामग्री का आकलन करें', risk: 'जोखिम आकलन', resultScam: 'मजबूत चेतावनी संकेत मिले', resultSuspicious: 'कुछ चेतावनी संकेत मिले', resultClear: 'कॉन्फ़िगर किए गए चेतावनी संकेत नहीं मिले', paymentCaution: 'भुगतान विवरण सत्यापित नहीं हैं। कार्रवाई से पहले अपने भुगतान ऐप में प्राप्तकर्ता और राशि जाँचें।', scanAnother: 'दूसरा कोड स्कैन करें', retry: 'फिर से स्कैन करें', footer: 'QR कोड में लिंक, टेक्स्ट या भुगतान अनुरोध हो सकता है। QR का परिणाम आकलन है, सुरक्षा या धोखाधड़ी का प्रमाण नहीं।' },
  kn: { payment: 'UPI ಪಾವತಿ ವಿನಂತಿ', web: 'ವೆಬ್ ವಿಳಾಸ', text: 'ಪಠ್ಯ', permissionLoading: 'ಕ್ಯಾಮೆರಾ ಅನುಮತಿ ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ…', heading: 'QR ಕೋಡ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ', permissionBody: 'ಈ ಸಾಧನದಲ್ಲೇ QR ಕೋಡ್ ಡಿಕೋಡ್ ಮಾಡಲು ಮಾತ್ರ ಕ್ಯಾಮೆರಾ ಬಳಸಲಾಗುತ್ತದೆ. ScamShield ವಿಷಯ ತೆರೆಯುವುದಿಲ್ಲ ಅಥವಾ ಪಾವತಿ ಆರಂಭಿಸುವುದಿಲ್ಲ.', allow: 'ಕ್ಯಾಮೆರಾ ಅನುಮತಿಸಿ', settings: 'ಸಾಧನ ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ತೆರೆಯಿರಿ', denied: 'ಕ್ಯಾಮೆರಾ ಅನುಮತಿ ಆಫ್ ಆಗಿದೆ. ಸಾಧನ ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಅನುಮತಿಸಿ ಅಥವಾ ಸಂದೇಶ ಮತ್ತು ಲಿಂಕ್ ಸ್ಕ್ಯಾನರ್ ಬಳಸಿ.', cameraError: 'ಕ್ಯಾಮೆರಾ ಪ್ರಾರಂಭವಾಗಲಿಲ್ಲ', cameraBody: 'ಕ್ಯಾಮೆರಾ ಸಾಧನದಲ್ಲೇ ಡಿಕೋಡ್ ಮಾಡುತ್ತದೆ. ScamShield ಲಿಂಕ್ ತೆರೆಯುವುದಿಲ್ಲ ಅಥವಾ ಪಾವತಿ ಆರಂಭಿಸುವುದಿಲ್ಲ.', paused: 'ಈ ಪರದೆ ಸಕ್ರಿಯವಾಗಿಲ್ಲದಾಗ ಕ್ಯಾಮೆರಾ ವಿರಾಮದಲ್ಲಿದೆ.', decoded: 'ಈ ಸಾಧನದಲ್ಲೇ ಡಿಕೋಡ್ ಮಾಡಲಾಗಿದೆ', payee: 'ಪಾವತಿ ಸ್ವೀಕರಿಸುವವರು', amount: 'ಮೊತ್ತ', note: 'ಟಿಪ್ಪಣಿ', missing: 'ಈ QR ಕೋಡ್‌ನಲ್ಲಿ ಓದಬಹುದಾದ ಪಠ್ಯ ಇರಲಿಲ್ಲ. ಮತ್ತೊಂದು ಕೋಡ್ ಪ್ರಯತ್ನಿಸಿ.', tooLong: 'ಈ QR ಕೋಡ್‌ನಲ್ಲಿ 2,048 ಅಕ್ಷರಗಳಿಗಿಂತ ಹೆಚ್ಚು ಇದೆ; ScamShield ಇದನ್ನು ಪರಿಶೀಲಿಸಲಾಗುವುದಿಲ್ಲ.', assessInfo: 'ನೀವು ಪರಿಶೀಲಿಸಲು ಆಯ್ಕೆ ಮಾಡಿದಾಗ ಮಾತ್ರ ಡಿಕೋಡ್ ಮಾಡಿದ ಪಠ್ಯ ScamShield ಗೆ ಕಳುಹಿಸಲಾಗುತ್ತದೆ. QR ವಿಷಯ ಉಳಿಸಲಾಗುವುದಿಲ್ಲ.', assess: 'QR ವಿಷಯ ಪರಿಶೀಲಿಸಿ', risk: 'ಅಪಾಯ ಮೌಲ್ಯಮಾಪನ', resultScam: 'ಬಲವಾದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultSuspicious: 'ಕೆಲವು ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ', resultClear: 'ಕಾನ್ಫಿಗರ್ ಮಾಡಿದ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ', paymentCaution: 'ಪಾರ್ಸ್ ಮಾಡಿದ ಪಾವತಿ ವಿವರಗಳು ಪರಿಶೀಲಿತವಲ್ಲ. ಕ್ರಮಕ್ಕೂ ಮೊದಲು ಪಾವತಿ ಆ್ಯಪ್‌ನಲ್ಲಿ ಸ್ವೀಕರಿಸುವವರು ಮತ್ತು ಮೊತ್ತ ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.', scanAnother: 'ಮತ್ತೊಂದು ಕೋಡ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ', retry: 'ಮತ್ತೆ ಸ್ಕ್ಯಾನ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸಿ', footer: 'QR ಕೋಡ್‌ನಲ್ಲಿ ಲಿಂಕ್, ಪಠ್ಯ ಅಥವಾ ಪಾವತಿ ವಿನಂತಿ ಇರಬಹುದು. QR ಫಲಿತಾಂಶ ಮೌಲ್ಯಮಾಪನ ಮಾತ್ರ; ಸುರಕ್ಷತೆ ಅಥವಾ ವಂಚನೆಗೆ ಪುರಾವೆಯಲ್ಲ.' },
};

function classifyLocally(value: string, language: Language): string {
  const labels = qrCopy[language];
  if (isUpiPayment(value)) return labels.payment;
  if (/^(?:https?:\/\/|www\.)/i.test(value)) return labels.web;
  return labels.text;
}

function isUpiPayment(value: string): boolean {
  try {
    const parsed = new URL(value);
    return parsed.protocol.toLowerCase() === 'upi:' && parsed.hostname.toLowerCase() === 'pay' && ['', '/'].includes(parsed.pathname);
  } catch {
    return false;
  }
}

function upiPreview(value: string): { payee: string | null; amount: string | null; note: string | null } | null {
  if (!isUpiPayment(value)) return null;
  try {
    const query = new URL(value).searchParams;
    return {
      payee: query.get('pa'),
      amount: query.get('am'),
      note: query.get('tn'),
    };
  } catch {
    return { payee: null, amount: null, note: null };
  }
}

export function QRScannerView({ language }: { language: Language }) {
  const labels = qrCopy[language];
  const [permission, requestPermission] = useCameraPermissions();
  const isFocused = useIsFocused();
  const [appActive, setAppActive] = useState(AppState.currentState === 'active');
  const [decodedText, setDecodedText] = useState<string | null>(null);
  const [result, setResult] = useState<QrScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const captured = useRef(false);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => setAppActive(state === 'active'));
    return () => subscription.remove();
  }, []);

  function handleBarcode({ data }: { data: string }): void {
    if (captured.current) return;
    captured.current = true;
    if (!data.trim()) {
      setError(labels.missing);
      return;
    }
    if (data.length > 2048) {
      setError(labels.tooLong);
      return;
    }
    setDecodedText(data);
    setError(null);
  }

  async function assessDecodedText(): Promise<void> {
    if (!decodedText) return;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE}/scans/qr`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decoded_text: decodedText, language }),
      });
      const body = await response.json() as QrScanResult & { error?: { message?: string }; detail?: string };
      if (!response.ok) throw new Error(body.error?.message ?? body.detail ?? `Request failed (${response.status})`);
      setResult(body);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'We could not reach ScamShield. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  function scanAgain(): void {
    captured.current = false;
    setDecodedText(null);
    setResult(null);
    setError(null);
  }

  if (!permission) {
    return <View style={styles.permissionCard}><ActivityIndicator color="#ff987a" /><Text style={styles.body}>{labels.permissionLoading}</Text></View>;
  }

  if (!permission.granted) {
    return <View style={styles.permissionCard}>
      <Text style={styles.heading}>{labels.heading}</Text>
      <Text style={styles.body}>{labels.permissionBody}</Text>
      {permission.canAskAgain ? <Pressable accessibilityRole="button" onPress={() => { void requestPermission(); }} style={styles.button}><Text style={styles.buttonText}>{labels.allow}</Text></Pressable> : <Pressable accessibilityRole="button" onPress={() => { void Linking.openSettings(); }} style={styles.button}><Text style={styles.buttonText}>{labels.settings}</Text></Pressable>}
      {!permission.canAskAgain && <Text style={styles.small}>{labels.denied}</Text>}
    </View>;
  }

  return <View style={styles.container}>
    <Text style={styles.heading}>{labels.heading}</Text>
    <Text style={styles.body}>{labels.cameraBody}</Text>
    {!decodedText && isFocused && appActive ? <View style={styles.cameraFrame}>
      <CameraView
        style={StyleSheet.absoluteFill}
        facing="back"
        barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
        onBarcodeScanned={handleBarcode}
        onMountError={({ message }) => setError(`${labels.cameraError}: ${message}`)}
      />
      <View pointerEvents="none" style={styles.scanGuide} />
    </View> : !decodedText ? <View style={styles.cameraPaused}><Text style={styles.small}>{labels.paused}</Text></View> : <View style={styles.decodedCard}>
      <Text style={styles.eyebrow}>{labels.decoded.toUpperCase()} · {classifyLocally(decodedText, language).toUpperCase()}</Text>
      {upiPreview(decodedText) && <>
        <Text style={styles.notice}>{language === 'hi' ? 'यह QR भुगतान अनुरोध बताता है; इससे आपको पैसे नहीं मिलेंगे। भुगतान को मंज़ूरी देने के लिए UPI PIN का उपयोग होता है। मंज़ूरी से पहले प्राप्तकर्ता और राशि जाँचें।' : language === 'kn' ? 'ಈ QR ಪಾವತಿ ವಿನಂತಿಯನ್ನು ಸೂಚಿಸುತ್ತದೆ; ಇದರಿಂದ ನಿಮಗೆ ಹಣ ಬರುವುದಿಲ್ಲ. ಪಾವತಿಯನ್ನು ಅನುಮೋದಿಸಲು UPI PIN ಬಳಸಲಾಗುತ್ತದೆ. ಅನುಮೋದಿಸುವ ಮೊದಲು ಸ್ವೀಕರಿಸುವವರು ಮತ್ತು ಮೊತ್ತ ಪರಿಶೀಲಿಸಿ.' : 'This QR describes a payment request; it will not receive money. A UPI PIN authorizes payment. Check the payee and amount before approving anything.'}</Text>
        <Text style={styles.detailLabel}>{labels.payee}</Text><Text selectable style={styles.detailValue}>{upiPreview(decodedText)?.payee ?? (language === 'hi' ? 'नहीं दिया गया' : language === 'kn' ? 'ಒದಗಿಸಿಲ್ಲ' : 'Not provided')}</Text>
        <Text style={styles.detailLabel}>{labels.amount}</Text><Text selectable style={styles.detailValue}>{upiPreview(decodedText)?.amount ?? (language === 'hi' ? 'नहीं दिया गया' : language === 'kn' ? 'ಒದಗಿಸಿಲ್ಲ' : 'Not provided')}</Text>
        {!!upiPreview(decodedText)?.note && <><Text style={styles.detailLabel}>{labels.note}</Text><Text selectable style={styles.detailValue}>{upiPreview(decodedText)?.note}</Text></>}
      </>}
      <Text selectable style={styles.payload}>{decodedText}</Text>
      {!result && <>
        <Text style={styles.small}>{labels.assessInfo}</Text>
        <Pressable accessibilityRole="button" disabled={loading} onPress={() => { void assessDecodedText(); }} style={[styles.button, loading && styles.disabled]}>
          {loading ? <ActivityIndicator color="#23120d" /> : <Text style={styles.buttonText}>{labels.assess}</Text>}
        </Pressable>
      </>}
      {result && <>
        <Text style={styles.notice}>{result.notice}</Text>
        {result.upi_payment && <Text style={styles.small}>{labels.paymentCaution}</Text>}
        <View style={styles.assessment}>
          <Text style={styles.detailLabel}>{labels.risk} · {result.assessment.risk_level}</Text>
          <Text style={styles.verdict}>{result.assessment.verdict === 'SCAM' ? labels.resultScam : result.assessment.verdict === 'SUSPICIOUS' ? labels.resultSuspicious : labels.resultClear}</Text>
          <Text style={styles.body}>{result.assessment.uncertainty}</Text>
          {result.assessment.indicators.map((item) => <Text key={`${item.id}-${item.start}`} style={styles.small}>{item.label}: {item.why}</Text>)}
          {result.assessment.recommended_actions.map((item) => <Text key={item} style={styles.action}>{item}</Text>)}
        </View>
      </>}
      <Pressable accessibilityRole="button" onPress={scanAgain} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>{labels.scanAnother}</Text></Pressable>
    </View>}
    {error && <Text accessibilityRole="alert" style={styles.error}>{error}</Text>}
    {error && !decodedText && <Pressable accessibilityRole="button" onPress={scanAgain} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>{labels.retry}</Text></Pressable>}
    <Text style={styles.small}>{labels.footer}</Text>
  </View>;
}

const styles = StyleSheet.create({
  container: { gap: 13, paddingBottom: 18 },
  permissionCard: { gap: 14, padding: 16, borderRadius: 18, backgroundColor: '#15120f' },
  heading: { color: '#f4f2ef', fontSize: 20, fontWeight: '600' },
  body: { color: '#aaa49b', lineHeight: 21, fontSize: 13 },
  cameraFrame: { height: 330, overflow: 'hidden', borderRadius: 18, backgroundColor: '#15120f', alignItems: 'center', justifyContent: 'center' },
  cameraPaused: { height: 120, alignItems: 'center', justifyContent: 'center', borderRadius: 18, backgroundColor: '#15120f', padding: 18 },
  scanGuide: { width: 220, height: 220, borderWidth: 2, borderColor: '#ff987a', borderRadius: 20 },
  decodedCard: { padding: 15, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.12)', backgroundColor: '#15120f', gap: 10 },
  eyebrow: { color: '#ff987a', fontSize: 10, letterSpacing: 1.2, fontWeight: '700' },
  detailLabel: { color: '#817b73', fontSize: 11, fontWeight: '600', textTransform: 'uppercase' },
  detailValue: { color: '#f4f2ef', fontSize: 13, lineHeight: 19 },
  payload: { color: '#e5ded6', fontSize: 12, lineHeight: 18, padding: 10, borderRadius: 10, backgroundColor: '#0c0b09' },
  small: { color: '#858078', fontSize: 11, lineHeight: 17 },
  button: { minHeight: 46, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, borderRadius: 25, backgroundColor: '#ff8060' },
  buttonText: { color: '#23120d', fontWeight: '700', fontSize: 12 },
  secondaryButton: { alignSelf: 'flex-start', minHeight: 42, justifyContent: 'center', paddingHorizontal: 13 },
  secondaryButtonText: { color: '#ffae9b', fontWeight: '600', fontSize: 12 },
  disabled: { opacity: 0.6 },
  notice: { color: '#f0c48b', lineHeight: 20, fontSize: 12 },
  assessment: { gap: 7, padding: 12, borderRadius: 13, borderColor: 'rgba(255,255,255,.1)', borderWidth: 1 },
  verdict: { color: '#f4f2ef', fontSize: 15, fontWeight: '700' },
  action: { color: '#e8c7b9', fontSize: 12, lineHeight: 19 },
  error: { color: '#ff9ba5', fontSize: 12, lineHeight: 18 },
});
