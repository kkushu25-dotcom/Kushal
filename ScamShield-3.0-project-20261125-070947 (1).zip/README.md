# ScamShield 3.0

ScamShield is a multilingual digital-safety assistant for people in India. It provides transparent, on-demand message, URL, and QR risk assessments, account and privacy guidance, emergency response steps, and scam education.

## Repository status

This repository was empty when work began. The `/reference/` prototype and image named in the build brief were not present, so the current implementation follows the detailed written specification. The UI should be compared with the original prototype when those assets are supplied.

This is an in-progress product build. The server implements registration, sign-in, token rotation, account basics, password reset, guest message/URL/QR checks, and optional account-owned message/URL scan metadata history. QR text is stored nowhere; the Android camera decodes locally and only sends decoded content after the user chooses an assessment. Password-reset email delivery requires SMTP configuration. The web client has registration/sign-in, password recovery, a welcome guide, profile preferences, optional scan history, recent-scan summaries, a guided emergency checklist, and multilingual educational lessons/quizzes. The Android client has guest scanning, share-to-scan for shared text and links, registration/sign-in with SecureStore refresh-token rotation, native password recovery and confirmed account deletion, opt-in message/URL history, an opt-in QR assessment flow, multilingual offline emergency checklists with device-local progress and optional references, a device-local account-security checklist with official Google and Meta guidance, and the same educational lesson examples with device-local progress. Its Home now opens six category screens, shows only opted-in recent scan metadata for signed-in users, and summarizes device-local emergency checklist progress. Feature routes distinguish available flows, guidance, and unavailable modules. English/Hindi/Kannada is a persisted app language preference for supported mobile content, tab labels, and scan request explanations; several screens still have English-only interface copy. Development, preview, and production Android EAS profiles are present; push registration/sending and a built artifact remain open. Other modules are guidance or planned routes. Detection rules and their internal strength score are not calibrated on real-world data. Do not rely on a scan to make a financial decision or treat it as proof that a message or website is safe or fraudulent. No external reputation provider, LLM, push service, or production deployment is configured by default.

## Layout

- `apps/web`: responsive web client.
- `apps/mobile`: Expo Android client.
- `backend`: FastAPI service and migrations.
- `packages/api-client`: shared API types/client.
- `packages/design-tokens`: shared theme tokens.
- `packages/content`: localized education and emergency guidance.
- `data/detection-dataset`: labelled synthetic evaluation samples.
- `docs`: operational and product documentation.

## Local development

Prerequisites and exact verified versions are tracked in `DEVELOPMENT_ROADMAP.md` and pinned in each app manifest. To start the full local stack:

```powershell
docker compose up --build
```

Then open `http://localhost:5173`. The API health endpoint is `http://localhost:8000/health`; interactive API documentation is `http://localhost:8000/docs` in development.

Compose starts PostgreSQL and the API, applies local migrations, and installs the web workspace dependencies in a development container. The web and Android guest scanners call the rules API. For a web-only preview on a machine with package-registry access, install the pinned workspace packages and start Vite:

```powershell
pnpm install --link-workspace-packages
pnpm --filter @scamshield/web dev
```

Then open `http://localhost:5173`. In the current workspace, the web dependencies are installed and a production preview was built and opened in the Codex in-app browser. See `TESTING.md` for the verified preview address and remaining environment limits.

For component-specific commands, see `TESTING.md`. Android share-to-scan and camera features require a native development build; after installing dependencies and configuring Android tooling, run `pnpm --filter @scamshield/mobile android`. Expo Go does not include the share-intent native module. The EAS development, preview, and production profiles are in `apps/mobile/eas.json` and still need an Expo project and signing credentials.

## Safety principles

- A result is an assessment with uncertainty, not a guarantee.
- URLs are inspected as text and are never automatically opened.
- HTTPS does not establish legitimacy.
- Messages and financial identifiers are not stored by default or sent to an LLM.
- ScamShield does not monitor SMS, WhatsApp, or bank activity in the background.
- Emergency guidance points users to their bank and official Indian cybercrime channels; ScamShield cannot freeze accounts or recover funds.
- See [SECURITY.md](SECURITY.md) for the threat model and controls.

## Product and engineering documentation

- [Requirements](REQUIREMENTS.md)
- [Architecture](ARCHITECTURE.md)
- [Database design](DATABASE.md)
- [API contract](API_DOCUMENTATION.md) and [OpenAPI document](docs/openapi.yaml)
- [Screen map](SCREEN_MAP.md)
- [Development roadmap](DEVELOPMENT_ROADMAP.md)
- [Progress](PROGRESS.md)
- [Testing](TESTING.md)
- [Deployment](DEPLOYMENT.md)
- [Security](SECURITY.md)

