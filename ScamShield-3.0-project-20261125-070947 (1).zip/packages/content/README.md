# Shared content

Emergency resource text is bundled for offline display on mobile and includes a last-verified date. The 1930 helpline and portal were checked against the Government of India cybercrime portal on 2026-11-24. Reverify before production and update this date. Educational content must be labeled as guidance, separate from scanned content.

