import type { AuthUser, Language, SavedScanPage, ScanResult, UrlScanResult, WebAuthResult } from './types';
export type { AuthUser, DetectedEntity, Indicator, Language, MobileAuthResult, QrScanResult, SavedScan, SavedScanPage, ScanResult, UrlScanResult, UrlSignals, Verdict, WebAuthResult } from './types';

type ScanOptions = { language?: Language; signal?: AbortSignal; accessToken?: string; saveHistory?: boolean };
const API_BASE = import.meta.env?.VITE_API_BASE_URL ?? '/api/v1';

export class ApiUnavailableError extends Error {
  constructor() {
    super('The scan service is unavailable.');
    this.name = 'ApiUnavailableError';
  }
}

async function request<T>(path: string, init: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...init,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', ...init.headers },
    });
  } catch (error) {
    if (error instanceof TypeError) throw new ApiUnavailableError();
    throw error;
  }
  if (!response.ok) {
    const body = await response.json().catch(() => null) as { error?: { message?: string } } | null;
    if ([404, 502, 503, 504].includes(response.status)) throw new ApiUnavailableError();
    throw new Error(body?.error?.message ?? `Request failed (${response.status})`);
  }
  if (!response.headers.get('content-type')?.includes('application/json')) throw new ApiUnavailableError();
  return response.json() as Promise<T>;
}

async function authRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    credentials: 'include',
    headers: { ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...init.headers },
  });
  if (!response.ok) {
    const body = await response.json().catch(() => null) as { detail?: string; error?: { message?: string } } | null;
    throw new Error(body?.error?.message ?? body?.detail ?? `Request failed (${response.status})`);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export function registerWeb(email: string, password: string, language: Language, rememberMe: boolean): Promise<WebAuthResult> {
  return authRequest('/auth/register', { method: 'POST', body: JSON.stringify({ email, password, language, client_type: 'web', remember_me: rememberMe }) });
}

export function loginWeb(email: string, password: string, rememberMe: boolean): Promise<WebAuthResult> {
  return authRequest('/auth/login', { method: 'POST', body: JSON.stringify({ email, password, client_type: 'web', remember_me: rememberMe }) });
}

export function refreshWeb(csrfToken: string): Promise<WebAuthResult> {
  return authRequest('/auth/refresh', {
    method: 'POST',
    headers: { 'X-CSRF-Token': csrfToken },
    body: JSON.stringify({ client_type: 'web' }),
  });
}

export function logoutWeb(accessToken: string, csrfToken: string): Promise<void> {
  return authRequest('/auth/logout', {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}`, 'X-CSRF-Token': csrfToken },
  });
}

export function getCurrentUser(accessToken: string): Promise<AuthUser> {
  return authRequest('/users/me', { headers: { Authorization: `Bearer ${accessToken}` } });
}

export function updateCurrentUser(accessToken: string, changes: { display_name?: string | null; language?: Language }): Promise<AuthUser> {
  return authRequest('/users/me', {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${accessToken}` },
    body: JSON.stringify(changes),
  });
}

export function deleteCurrentUser(accessToken: string, csrfToken: string): Promise<void> {
  return authRequest('/users/me', {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}`, 'X-CSRF-Token': csrfToken },
  });
}

export function requestPasswordReset(email: string): Promise<{ message: string }> {
  return authRequest('/auth/password-reset/request', { method: 'POST', body: JSON.stringify({ email }) });
}

export function resetPassword(token: string, newPassword: string): Promise<void> {
  return authRequest('/auth/password-reset/confirm', {
    method: 'POST',
    body: JSON.stringify({ token, new_password: newPassword }),
  });
}

export function listSavedScans(accessToken: string, cursor?: string, limit = 20): Promise<SavedScanPage> {
  const query = new URLSearchParams({ limit: String(limit) });
  if (cursor) query.set('cursor', cursor);
  return authRequest(`/scans?${query.toString()}`, { headers: { Authorization: `Bearer ${accessToken}` } });
}

export function deleteSavedScan(accessToken: string, id: string): Promise<void> {
  return authRequest(`/scans/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` },
  });
}

export function scanMessage(message: string, options: ScanOptions = {}): Promise<ScanResult> {
  return request<ScanResult>('/scans/messages', {
    method: 'POST',
    signal: options.signal,
    headers: options.accessToken ? { Authorization: `Bearer ${options.accessToken}` } : undefined,
    body: JSON.stringify({ message, language: options.language, save_history: options.saveHistory ?? false }),
  });
}

export function scanUrl(url: string, options: ScanOptions = {}): Promise<UrlScanResult> {
  return request<UrlScanResult>('/scans/urls', {
    method: 'POST',
    signal: options.signal,
    headers: options.accessToken ? { Authorization: `Bearer ${options.accessToken}` } : undefined,
    body: JSON.stringify({ url, language: options.language, save_history: options.saveHistory ?? false }),
  });
}

