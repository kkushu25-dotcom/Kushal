export type Language = 'en' | 'hi' | 'kn';
export type Verdict = 'SAFE' | 'SUSPICIOUS' | 'SCAM';
export type Indicator = {
  id: string;
  label: string;
  why: string;
  start: number;
  end: number;
};
export type DetectedEntity = {
  type: 'url' | 'phone' | 'upi_id';
  value: string;
  start: number;
  end: number;
};
export type UrlSignals = {
  short_link: boolean;
  odd_host: boolean;
  raw_ip: boolean;
  punycode: boolean;
  risky_tld: boolean;
  excessive_subdomains: boolean;
  has_userinfo: boolean;
  unusual_port: boolean;
  lookalike_brand: boolean;
};
export type UrlScanResult = ScanResult & {
  reputation: string;
  https: boolean;
  host: string | null;
  url_signals: UrlSignals;
};
export type QrScanResult = {
  qr_type: 'url' | 'upi_payment_request' | 'text';
  notice: string;
  upi_payment: { payee: string | null; amount: string | null; note: string | null } | null;
  assessment: ScanResult | UrlScanResult;
};
export type ScanResult = {
  verdict: Verdict;
  risk_level: 'low' | 'medium' | 'high';
  category: string | null;
  confidence: number;
  uncertainty: string;
  indicators: Indicator[];
  entities: DetectedEntity[];
  recommended_actions: string[];
  language: Language;
  lesson_id: string | null;
  engine: 'rules' | 'rules+llm';
  llm_status: 'not_configured' | 'not_requested' | 'available' | 'unavailable' | 'redacted';
};

export type AuthUser = {
  id: string;
  email: string;
  display_name: string | null;
  language: Language;
  created_at: string;
};

export type WebAuthResult = {
  access_token: string;
  csrf_token?: string;
  token_type: 'bearer';
  expires_in: number;
  user: AuthUser;
};
export type MobileAuthResult = {
  access_token: string;
  refresh_token: string;
  token_type: 'bearer';
  expires_in: number;
  user: AuthUser;
};

export type SavedScan = {
  id: string;
  scan_type: 'message' | 'url';
  verdict: Verdict;
  risk_level: 'low' | 'medium' | 'high';
  category: string | null;
  language: Language;
  created_at: string;
};

export type SavedScanPage = { items: SavedScan[]; next_cursor: string | null };
