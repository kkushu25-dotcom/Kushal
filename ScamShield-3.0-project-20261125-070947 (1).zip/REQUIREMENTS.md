# Requirements and acceptance criteria

## Product objective

Help people in India detect warning signs, take safer next steps, respond to a suspected fraud, and learn practical digital-safety habits. English (`en`), Hindi (`hi`), and Kannada (`kn`) are first-class locales.

## Product rules

1. A scan returns a risk assessment, never proof. A no-match result must say that no configured warning signs were found and still state that the content was not verified safe.
2. A URL is parsed and assessed as text. The app never opens it automatically, and HTTPS is not a legitimacy signal.
3. Detection is on-demand. There is no SMS, WhatsApp, or bank monitoring without a future, explicit, permissioned integration.
4. Never request or retain OTPs, UPI PINs, CVVs, card numbers, passwords, or banking credentials. Never pass these to an LLM.
5. Store scan metadata only when the user opts into history. Do not store source message text by default.
6. Guidance and educational examples are visibly separated from inspected content and results.
7. Community submissions are unverified until reviewed; only reviewed items may be presented as confirmed.
8. Learning progress may be scored. A score must never claim to measure a person's real-world protection.
9. Emergency guidance is not a bank or law-enforcement service and cannot freeze accounts or recover funds.

## Functional requirements

| Area | Acceptance criteria |
|---|---|
| Guest access | Users can scan without registering; guest requests are more tightly rate-limited and are not persisted server-side. |
| Account security | Registration/login use Argon2id; short-lived access tokens; hashed, rotating refresh tokens with reuse detection; cookie-based web refresh is HttpOnly, Secure in production, SameSite, and CSRF-protected. |
| Message scan | Input capped at 4,000 characters; Unicode normalization; English/Hindi/Kannada identification with override; explainable rule findings include safe text offsets; result includes uncertainty, actions, engine, and LLM status. |
| URL scan | Parse without navigation; report structure signals, optional real reputation status, and the HTTPS caveat; network fetch is disabled unless the SSRF-safe fetcher is fully enabled. |
| QR | Mobile decodes locally; API receives decoded text only; UPI payment payloads are parsed as payment requests and never initiated. |
| History | Only explicit opt-in metadata is stored; ownership is enforced and foreign resources return 404. |
| Emergency | One step at a time; official-channel guidance, `tel:1930`, cybercrime.gov.in, checklist, optional non-sensitive reference numbers, persistent disclaimer; key steps work offline on mobile. |
| Protection | Account and privacy checklist items are guidance, not remote account inspection or control. |
| Learning | Localized lessons and quizzes cover ten scam categories; clear explanations; progress measures learning activity only. |
| Family | Explicit revocable consent; share alert metadata only, never message contents; audit every share. |
| Community | Moderation states and abuse controls; label unverified submissions as reported, not verified. |
| Web | Screen-to-screen navigation, persistent bottom tabs, responsive centered layout, keyboard-operable controls, WCAG 2.2 AA target, reduced motion, no private API caching. |
| Android | Expo tabs/stacks, camera permission handling, share intake, secure token storage, notifications only with real device registration, offline emergency resources. |
| Operations | OpenAPI-backed contract, migrations, health/readiness endpoints, CI, dependency audit, no secrets in source, documented deploy and rollback. |

## Non-functional targets

- Strict TypeScript and typed request/response schemas.
- Default-deny external network integrations.
- No raw message text, tokens, evidence, or financial secrets in logs.
- High-impact user data isolated by ownership checks and deleted on account deletion.
- Scanning should return a deterministic rules-only result when optional integrations fail.
- Accessibility: visible focus, semantic labels, minimum 44 px touch targets, reduced-motion support, useful error text.

## Scope boundaries and assumptions

- The supplied prototype HTML, image, and earlier prompt documents were not present in the workspace at discovery. The written build brief is the current product/design reference.
- No production API key, host, database, Expo/EAS account, push credentials, or domain was supplied. Integrations requiring those credentials remain disabled until configured.
- The feature breadth is large. Each module must be marked complete only after integration and verification; see `PROGRESS.md` for evidence and remaining work.

