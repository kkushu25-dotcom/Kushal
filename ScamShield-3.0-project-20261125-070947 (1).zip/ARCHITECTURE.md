# Architecture

## System overview

ScamShield is a monorepo with a responsive React web app, an Expo Android app, and a FastAPI modular monolith. Both clients use one versioned `/api/v1` contract. Shared packages contain API types, design tokens, and localized content.

```mermaid
flowchart LR
  Web[Web: React + TypeScript]
  Android[Android: Expo Router]
  Client[Shared typed API client]
  API[FastAPI /api/v1]
  Detection[Detection services]
  DB[(PostgreSQL)]
  Content[Localized content files]
  Reputation[Optional reputation provider]
  LLM[Optional LLM provider]
  Web --> Client
  Android --> Client
  Client --> API
  API --> Detection
  API --> DB
  API --> Content
  Detection -. opt-in, bounded .-> Reputation
  Detection -. redacted, opt-in .-> LLM
```

## Boundaries

### Web client

- React, TypeScript strict mode, Vite, React Router, TanStack Query, React Hook Form, Zod, i18next, and locally bundled Lucide icons.
- Route hierarchy: persistent application shell → category → feature. No sidebar. Home, Scan, Learn, Alerts, and Profile remain in the bottom tab bar.
- The client never stores tokens in `localStorage` and never persists private API cache entries to the offline shell.
- Message text is rendered as escaped text. Evidence highlights use offset ranges and React text spans, not HTML injection.

### Android client

- Expo Router tabs plus stacks; the Home category grid routes through category and feature screens; rotating refresh tokens use Expo SecureStore and short-lived access tokens stay in memory; Expo Camera handles QR decoding; password-reset links can deep-link into a native confirmation screen; account deletion is explicit and confirmed; shared text and links prefill the scanner without sending until the user acts; emergency and account-security checklists are stored on-device; push notification registration and delivery remain unimplemented.
- QR is decoded on-device. Decoded text is sent to the API only after the user taps the assessment button; links are never opened and UPI payments are never initiated. The endpoint parses payee, amount, and note fields only for display, with no persistence. Emergency resources are bundled for offline access.

### Backend

Routes validate transport schemas and call services. Services own detection, auth, emergency, education, and privacy policy. Repositories own persistence. Models and Alembic migrations own schema shape. `main.py` only configures the app, middleware, and routes.

### Detection

`normalization → language → entity extraction → configurable rules → optional providers → conservative classifier → localized actions`. The original message is transient by default. The provider interface receives no credentials or secrets, has strict timeouts and schema validation, and may fail without affecting rules-only scanning. URL reputation starts as `not_checked` unless a real provider is configured. Any redirect-following code is isolated behind an SSRF guard and disabled until all DNS/IP pinning tests pass.

## Learning content and progress

Lessons and quiz examples are bundled versioned JSON shared by the web and Android clients, so they work without an API connection. The current set covers ten common scam patterns in English, Hindi, and Kannada. Web completion is stored in the current browser tab; Android completion IDs are stored locally in Expo SecureStore. Neither client submits quiz attempts or stores account learning progress yet.

## QR classification

The Android camera decodes QR codes locally and stops the camera after a result. The user sees decoded content and UPI payee/amount/note details before any API request. The API classifies web addresses, UPI payment requests, or other text and performs the existing rules assessment without fetching a URL. QR scans are never added to saved history, and the client does not invoke a payment app or payment flow.

## Runtime and version policy

The brief calls for Python 3.12 and current stable Expo/React tooling. At discovery (2026-11-24), official release references show React 19.3, Expo SDK 58 / React Native 0.88, Vite 8.3, and FastAPI 0.163.1. Verify and pin exact compatible patch versions when manifests are finalized. Expo documents that SDK package versions should be installed with `expo install` and lists SDK/React Native compatibility in its [SDK reference](https://docs.expo.dev/versions/latest/). FastAPI documents explicit version pinning in its [version guide](https://fastapi.tiangolo.com/deployment/versions/); the [release notes](https://fastapi.tiangolo.com/release-notes/) list current releases. Vite's [release policy](https://vite.dev/releases) identifies supported release lines. React's [version page](https://react.dev/versions) identifies its current stable line.

Exact versions must be recorded in dependency manifests and lock files. Never use a floating `latest` tag in a deployed build.

## Data flow: message scan

1. Validate body size and guest/user rate limit.
2. Normalize Unicode and spacing in memory.
3. Detect language and extract candidate URLs, phone numbers, and UPI IDs.
4. Run named, data-configured rules; each finding stores a stable rule ID and source-text offsets.
5. Optionally request a bounded provider analysis only after secret masking and only when the user-facing privacy choice allows it.
6. Validate response shape; on any provider failure return rules-only and set a machine-readable unavailable status.
7. Return explicit uncertainty and useful next steps. Save metadata only after explicit history consent.

## Data flow: URL scan

The submitted string is parsed locally. No browser navigation occurs. Reputation checks are optional and use a server-side provider. URL fetching and redirect inspection are disabled by default; if enabled, `safe_fetch` resolves DNS itself, rejects non-public addresses, pins the connection to the vetted IP, rechecks each redirect, caps bytes/hops/time, and carries no cookies or credentials.

## Cross-cutting controls

- Pydantic validation, request size limits, CORS allow-list, secure headers, CSP, CSRF tokens for cookie refresh, rate limits, structured redacted logs, migration checks, and ownership-scoped repository operations.
- PostgreSQL is authoritative for user data. Local educational content is versioned files. No external integration may change a verdict to “safe”.
- Health checks distinguish process liveness (`/health`) from dependency readiness (`/ready`).

## Deployment topology

Docker Compose runs PostgreSQL, API, and web for local development. Production uses separately deployable web/API, managed PostgreSQL, HTTPS, production cookie settings, migrations as an explicit release step, health probes, and documented rollback. EAS builds the Android artifact. Provider credentials are server-only environment secrets.

## Risks and technical limits

1. The missing reference prototype/image prevents pixel-level comparison and copy validation.
2. Rule-based detection can miss novel scams and flag legitimate messages; every result needs uncertainty and the dataset must be evaluated before claims are made.
3. Fetching a user-supplied URL creates SSRF and DNS-rebinding risk; keep fetching disabled until guards and tests pass.
4. LLM analysis adds privacy, latency, cost, availability, and prompt-injection risks. It must remain optional and receive only masked content.
5. Official Indian emergency contact guidance and links need periodic verification and a visible last-verified date.
6. Auth, account deletion, consent, and family sharing are high-impact; avoid representing scaffolded endpoints as production-ready without integration tests and a database deployment.
7. Production service accounts, deploy targets, custom domains, push credentials, EAS access, and live smoke testing are not available in this workspace.

