# Testing and verification

Never report a check as passed unless it was run. Record command, date, result, and relevant environment constraints in `PROGRESS.md`.

## Backend

From repository root, with Python 3.12 and PostgreSQL available:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r backend\requirements-dev.txt
python -m ruff check backend
python -m mypy backend\app
python -m pytest backend\tests -q
Push-Location backend
python -m scripts.evaluate_detection
Pop-Location
```

Database integration tests require `DATABASE_URL` pointed at a disposable test database. Never run destructive tests against production. Migration checks:

```powershell
alembic -c backend\alembic.ini upgrade head
alembic -c backend\alembic.ini check
```

## Web and API contract

With Node.js and pnpm installed, from the repository root:

```powershell
pnpm install --link-workspace-packages
pnpm --filter @scamshield/web lint
pnpm --filter @scamshield/web typecheck
pnpm --filter @scamshield/web test
pnpm --filter @scamshield/web build
pnpm --filter @scamshield/mobile typecheck
pnpm --filter @scamshield/web e2e
```

The workspace uses exact dependency versions and a pnpm workspace definition. Generate `pnpm-lock.yaml` on a machine with package-registry access, then commit it and use `pnpm install --frozen-lockfile` for later installs.

Run the generated-client drift check from the repository root after the API schema/client generator is configured:

```powershell
pnpm run api:generate
git diff --exit-code -- packages\api-client
```

## Android

```powershell
pnpm install --frozen-lockfile
pnpm --filter @scamshield/mobile typecheck
cd apps\mobile
npx expo-doctor
npx expo export --platform android
```

The Android camera and share target require a development build; Expo Go does not include the share-intent native module. Use `pnpm --filter @scamshield/mobile android` to prebuild and run a local Android development client, or create an EAS development build. For an Android emulator, set `EXPO_PUBLIC_API_BASE_URL=http://10.0.2.2:8000/api/v1`; for a physical development device, use the host computer's LAN address.

An installable EAS artifact also requires an Expo account, configured project ID, Android signing setup, and the exact EAS build command documented in `DEPLOYMENT.md`.

## End-to-end and accessibility

The Playwright web server starts automatically. From the repository root:

```powershell
pnpm --filter @scamshield/web exec playwright install chromium
pnpm --filter @scamshield/web e2e
```

The browser suite covers the dashboard, welcome journey, guided emergency checklist, registration form, and mocked end-to-end checks for remember-me, opt-in history metadata, and lesson quiz completion across the ten shared localized lessons. Locale/theme switching, keyboard navigation, mobile viewport, reduced motion, and axe checks remain to be added.

QR API coverage checks URL classification, UPI payee/amount/note parsing, input limits, localized payment cautions, and the absence of QR records in saved history. The Expo camera flow still needs device validation for permission prompts/denial and barcode decoding; it cannot be fully verified by a Node typecheck alone.

Mobile auth uses a rotated refresh token in Expo SecureStore and an in-memory access token. The mobile TypeScript check should cover token restoration, authenticated scans, opt-in history, sign-out, account deletion, and deep-linked password reset once dependencies are installed; device-level SecureStore behavior and app-link handling remain unverified here. Backend auth tests include the mobile password-reset URI contract.

The Android emergency route uses bundled guidance offline and stores checklist progress and optional report references on-device. Before release, validate both scenario paths, locale switching, reference validation, SecureStore restoration, back navigation, and call/portal links on a device. The Alerts tab should clearly show that push is unavailable and must not display fabricated events; verify its language choices and links to scanning, emergency help, and account security.

The Secure My Account route stores only completed step indices in SecureStore and opens official Google and Meta security pages. Before release, validate progress restoration/reset, all three language choices, back navigation, and both external links on a device.

The Android Home category grid should open six categories, and every feature row should either reach the implemented flow, show guidance, or clearly state that the feature is unavailable. Validate deep links into URL, QR, money-loss, and account-hacked flows, plus back navigation from both category and feature routes.

Mobile language selection is shared across supported screens and persisted in SecureStore. Before release, verify persistence after restart, localized tab labels and category titles, localized emergency/alerts/learning/security/scan/profile/QR content, and that message/URL/QR requests send the selected language. Category/feature descriptions and some secondary route copy remain English-only.

The Android Home loads only the signed-in user’s opted-in scan summaries and reads emergency progress from SecureStore. Verify account switching never shows the prior user’s summaries, guest mode explains the opt-in requirement, and checklist counts restore correctly or show the secure-storage error state.

## Current authoring environment

The workspace provides Node 24.22.3 and pnpm 11.25.0. Package installation completed with `pnpm install --link-workspace-packages --package-import-method copy --store-dir .pnpm-store`; this generated `pnpm-lock.yaml`, and `.pnpm-store/` is ignored. The sandbox's pnpm wrapper still attempts to register the checkout in an external store when running filtered scripts, so the installed app binaries were invoked directly for local verification.

Verified locally on 2026-11-25:

```powershell
Push-Location apps\web
.\node_modules\.bin\tsc.CMD --noEmit
.\node_modules\.bin\vite.CMD build
Pop-Location
Push-Location apps\mobile
.\node_modules\.bin\tsc.CMD --noEmit
Pop-Location
```

The web typecheck, production build, and mobile typecheck passed. Vite reported a 618.66 kB minified JavaScript chunk, above its 500 kB warning threshold. The production preview was opened and visually verified in Codex's in-app browser at `http://127.0.0.1:4175/` (Vite selected this port because 4173 and 4174 were occupied). The backend is not running in this environment, so sign-in and API-backed scans need the API service before they can work.

No Python runtime, Docker, Java/Android SDK, or PostgreSQL service is available. No test suites were run. This workspace still has no `.git` directory, and GitHub writes remain unavailable; see the latest entry in `PROGRESS.md`.

The checked-in detection examples are synthetic fixtures designed to exercise rules, including genuine bank/OTP, delivery, cab, and food-order messages. Evaluation metrics describe this fixture set only and must not be presented as real-world scam-detection accuracy.

