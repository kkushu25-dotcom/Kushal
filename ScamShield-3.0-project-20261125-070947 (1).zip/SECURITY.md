# Security model

This is the target security model, not a claim that every control is implemented. The current server adds security response headers, request IDs, production secret-length enforcement, fixed CORS allowlists, no-store responses, redacted error bodies, Argon2 password hashes, short-lived access JWTs, hashed single-use refresh rotation with reuse-family revocation, cookie/CSRF handling for web clients, one-time password reset tokens, account deletion, opt-in owner-scoped scan metadata, and IP-based rate limits. Production requires Redis for rate limits. Guest scan text and QR payloads are processed only for the request and are not persisted, logged, or sent to an external provider. The Android QR client decodes locally and submits only after explicit user action. Mobile password reset emails use the configured app deep link; keep the token single-use and short-lived. Account deletion requires an explicit confirmation in the mobile UI and removes the user-owned records. SMTP must be configured for password reset email delivery; ownership for cases, contacts, and other future resources, evidence handling, and provider controls below remain planned work.

## Assets and trust boundaries

Assets include account credentials, access/refresh tokens, user preferences, scan metadata, emergency references, evidence files, trusted-contact details, consent records, device push tokens, and the integrity of the risk assessment. Treat user-supplied messages, URLs, QR payloads, uploaded files, provider responses, and community reports as untrusted data.

Trust boundaries are: browser/Android client ↔ HTTPS API; API ↔ PostgreSQL; API ↔ optional LLM/reputation service; API ↔ evidence object storage; API ↔ push provider. Only server-side services may hold provider secrets.

## Threats and controls

| Threat | Controls |
|---|---|
| Credential theft or refresh replay | Argon2id, short-lived access JWTs, hash-at-rest single-use refresh rotation, family revocation on reuse, Secure/HttpOnly/SameSite cookies, CSRF validation, no localStorage tokens. |
| Password reset abuse or token theft | Generic account-independent response, per-IP rate limit, high-entropy one-time token stored only as a hash, short expiry, SMTP TLS, and refresh-family revocation after reset. |
| Cross-account data access | Owner-scoped repository queries, opaque not-found responses, authorization tests covering every private resource. |
| Prompt injection or financial secrets sent to an LLM | Fixed system prompt, untrusted input delimiters, secret detection/redaction before provider calls, structured output schema, no credentials in logs, provider off unless configured and user choice allows. |
| SSRF, metadata theft, DNS rebinding | Do not fetch user URLs by default. If enabled, allow HTTP(S) ports 80/443 only, resolve and classify every address, reject non-public IPv4/IPv6, pin IP to connection, repeat on redirect, limit hops/bytes/time, no credentials/cookies, test adversarial DNS and redirect cases. |
| Stored/reflected XSS from scan or report text | Treat all text as text, React escaping, no `dangerouslySetInnerHTML`, highlight through safe ranges/spans, sanitize any future rich lesson content. |
| Brute force, scan abuse, enumeration | Per-IP and per-user limits, stricter anonymous and scan limits, generic auth/reset errors, request size caps and timeouts. |
| Malicious evidence upload | Allowlist and inspect file type/content, strict size cap, randomized object key, storage outside web root, reject executables, malware scan, signed access, ownership checks. |
| Secret leakage via logs or analytics | Structured allowlisted event fields, redact tokens and payloads, never log message text/evidence/OTP/PIN/card/account data; minimize analytics. |
| Misleading risk result | Always expose uncertainty; no-match wording is not “safe”; HTTPS is not proof; optional provider failure leaves rules result and visible unavailable status. |
| Unauthorized family sharing | Explicit scoped consent, revocation, share only alert metadata, audit every share, never share message contents. |
| Private data survives account deletion | Transactional deletion service, cascading FKs, object deletion retry queue, test data-export/deletion flow. |

## Secret handling

Production must set high-entropy signing keys, database credentials, provider keys, and storage credentials through a secret manager or deployment environment. `.env.example` contains names and safe examples only. Never check in real `.env` files or credentials. Rotate any key suspected of exposure.

## Release gates

Before production: pass auth/ownership and SSRF tests; run dependency vulnerability checks; review migrations and account deletion; configure strict CORS, CSP/security headers, secure cookies, HTTPS and rate limits; verify logs contain no sample payloads; review evidence storage; and run a live smoke test. See `TESTING.md` and `DEPLOYMENT.md`.

## Incident response

Disable affected provider integrations, rotate secrets, revoke refresh-token families, preserve access/audit metadata without copying private payloads into tickets, assess scope, notify affected users and authorities as required by the deployment's legal review, and publish a recovery note. ScamShield guidance must direct fraud victims to their bank and official Indian cybercrime channels.

This is an engineering threat model, not a completed independent security audit. Production launch requires review by a qualified security engineer.

