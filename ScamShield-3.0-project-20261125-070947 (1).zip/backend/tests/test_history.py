from app.core.config import Settings
from app.core.database import create_database_engine
from app.main import create_app
from app.models import Base
from fastapi.testclient import TestClient


def make_client() -> TestClient:
    engine = create_database_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    settings = Settings(app_env="test", database_url="sqlite+pysqlite:///:memory:")
    return TestClient(create_app(settings=settings, database_engine=engine))


def register(client: TestClient, email: str) -> dict[str, object]:
    response = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": "correct horse battery staple"},
    )
    assert response.status_code == 201
    return response.json()


def test_saved_history_is_opt_in_owner_scoped_and_deletable() -> None:
    with make_client() as client:
        owner = register(client, "owner@example.com")
        other = register(client, "other@example.com")
        owner_headers = {"Authorization": f"Bearer {owner['access_token']}"}
        other_headers = {"Authorization": f"Bearer {other['access_token']}"}
        guest_save = client.post(
            "/api/v1/scans/messages",
            json={"message": "private reference 93820", "save_history": True},
        )
        first_scan = client.post(
            "/api/v1/scans/messages",
            headers=owner_headers,
            json={"message": "private reference 93820", "save_history": True},
        )
        second_scan = client.post(
            "/api/v1/scans/urls",
            headers=owner_headers,
            json={"url": "https://example.org/special-path", "save_history": True},
        )
        page_one = client.get("/api/v1/scans?limit=1", headers=owner_headers)
        next_cursor = page_one.json()["next_cursor"]
        page_two = client.get(f"/api/v1/scans?limit=1&cursor={next_cursor}", headers=owner_headers)
        other_history = client.get("/api/v1/scans", headers=other_headers)
        foreign_delete = client.delete(f"/api/v1/scans/{page_one.json()['items'][0]['id']}", headers=other_headers)
        deleted = client.delete(f"/api/v1/scans/{page_one.json()['items'][0]['id']}", headers=owner_headers)
        remaining = client.get("/api/v1/scans", headers=owner_headers)

    assert guest_save.status_code == 401
    assert first_scan.status_code == second_scan.status_code == 200
    assert page_one.status_code == page_two.status_code == 200
    assert len(page_one.json()["items"]) == len(page_two.json()["items"]) == 1
    assert page_one.json()["next_cursor"]
    assert other_history.json()["items"] == []
    assert "private reference 93820" not in page_one.text + page_two.text
    assert "special-path" not in page_one.text + page_two.text
    assert foreign_delete.status_code == 404
    assert deleted.status_code == 204
    assert len(remaining.json()["items"]) == 1
