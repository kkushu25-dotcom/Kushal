from hashlib import sha256
from urllib.parse import parse_qs, urlsplit
from uuid import UUID

from app.api.v1 import auth as auth_routes
from app.core.config import Settings
from app.core.database import create_database_engine
from app.main import create_app
from app.models import Base, PasswordResetToken, User
from fastapi.testclient import TestClient


def make_client(settings: Settings | None = None) -> TestClient:
    engine = create_database_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    current_settings = settings or Settings(app_env="test", database_url="sqlite+pysqlite:///:memory:")
    return TestClient(create_app(settings=current_settings, database_engine=engine))


def register(client: TestClient, *, client_type: str = "mobile") -> dict[str, object]:
    response = client.post(
        "/api/v1/auth/register",
        json={"email": "person@example.com", "password": "correct horse battery staple", "client_type": client_type},
    )
    assert response.status_code == 201
    return response.json()


def test_registration_hashes_password_and_returns_mobile_refresh_token() -> None:
    with make_client() as client:
        result = register(client)
        user_id = result["user"]["id"]
        with client.app.state.session_factory() as session:
            user = session.get(User, UUID(user_id))
        assert user is not None
        assert user.password_hash != "correct horse battery staple"
        assert user.password_hash.startswith("$argon2")
    assert result["refresh_token"]
    assert result["token_type"] == "bearer"


def test_duplicate_registration_and_login_use_generic_conflict_errors() -> None:
    with make_client() as client:
        register(client)
        duplicate = client.post(
            "/api/v1/auth/register",
            json={"email": "person@example.com", "password": "correct horse battery staple"},
        )
        unknown = client.post("/api/v1/auth/login", json={"email": "nobody@example.com", "password": "wrong-password"})
        wrong = client.post("/api/v1/auth/login", json={"email": "person@example.com", "password": "wrong-password"})
    assert duplicate.status_code == 409
    assert unknown.status_code == wrong.status_code == 401
    assert unknown.json()["error"]["code"] == wrong.json()["error"]["code"] == "unauthorized"
    assert unknown.json()["error"]["message"] == wrong.json()["error"]["message"]


def test_refresh_rotation_and_reuse_revokes_the_whole_family() -> None:
    with make_client() as client:
        first = register(client)
        old_refresh = first["refresh_token"]
        rotated = client.post("/api/v1/auth/refresh", json={"refresh_token": old_refresh, "client_type": "mobile"})
        assert rotated.status_code == 200
        current_refresh = rotated.json()["refresh_token"]
        reused = client.post("/api/v1/auth/refresh", json={"refresh_token": old_refresh, "client_type": "mobile"})
        after_reuse = client.post("/api/v1/auth/refresh", json={"refresh_token": current_refresh, "client_type": "mobile"})
    assert reused.status_code == 401
    assert after_reuse.status_code == 401


def test_web_refresh_uses_http_only_cookie_and_csrf_header() -> None:
    with make_client() as client:
        result = register(client, client_type="web")
        assert "refresh_token" not in result
        assert client.cookies.get("scamshield_refresh")
        csrf = result["csrf_token"]
        rejected = client.post("/api/v1/auth/refresh")
        rotated = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": csrf})
    assert rejected.status_code == 403
    assert rotated.status_code == 200
    assert "refresh_token" not in rotated.json()


def test_web_remember_me_choice_survives_refresh_rotation() -> None:
    with make_client() as client:
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "session@example.com",
                "password": "correct horse battery staple",
                "client_type": "web",
                "remember_me": False,
            },
        )
        csrf = response.json()["csrf_token"]
        session_cookie = next(value for value in response.headers.get_list("set-cookie") if value.startswith("scamshield_refresh="))
        rotated = client.post("/api/v1/auth/refresh", headers={"X-CSRF-Token": csrf})
        rotated_cookie = next(value for value in rotated.headers.get_list("set-cookie") if value.startswith("scamshield_refresh="))
    assert response.status_code == 201
    assert rotated.status_code == 200
    assert "max-age=" not in session_cookie.lower()
    assert "max-age=" not in rotated_cookie.lower()


def test_web_remember_me_sets_a_persistent_refresh_cookie() -> None:
    with make_client() as client:
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "remember@example.com",
                "password": "correct horse battery staple",
                "client_type": "web",
                "remember_me": True,
            },
        )
        refresh_cookie = next(value for value in response.headers.get_list("set-cookie") if value.startswith("scamshield_refresh="))
    assert response.status_code == 201
    assert "max-age=" in refresh_cookie.lower()


def test_user_patch_and_delete_require_access_token() -> None:
    with make_client() as client:
        anonymous = client.get("/api/v1/users/me")
        result = register(client)
        headers = {"Authorization": f"Bearer {result['access_token']}"}
        changed = client.patch("/api/v1/users/me", headers=headers, json={"display_name": "  Asha  ", "language": "hi"})
        deleted = client.delete("/api/v1/users/me", headers=headers)
        after_delete = client.get("/api/v1/users/me", headers=headers)
        revoked_refresh = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": result["refresh_token"], "client_type": "mobile"},
        )
    assert anonymous.status_code == 401
    assert changed.status_code == 200
    assert changed.json()["display_name"] == "Asha"
    assert changed.json()["language"] == "hi"
    assert deleted.status_code == 204
    assert after_delete.status_code == 401
    assert revoked_refresh.status_code == 401


def test_web_account_deletion_clears_refresh_and_csrf_cookies() -> None:
    with make_client() as client:
        result = register(client, client_type="web")
        headers = {"Authorization": f"Bearer {result['access_token']}"}
        deleted = client.delete("/api/v1/users/me", headers=headers)
    assert deleted.status_code == 204
    assert client.cookies.get("scamshield_refresh") is None
    assert client.cookies.get("scamshield_csrf") is None


def test_logout_revokes_refresh_family() -> None:
    with make_client() as client:
        result = register(client)
        headers = {"Authorization": f"Bearer {result['access_token']}"}
        logged_out = client.post("/api/v1/auth/logout", headers=headers)
        refreshed = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": result["refresh_token"], "client_type": "mobile"},
        )
    assert logged_out.status_code == 204
    assert refreshed.status_code == 401


def test_password_reset_is_generic_single_use_and_revokes_sessions(monkeypatch) -> None:
    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(auth_routes, "_deliver_password_reset_email", lambda _settings, email, url: sent.append((email, url)))
    settings = Settings(
        app_env="test",
        database_url="sqlite+pysqlite:///:memory:",
        smtp_host="smtp.example.test",
        smtp_from_email="support@example.test",
    )
    with make_client(settings) as client:
        account = register(client)
        existing = client.post("/api/v1/auth/password-reset/request", json={"email": "person@example.com"})
        missing = client.post("/api/v1/auth/password-reset/request", json={"email": "nobody@example.com"})
        token = parse_qs(urlsplit(sent[0][1]).query)["token"][0]
        with client.app.state.session_factory() as session:
            stored = session.query(PasswordResetToken).one()
            stored_digest = stored.token_hash

        updated = client.post(
            "/api/v1/auth/password-reset/confirm",
            json={"token": token, "new_password": "a-new-correct-horse-battery"},
        )
        replay = client.post(
            "/api/v1/auth/password-reset/confirm",
            json={"token": token, "new_password": "another-correct-horse-battery"},
        )
        old_access = client.get("/api/v1/users/me", headers={"Authorization": f"Bearer {account['access_token']}"})
        old_refresh = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": account["refresh_token"], "client_type": "mobile"},
        )
        signed_in = client.post(
            "/api/v1/auth/login",
            json={"email": "person@example.com", "password": "a-new-correct-horse-battery"},
        )

    assert existing.status_code == missing.status_code == 202
    assert existing.json() == missing.json()
    assert [item[0] for item in sent] == ["person@example.com"]
    assert stored_digest == sha256(token.encode()).hexdigest()
    assert stored_digest != token
    assert updated.status_code == 204
    assert replay.status_code == 400
    assert old_access.status_code == old_refresh.status_code == 401
    assert signed_in.status_code == 200


def test_password_reset_token_expiry_is_enforced(monkeypatch) -> None:
    sent: list[str] = []
    monkeypatch.setattr(auth_routes, "_deliver_password_reset_email", lambda _settings, _email, url: sent.append(url))
    settings = Settings(
        app_env="test",
        database_url="sqlite+pysqlite:///:memory:",
        smtp_host="smtp.example.test",
        smtp_from_email="support@example.test",
    )
    with make_client(settings) as client:
        register(client)
        requested = client.post("/api/v1/auth/password-reset/request", json={"email": "person@example.com"})
        token = parse_qs(urlsplit(sent[0]).query)["token"][0]
        with client.app.state.session_factory() as session:
            stored = session.query(PasswordResetToken).one()
            stored.expires_at = stored.expires_at.replace(year=2000)
            session.commit()
        expired = client.post(
            "/api/v1/auth/password-reset/confirm",
            json={"token": token, "new_password": "a-new-correct-horse-battery"},
        )
    assert requested.status_code == 202
    assert expired.status_code == 400


def test_mobile_password_reset_uses_app_deep_link(monkeypatch) -> None:
    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(auth_routes, "_deliver_password_reset_email", lambda _settings, email, url: sent.append((email, url)))
    settings = Settings(
        app_env="test",
        database_url="sqlite+pysqlite:///:memory:",
        smtp_host="smtp.example.test",
        smtp_from_email="support@example.test",
        password_reset_mobile_url="scamshield://auth/reset-password",
    )
    with make_client(settings) as client:
        register(client)
        requested = client.post(
            "/api/v1/auth/password-reset/request",
            json={"email": "person@example.com", "client_type": "mobile"},
        )
    assert requested.status_code == 202
    assert sent[0][0] == "person@example.com"
    assert urlsplit(sent[0][1]).scheme == "scamshield"
    assert urlsplit(sent[0][1]).netloc == "auth"
    assert urlsplit(sent[0][1]).path == "/reset-password"
    assert parse_qs(urlsplit(sent[0][1]).query).get("token")

