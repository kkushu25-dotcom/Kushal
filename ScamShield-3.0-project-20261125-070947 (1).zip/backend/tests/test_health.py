from app.core.config import Settings
from app.core.database import create_database_engine
from app.main import create_app
from fastapi.testclient import TestClient


def make_test_client() -> TestClient:
    engine = create_database_engine("sqlite+pysqlite:///:memory:")
    settings = Settings(app_env="test", database_url="sqlite+pysqlite:///:memory:")
    return TestClient(create_app(settings=settings, database_engine=engine))


def test_health_returns_ok_and_security_headers() -> None:
    with make_test_client() as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-request-id"]


def test_readiness_checks_database_connection() -> None:
    with make_test_client() as client:
        response = client.get("/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ready"}


def test_message_scan_does_not_echo_input_and_warns_about_otp_pressure() -> None:
    with make_test_client() as client:
        response = client.post("/api/v1/scans/messages", json={"message": "Urgent: send your OTP immediately to avoid account blocked"})
    assert response.status_code == 200
    assert response.json()["verdict"] == "SCAM"
    assert response.json()["llm_status"] == "not_configured"
    assert "Urgent: send your OTP immediately" not in response.text


def test_message_scan_treats_no_match_as_unproven_safe_and_not_stored() -> None:
    with make_test_client() as client:
        response = client.post("/api/v1/scans/messages", json={"message": "See you at lunch tomorrow.", "save_history": False})
    assert response.status_code == 200
    assert response.json()["verdict"] == "SAFE"
    assert "cannot prove" in response.json()["uncertainty"]


def test_url_scan_does_not_fetch_shortened_url() -> None:
    with make_test_client() as client:
        response = client.post("/api/v1/scans/urls", json={"url": "https://bit.ly/example"})
    assert response.status_code == 200
    assert response.json()["verdict"] == "SUSPICIOUS"
    assert response.json()["reputation"] == "not_checked"
    assert response.json()["host"] == "bit.ly"


def test_scan_rejects_blank_input_and_requires_account_for_history() -> None:
    with make_test_client() as client:
        blank = client.post("/api/v1/scans/messages", json={"message": "   "})
        history = client.post("/api/v1/scans/messages", json={"message": "hello", "save_history": True})
    assert blank.status_code == 422
    assert history.status_code == 401
    assert history.json()["error"]["code"] == "unauthorized"


def test_url_scan_rejects_non_url_text() -> None:
    with make_test_client() as client:
        response = client.post("/api/v1/scans/urls", json={"url": "not a url"})
    assert response.status_code == 422

