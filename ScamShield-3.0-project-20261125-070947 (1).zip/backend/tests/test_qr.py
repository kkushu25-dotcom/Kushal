from app.core.config import Settings
from app.core.database import create_database_engine
from app.main import create_app
from app.models import Base
from fastapi.testclient import TestClient


def make_client() -> TestClient:
    engine = create_database_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    settings = Settings(app_env="test", database_url="sqlite+pysqlite:///:memory:")
    return TestClient(create_app(settings=settings, database_engine=engine))


def test_qr_endpoint_classifies_url_without_opening_or_persisting_it() -> None:
    with make_client() as client:
        result = client.post(
            "/api/v1/scans/qr",
            json={"decoded_text": "https://example.org/offer", "language": "en"},
        )

    assert result.status_code == 200
    body = result.json()
    assert body["qr_type"] == "url"
    assert body["assessment"]["host"] == "example.org"
    assert "never opened" in body["notice"]
    assert body["upi_payment"] is None


def test_qr_endpoint_parses_upi_request_and_warns_without_initiating_payment() -> None:
    with make_client() as client:
        result = client.post(
            "/api/v1/scans/qr",
            json={
                "decoded_text": "upi://pay?pa=merchant%40upi&pn=Sample+Shop&am=25.50&tn=Order+refund",
                "language": "en",
            },
        )

    assert result.status_code == 200
    body = result.json()
    assert body["qr_type"] == "upi_payment_request"
    assert body["upi_payment"] == {"payee": "merchant@upi", "amount": "25.50", "note": "Order refund"}
    assert "will not receive money" in body["notice"]
    assert "never initiates a payment" in body["notice"]


def test_qr_payment_caution_is_localized_and_uri_match_is_exact() -> None:
    with make_client() as client:
        hindi = client.post(
            "/api/v1/scans/qr",
            json={"decoded_text": "upi://pay?pa=merchant%40upi", "language": "hi"},
        )
        kannada = client.post(
            "/api/v1/scans/qr",
            json={"decoded_text": "upi://pay?pa=merchant%40upi", "language": "kn"},
        )
        unrelated = client.post(
            "/api/v1/scans/qr",
            json={"decoded_text": "upi://payment?pa=merchant%40upi", "language": "en"},
        )

    assert hindi.status_code == kannada.status_code == unrelated.status_code == 200
    assert hindi.json()["qr_type"] == kannada.json()["qr_type"] == "upi_payment_request"
    assert "पैसे प्राप्त नहीं" in hindi.json()["notice"]
    assert "ಹಣ ಸ್ವೀಕರಿಸಲಾಗುವುದಿಲ್ಲ" in kannada.json()["notice"]
    assert unrelated.json()["qr_type"] == "text"


def test_qr_payload_is_never_added_to_saved_scan_history() -> None:
    with make_client() as client:
        account = client.post(
            "/api/v1/auth/register",
            json={"email": "qr-owner@example.com", "password": "correct horse battery staple"},
        )
        headers = {"Authorization": f"Bearer {account.json()['access_token']}"}
        scanned = client.post(
            "/api/v1/scans/qr",
            headers=headers,
            json={"decoded_text": "upi://pay?pa=merchant%40upi&am=25.50"},
        )
        history = client.get("/api/v1/scans", headers=headers)

    assert scanned.status_code == 200
    assert history.status_code == 200
    assert history.json()["items"] == []


def test_qr_endpoint_rejects_blank_and_oversized_payloads() -> None:
    with make_client() as client:
        blank = client.post("/api/v1/scans/qr", json={"decoded_text": "  "})
        oversized = client.post("/api/v1/scans/qr", json={"decoded_text": "a" * 2049})

    assert blank.status_code == 422
    assert oversized.status_code == 422
