from app.core.rate_limit import RateLimiter
from app.services.detection.entities import extract_entities
from app.services.detection.language import detect_language
from app.services.detection.normalization import normalize_message
from app.services.rules import RULES, assess_message, assess_url, inspect_url


def test_sensitive_information_request_with_urgency_is_strongly_flagged() -> None:
    result = assess_message("Urgent: send your OTP immediately to avoid account blocked")
    assert result["verdict"] == "SCAM"
    assert len(result["indicators"]) >= 2
    assert "cannot prove" not in str(result["uncertainty"])


def test_warning_about_never_sharing_otp_is_not_flagged_for_credentials() -> None:
    result = assess_message("Never share your OTP. Your bank will never ask for it.")
    assert result["verdict"] == "SAFE"
    assert result["indicators"] == []
    assert "cannot prove" in str(result["uncertainty"])


def test_url_inspection_accepts_bare_domains_without_claiming_https() -> None:
    result = inspect_url("example.com/path")
    assert result["valid"] is True
    assert result["https"] is False
    assert result["host"] == "example.com"


def test_url_inspection_flags_raw_ip_without_network_access() -> None:
    result = assess_url("http://192.0.2.10/login")
    assert result["verdict"] == "SUSPICIOUS"
    assert result["reputation"] == "not_checked"
    assert result["host"] == "192.0.2.10"


def test_local_rate_limiter_blocks_after_configured_limit() -> None:
    limiter = RateLimiter()
    assert limiter.consume("test", limit=2, window_seconds=60) is None
    assert limiter.consume("test", limit=2, window_seconds=60) is None
    retry_after = limiter.consume("test", limit=2, window_seconds=60)
    assert isinstance(retry_after, int) and retry_after > 0


def test_rules_are_configured_as_ten_explainable_categories() -> None:
    categories = {rule.category for rule in RULES}
    categories.add(str(assess_url("https://bit.ly/example", language="en")["category"]))
    assert {
        "kyc_phishing",
        "bank_impersonation",
        "upi_payment_fraud",
        "lottery_prize_fraud",
        "fake_job_offer",
        "investment_fraud",
        "customer_care_scam",
        "delivery_parcel_fraud",
        "remote_access_scam",
        "phishing_link",
    }.issubset(categories)


def test_multilingual_fixture_gaps_are_classified_by_their_specific_categories() -> None:
    cases = (
        ("Your Aadhaar KYC has expired; confirm your bank details within 10 minutes.", "en", "kyc_phishing"),
        ("ಸರ್ಕಾರಿ ಅಧಿಕಾರಿ ಎಂದು ಹೇಳಿ, ಹಣ ಬಿಡುಗಡೆಗೆ ಪಿನ್ ಕಳುಹಿಸಿ.", "kn", "bank_impersonation"),
        ("\u0C97\u0CCD\u0CB0\u0CBE\u0CB9\u0C95 \u0CB8\u0CC7\u0CB5\u0CC6\u0C97\u0CC6 \u0C95\u0CB0\u0CC6 OTP", "kn", "customer_care_scam"),
        ("पैसे वापस लेने के लिए कस्टमर केयर से अभी संपर्क करें।", "hi", "customer_care_scam"),
        ("पैकेज सीमा शुल्क में है, डिलीवरी के लिए शुल्क भेजें।", "hi", "delivery_parcel_fraud"),
        ("Install the remote access app now and keep your banking app open.", "en", "remote_access_scam"),
        ("पैसा वापस पाने हेतु अपनी स्क्रीन साझा करें और एक्सेस दें।", "hi", "remote_access_scam"),
    )
    for message, language, expected_category in cases:
        result = assess_message(message, language=language)
        assert result["verdict"] != "SAFE"
        assert result["category"] == expected_category


def test_unicode_compatibility_and_invisible_characters_keep_source_offsets() -> None:
    message = "Check this now: O\u200bT\u200bP required"
    normalized = normalize_message(message)
    result = assess_message(message)
    credential = next(item for item in result["indicators"] if item["id"] == "credentials")
    start, end = credential["start"], credential["end"]
    assert normalized.value == message.replace("\u200b", "")
    assert message[start:end].replace("\u200b", "") == "OTP"


def test_supported_script_detection_and_language_override() -> None:
    assert detect_language("आपका खाता बंद हो जाएगा") == "hi"
    assert detect_language("ನಿಮ್ಮ ಖಾತೆ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ") == "kn"
    assert detect_language("Your account may be blocked") == "en"
    hindi = assess_message("आपका खाता बंद हो जाएगा")
    override = assess_message("ನಿಮ್ಮ ಖಾತೆ ತಕ್ಷಣ ಪರಿಶೀಲಿಸಿ", language="hi")
    assert hindi["language"] == "hi"
    assert override["language"] == "hi"


def test_entity_extraction_returns_offsets_into_original_text() -> None:
    message = "Call +91 98765 43210; UPI: asha@ybl; link https://example.com"
    result = assess_message(message)
    entities = extract_entities(normalize_message(message))
    assert {item["type"] for item in entities} == {"url", "phone", "upi_id"}
    for entity in result["entities"]:
        assert message[int(entity["start"]) : int(entity["end"])] == entity["value"]


def test_url_structure_flags_userinfo_lookalikes_and_risky_hosts() -> None:
    userinfo = inspect_url("https://user@example.com/login")
    lookalike = inspect_url("https://sbi-secure-login.com/verify")
    risky_tld = inspect_url("https://account.example.zip/")
    excessive = inspect_url("https://a.b.c.d.e.example.com/")
    unusual_port = inspect_url("https://example.com:8443/")
    assert userinfo["valid"] is True and userinfo["has_userinfo"] is True
    assert userinfo["odd_host"] is True
    assert lookalike["lookalike_brand"] is True
    assert risky_tld["risky_tld"] is True
    assert excessive["excessive_subdomains"] is True
    assert unusual_port["unusual_port"] is True


def test_rule_engine_preserves_user_url_red_flags_and_uncertainty() -> None:
    result = assess_url("https://sbi-secure-login.com/update", language="en")
    assert result["verdict"] == "SUSPICIOUS"
    assert result["url_signals"]["lookalike_brand"] is True
    assert result["reputation"] == "not_checked"
    assert "can be wrong" in result["uncertainty"]

