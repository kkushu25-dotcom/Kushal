from __future__ import annotations

import argparse
import json
import time
from collections import Counter
from pathlib import Path
from typing import Any

from app.services.rules import assess_message

DEFAULT_DATASET = Path(__file__).resolve().parents[2] / "data" / "detection-dataset" / "messages.jsonl"


def _ratio(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 0.0


def evaluate(dataset_path: Path) -> dict[str, Any]:
    records = [json.loads(line) for line in dataset_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(records) < 150:
        raise ValueError(f"The detection dataset must contain at least 150 examples; found {len(records)}")

    true_positive = false_positive = false_negative = true_negative = 0
    categories = sorted({record["category"] for record in records if record["label"] == "SCAM"})
    category_counts = {category: {"tp": 0, "fp": 0, "fn": 0} for category in categories}
    out_of_scope_predictions: Counter[str] = Counter()
    missed_examples: list[dict[str, str]] = []
    category_mismatches: list[dict[str, str]] = []
    elapsed_ms: list[float] = []
    supported_languages = {"en", "hi", "kn"}
    for record in records:
        if record.get("language") not in supported_languages or record.get("label") not in {"SCAM", "SAFE"}:
            raise ValueError(f"Invalid language or label in dataset record {record.get('id', '<unknown>')}")
        start = time.perf_counter_ns()
        result = assess_message(record["message"], record["language"])
        elapsed_ms.append((time.perf_counter_ns() - start) / 1_000_000)
        actual_positive = record["label"] == "SCAM"
        predicted_positive = result["verdict"] != "SAFE"
        if actual_positive and predicted_positive:
            true_positive += 1
        elif actual_positive:
            false_negative += 1
        elif predicted_positive:
            false_positive += 1
        else:
            true_negative += 1

        actual_category = record["category"] if actual_positive else None
        predicted_category = result["category"] if predicted_positive else None
        if actual_category:
            counts = category_counts[actual_category]
            if predicted_category == actual_category:
                counts["tp"] += 1
            else:
                counts["fn"] += 1
                category_mismatches.append(
                    {"id": record.get("id", "<unknown>"), "actual": actual_category, "predicted": predicted_category or "SAFE"}
                )
            if not predicted_positive:
                missed_examples.append(
                    {"id": record.get("id", "<unknown>"), "category": actual_category, "message": record["message"]}
                )
        if predicted_category and predicted_category != actual_category:
            if predicted_category in category_counts:
                category_counts[predicted_category]["fp"] += 1
            else:
                out_of_scope_predictions[predicted_category] += 1

    per_category = {
        category: {
            "precision": _ratio(counts["tp"], counts["tp"] + counts["fp"]),
            "recall": _ratio(counts["tp"], counts["tp"] + counts["fn"]),
            "true_positives": counts["tp"],
            "false_positives": counts["fp"],
            "false_negatives": counts["fn"],
        }
        for category, counts in sorted(category_counts.items())
    }
    total = true_positive + false_positive + false_negative + true_negative
    return {
        "dataset": str(dataset_path),
        "dataset_kind": "synthetic labeled fixtures; metrics do not estimate real-world performance",
        "examples": total,
        "confusion_matrix": {
            "true_positive": true_positive,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "true_negative": true_negative,
        },
        "precision": _ratio(true_positive, true_positive + false_positive),
        "recall": _ratio(true_positive, true_positive + false_negative),
        "false_positive_rate": _ratio(false_positive, false_positive + true_negative),
        "false_negative_rate": _ratio(false_negative, false_negative + true_positive),
        "mean_latency_ms": round(sum(elapsed_ms) / len(elapsed_ms), 3),
        "exact_category_accuracy_on_scam_examples": _ratio(
            sum(counts["tp"] for counts in category_counts.values()), sum(counts["tp"] + counts["fn"] for counts in category_counts.values())
        ),
        "out_of_scope_category_predictions": dict(sorted(out_of_scope_predictions.items())),
        "missed_examples": missed_examples,
        "category_mismatches": category_mismatches,
        "per_category": per_category,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate rules against the labeled synthetic fixture set.")
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    args = parser.parse_args()
    print(json.dumps(evaluate(args.dataset), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
