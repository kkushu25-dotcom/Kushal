"""Command-line utilities for the ScamShield backend."""
