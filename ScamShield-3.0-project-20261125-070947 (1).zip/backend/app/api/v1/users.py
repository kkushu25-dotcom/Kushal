from __future__ import annotations

from datetime import datetime
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy.orm import Session

from app.api.v1.auth import AuthenticatedSession, get_authenticated_session
from app.core.database import get_database_session
from app.models import User
from app.services.rules import Language

router = APIRouter(prefix="/users", tags=["users"])


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    email: str
    display_name: str | None
    language: Language
    created_at: datetime


class UserPatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    display_name: str | None = Field(default=None, max_length=80)
    language: Language | None = None

    @field_validator("display_name")
    @classmethod
    def normalize_display_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        return normalized or None


def _user_or_unauthorized(principal: AuthenticatedSession) -> User:
    user = principal.user
    if user.deleted_at is not None:
        raise HTTPException(status_code=401, detail="Authentication is required")
    return user


@router.get("/me", response_model=UserResponse)
def get_me(principal: Annotated[AuthenticatedSession, Depends(get_authenticated_session)]) -> User:
    return _user_or_unauthorized(principal)


@router.patch("/me", response_model=UserResponse)
def patch_me(
    payload: UserPatchRequest,
    principal: Annotated[AuthenticatedSession, Depends(get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
) -> User:
    user = _user_or_unauthorized(principal)
    changes = payload.model_dump(exclude_unset=True)
    if "language" in changes and changes["language"] is None:
        raise HTTPException(status_code=422, detail="Language cannot be empty")
    for key, value in changes.items():
        setattr(user, key, value)
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


@router.delete("/me", status_code=204)
def delete_me(
    request: Request,
    principal: Annotated[AuthenticatedSession, Depends(get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
    response: Response,
) -> Response:
    user = _user_or_unauthorized(principal)
    session.delete(user)
    session.commit()
    secure = request.app.state.settings.app_env == "production"
    response.delete_cookie("scamshield_refresh", path="/api/v1/auth", secure=secure, httponly=True, samesite="lax")
    response.delete_cookie("scamshield_csrf", path="/", secure=secure, samesite="lax")
    response.status_code = 204
    return response
