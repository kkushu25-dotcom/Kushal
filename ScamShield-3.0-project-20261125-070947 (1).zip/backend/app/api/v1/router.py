from __future__ import annotations

import base64
import re
from binascii import Error as Base64Error
from datetime import UTC, datetime
from typing import Annotated, Literal
from urllib.parse import parse_qs, urlsplit
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.api.v1 import auth, users
from app.core.database import get_database_session
from app.core.rate_limit import enforce_rate_limit
from app.models import SavedScan
from app.services.rules import Language, assess_message, assess_url, inspect_url

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(users.router)


class SavedScanResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    scan_type: Literal["message", "url"]
    verdict: Literal["SAFE", "SUSPICIOUS", "SCAM"]
    risk_level: Literal["low", "medium", "high"]
    category: str | None
    language: Language
    created_at: datetime


class SavedScanPage(BaseModel):
    items: list[SavedScanResponse]
    next_cursor: str | None


def _require_history_owner(principal: auth.AuthenticatedSession | None) -> auth.AuthenticatedSession:
    if principal is None:
        raise HTTPException(status_code=401, detail="Sign in to save scan history")
    return principal


def _store_scan(session: Session, principal: auth.AuthenticatedSession, scan_type: Literal["message", "url"], result: dict[str, object]) -> None:
    # Keep only assessment metadata; source text, URLs, phone numbers, and entities are excluded.
    session.add(
        SavedScan(
            user_id=principal.user.id,
            scan_type=scan_type,
            verdict=str(result["verdict"]),
            risk_level=str(result["risk_level"]),
            category=result["category"] if isinstance(result["category"], str) else None,
            language=str(result["language"]),
        )
    )
    session.commit()


def _encode_scan_cursor(item: SavedScan) -> str:
    value = f"{item.created_at.isoformat()}|{item.id}"
    return base64.urlsafe_b64encode(value.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_scan_cursor(cursor: str) -> tuple[datetime, UUID]:
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        value = base64.b64decode(padded, altchars=b"-_", validate=True).decode("utf-8")
        created_text, id_text = value.split("|", 1)
        created_at = datetime.fromisoformat(created_text)
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)
        return created_at, UUID(id_text)
    except (Base64Error, UnicodeDecodeError, ValueError):
        raise HTTPException(status_code=422, detail="Invalid scan-history cursor") from None


@api_router.get("/scans", response_model=SavedScanPage, tags=["scans"])
def list_saved_scans(
    request: Request,
    principal: Annotated[auth.AuthenticatedSession, Depends(auth.get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
    limit: Annotated[int, Query(ge=1, le=50)] = 20,
    cursor: Annotated[str | None, Query(max_length=256)] = None,
) -> SavedScanPage:
    enforce_rate_limit(request, "scan_history", 60)
    statement = select(SavedScan).where(SavedScan.user_id == principal.user.id)
    if cursor:
        created_at, scan_id = _decode_scan_cursor(cursor)
        statement = statement.where(
            or_(
                SavedScan.created_at < created_at,
                and_(SavedScan.created_at == created_at, SavedScan.id < scan_id),
            )
        )
    rows = list(session.scalars(statement.order_by(SavedScan.created_at.desc(), SavedScan.id.desc()).limit(limit + 1)))
    has_more = len(rows) > limit
    items = rows[:limit]
    return SavedScanPage(items=items, next_cursor=_encode_scan_cursor(items[-1]) if has_more and items else None)


@api_router.get("/scans/{scan_id}", response_model=SavedScanResponse, tags=["scans"])
def get_saved_scan(
    scan_id: UUID,
    principal: Annotated[auth.AuthenticatedSession, Depends(auth.get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
) -> SavedScan:
    item = session.scalar(select(SavedScan).where(SavedScan.id == scan_id, SavedScan.user_id == principal.user.id))
    if item is None:
        raise HTTPException(status_code=404, detail="Saved scan was not found")
    return item


@api_router.delete("/scans/{scan_id}", status_code=204, tags=["scans"])
def delete_saved_scan(
    scan_id: UUID,
    principal: Annotated[auth.AuthenticatedSession, Depends(auth.get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
) -> Response:
    item = session.scalar(select(SavedScan).where(SavedScan.id == scan_id, SavedScan.user_id == principal.user.id))
    if item is None:
        raise HTTPException(status_code=404, detail="Saved scan was not found")
    session.delete(item)
    session.commit()
    return Response(status_code=204)


class MessageScanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    message: str = Field(min_length=1, max_length=4000)
    language: Language | None = None
    save_history: bool = False

    @field_validator("message")
    @classmethod
    def reject_blank_message(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Message must contain text")
        return value


class UrlScanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    url: str = Field(min_length=1, max_length=2048)
    language: Language | None = None
    save_history: bool = False

    @field_validator("url")
    @classmethod
    def reject_blank_url(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("URL must contain text")
        return value


class QrScanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    decoded_text: str = Field(min_length=1, max_length=2048)
    language: Language | None = None

    @field_validator("decoded_text")
    @classmethod
    def reject_blank_qr_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("QR content must contain text")
        return value


class UpiPaymentDetails(BaseModel):
    payee: str | None
    amount: str | None
    note: str | None


class QrScanResponse(BaseModel):
    qr_type: Literal["url", "upi_payment_request", "text"]
    notice: str
    upi_payment: UpiPaymentDetails | None
    assessment: dict[str, object]


def _safe_upi_field(value: str | None, limit: int) -> str | None:
    if value is None:
        return None
    cleaned = "".join(character for character in value if character.isprintable()).strip()
    return cleaned[:limit] or None


def _is_upi_payment_uri(decoded_text: str) -> bool:
    try:
        parsed = urlsplit(decoded_text)
    except ValueError:
        return False
    return parsed.scheme.lower() == "upi" and parsed.netloc.lower() == "pay" and parsed.path in {"", "/"}


def _first_query_value(query: dict[str, list[str]], name: str) -> str | None:
    values = query.get(name)
    return values[0] if values else None


def _upi_payment_details(decoded_text: str) -> UpiPaymentDetails:
    try:
        query = parse_qs(urlsplit(decoded_text).query, keep_blank_values=True, max_num_fields=32)
    except ValueError:
        query = {}
    payee = _safe_upi_field(_first_query_value(query, "pa"), 100)
    amount = _safe_upi_field(_first_query_value(query, "am"), 16)
    note = _safe_upi_field(_first_query_value(query, "tn"), 120)
    if amount is not None and re.fullmatch(r"(?:0|[1-9]\d{0,8})(?:\.\d{1,2})?", amount) is None:
        amount = None
    return UpiPaymentDetails(payee=payee, amount=amount, note=note)


QR_NOTICES: dict[Language, dict[str, str]] = {
    "en": {
        "upi": "This QR encodes a payment request; it will not receive money. Entering a UPI PIN authorizes a payment. Verify the payee and amount in your payment app. ScamShield never initiates a payment.",
        "other": "QR content is shown as text and is never opened here. Verify the source independently. Review any recipient and amount in your payment app before authorizing a payment.",
    },
    "hi": {
        "upi": "यह QR भुगतान अनुरोध देता है; इससे पैसे प्राप्त नहीं होंगे। UPI PIN डालना भुगतान की अनुमति देता है। भुगतान ऐप में पाने वाले और राशि की पुष्टि करें। ScamShield कोई भुगतान शुरू नहीं करता।",
        "other": "QR की सामग्री यहाँ केवल पाठ के रूप में दिखाई जाती है और खोली नहीं जाती। स्रोत की स्वतंत्र पुष्टि करें। भुगतान की अनुमति देने से पहले ऐप में पाने वाले और राशि को जाँचें।",
    },
    "kn": {
        "upi": "ಈ QR ಪಾವತಿ ವಿನಂತಿಯನ್ನು ಹೊಂದಿದೆ; ಇದರಿಂದ ಹಣ ಸ್ವೀಕರಿಸಲಾಗುವುದಿಲ್ಲ. UPI PIN ನಮೂದಿಸುವುದು ಪಾವತಿಗೆ ಅನುಮತಿ ನೀಡುತ್ತದೆ. ಪಾವತಿ ಆ್ಯಪ್‌ನಲ್ಲಿ ಸ್ವೀಕರಿಸುವವರು ಮತ್ತು ಮೊತ್ತವನ್ನು ಪರಿಶೀಲಿಸಿ. ScamShield ಪಾವತಿಯನ್ನು ಪ್ರಾರಂಭಿಸುವುದಿಲ್ಲ.",
        "other": "QR ವಿಷಯವನ್ನು ಇಲ್ಲಿ ಪಠ್ಯವಾಗಿ ಮಾತ್ರ ತೋರಿಸಲಾಗುತ್ತದೆ; ತೆರೆಯುವುದಿಲ್ಲ. ಮೂಲವನ್ನು ಸ್ವತಂತ್ರವಾಗಿ ಪರಿಶೀಲಿಸಿ. ಪಾವತಿಗೆ ಅನುಮೋದಿಸುವ ಮೊದಲು ಆ್ಯಪ್‌ನಲ್ಲಿ ಸ್ವೀಕರಿಸುವವರು ಮತ್ತು ಮೊತ್ತ ಪರಿಶೀಲಿಸಿ.",
    },
}


@api_router.post("/scans/messages", tags=["scans"])
def scan_message(
    request: MessageScanRequest,
    http_request: Request,
    principal: Annotated[auth.AuthenticatedSession | None, Depends(auth.get_optional_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
) -> dict[str, object]:
    enforce_rate_limit(http_request, "scan", 30)
    owner = _require_history_owner(principal) if request.save_history else principal
    result = assess_message(request.message, request.language)
    if request.save_history and owner is not None:
        _store_scan(session, owner, "message", result)
    return result


@api_router.post("/scans/urls", tags=["scans"])
def scan_url(
    request: UrlScanRequest,
    http_request: Request,
    principal: Annotated[auth.AuthenticatedSession | None, Depends(auth.get_optional_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
) -> dict[str, object]:
    enforce_rate_limit(http_request, "scan", 30)
    owner = _require_history_owner(principal) if request.save_history else principal
    if not inspect_url(request.url)["valid"]:
        raise HTTPException(status_code=422, detail="Enter a valid web address")
    result = assess_url(request.url, request.language)
    if request.save_history and owner is not None:
        _store_scan(session, owner, "url", result)
    return result


@api_router.post("/scans/qr", response_model=QrScanResponse, tags=["scans"])
def scan_qr(request: QrScanRequest, http_request: Request) -> QrScanResponse:
    enforce_rate_limit(http_request, "scan", 30)
    decoded = request.decoded_text.strip()
    language = request.language or "en"
    if _is_upi_payment_uri(decoded):
        qr_type: Literal["url", "upi_payment_request", "text"] = "upi_payment_request"
        assessment = assess_message(decoded, language)
        payment = _upi_payment_details(decoded)
        notice = QR_NOTICES[language]["upi"]
    elif inspect_url(decoded)["valid"]:
        qr_type = "url"
        assessment = assess_url(decoded, language)
        payment = None
        notice = QR_NOTICES[language]["other"]
    else:
        qr_type = "text"
        assessment = assess_message(decoded, language)
        payment = None
        notice = QR_NOTICES[language]["other"]
    return QrScanResponse(qr_type=qr_type, notice=notice, upi_payment=payment, assessment=assessment)

