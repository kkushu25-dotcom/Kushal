from __future__ import annotations

import hashlib
import logging
import re
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal
from urllib.parse import urlencode, urlsplit, urlunsplit
from uuid import UUID, uuid4

import jwt
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Body,
    Depends,
    Header,
    HTTPException,
    Request,
    Response,
)
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.database import get_database_session
from app.core.rate_limit import enforce_rate_limit
from app.core.security import (
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)
from app.models import PasswordResetToken, RefreshToken, User
from app.services.password_reset_mailer import send_password_reset_email
from app.services.rules import Language

router = APIRouter(prefix="/auth", tags=["auth"])
bearer_scheme = HTTPBearer(auto_error=False)
logger = logging.getLogger("scamshield.auth")
ClientType = Literal["web", "mobile"]
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


class RegisterRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=12, max_length=128)
    language: Language = "en"
    client_type: ClientType = "mobile"
    remember_me: bool = False

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not EMAIL_PATTERN.fullmatch(normalized):
            raise ValueError("Enter a valid email address")
        return normalized


class LoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=128)
    client_type: ClientType = "mobile"
    remember_me: bool = False

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not EMAIL_PATTERN.fullmatch(normalized):
            raise ValueError("Enter a valid email address")
        return normalized


class PasswordResetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: str = Field(min_length=3, max_length=254)
    client_type: ClientType = "web"

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not EMAIL_PATTERN.fullmatch(normalized):
            raise ValueError("Enter a valid email address")
        return normalized


class PasswordResetConfirmRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    token: str = Field(min_length=32, max_length=256)
    new_password: str = Field(min_length=12, max_length=128)


class PasswordResetRequestResponse(BaseModel):
    message: Literal["If an account with that email exists, reset instructions will be sent."] = (
        "If an account with that email exists, reset instructions will be sent."
    )


class RefreshRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    refresh_token: str | None = Field(default=None, min_length=32, max_length=256)
    client_type: ClientType | None = None


class AuthUserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    email: str
    display_name: str | None
    language: Language
    created_at: datetime


class AuthResultResponse(BaseModel):
    access_token: str
    refresh_token: str | None = None
    csrf_token: str | None = None
    token_type: Literal["bearer"] = "bearer"
    expires_in: int
    user: AuthUserResponse


@dataclass(frozen=True)
class AuthenticatedSession:
    user: User
    family_id: UUID
    client_type: ClientType


def _unauthorized() -> HTTPException:
    return HTTPException(status_code=401, detail="Authentication is required")


def _csrf_required(request: Request, csrf_header: str | None) -> None:
    cookie = request.cookies.get("scamshield_csrf", "")
    if not cookie or not csrf_header or not secrets.compare_digest(cookie, csrf_header):
        raise HTTPException(status_code=403, detail="CSRF validation failed")


def _now() -> datetime:
    return datetime.now(UTC)


def _aware(value: datetime) -> datetime:
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value


def _token_digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _reset_link(base_url: str, raw_token: str) -> str:
    parts = urlsplit(base_url)
    query = f"{parts.query}&{urlencode({'token': raw_token})}" if parts.query else urlencode({"token": raw_token})
    return urlunsplit((parts.scheme, parts.netloc, parts.path, query, parts.fragment))


def _deliver_password_reset_email(settings, email: str, reset_url: str) -> None:
    try:
        send_password_reset_email(settings, email, reset_url)
    except Exception as error:
        # The request response is deliberately generic. Do not log recipient, token, URL, or provider text.
        logger.error("password_reset_email_delivery_failed", extra={"error_type": type(error).__name__})


def _make_refresh_record(user_id: UUID, family_id: UUID, raw_token: str, settings, remember_me: bool) -> RefreshToken:
    return RefreshToken(
        user_id=user_id,
        family_id=family_id,
        token_hash=_token_digest(raw_token),
        expires_at=_now() + timedelta(days=settings.refresh_token_days),
        remember_me=remember_me,
    )


def _auth_result(
    user: User,
    family_id: UUID,
    client_type: ClientType,
    raw_refresh_token: str,
    remember_me: bool,
    request: Request,
    response: Response,
) -> AuthResultResponse:
    settings = request.app.state.settings
    secret = request.app.state.jwt_secret
    access_token = create_access_token(
        user.id,
        family_id,
        client_type,
        secret,
        settings.access_token_minutes,
    )
    csrf_token: str | None = None
    refresh_for_body: str | None = raw_refresh_token
    secure = settings.app_env == "production"
    if client_type == "web":
        csrf_token = secrets.token_urlsafe(32)
        refresh_for_body = None
        response.set_cookie(
            "scamshield_refresh",
            raw_refresh_token,
            max_age=settings.refresh_token_days * 24 * 60 * 60 if remember_me else None,
            httponly=True,
            secure=secure,
            samesite="lax",
            path="/api/v1/auth",
        )
        response.set_cookie(
            "scamshield_csrf",
            csrf_token,
            max_age=settings.refresh_token_days * 24 * 60 * 60 if remember_me else None,
            httponly=False,
            secure=secure,
            samesite="lax",
            path="/",
        )
    response.headers["Cache-Control"] = "no-store"
    return AuthResultResponse(
        access_token=access_token,
        refresh_token=refresh_for_body,
        csrf_token=csrf_token,
        expires_in=settings.access_token_minutes * 60,
        user=user,
    )


def get_authenticated_session(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer_scheme)],
    session: Annotated[Session, Depends(get_database_session)],
) -> AuthenticatedSession:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise _unauthorized()
    try:
        payload = decode_access_token(credentials.credentials, request.app.state.jwt_secret)
        user_id = UUID(str(payload["sub"]))
        family_id = UUID(str(payload["fid"]))
        client_type = payload["client_type"]
        if client_type not in {"web", "mobile"}:
            raise ValueError("Unsupported client")
    except (jwt.PyJWTError, KeyError, TypeError, ValueError):
        raise _unauthorized() from None
    user = session.scalar(select(User).where(User.id == user_id, User.deleted_at.is_(None)))
    if user is None:
        raise _unauthorized()
    active_family = session.scalar(
        select(RefreshToken.id)
        .where(
            RefreshToken.user_id == user_id,
            RefreshToken.family_id == family_id,
            RefreshToken.revoked_at.is_(None),
            RefreshToken.expires_at > _now(),
        )
        .limit(1)
    )
    if active_family is None:
        raise _unauthorized()
    return AuthenticatedSession(user=user, family_id=family_id, client_type=client_type)


def get_optional_authenticated_session(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer_scheme)],
    session: Annotated[Session, Depends(get_database_session)],
) -> AuthenticatedSession | None:
    if credentials is None:
        if request.headers.get("authorization"):
            raise _unauthorized()
        return None
    return get_authenticated_session(request, credentials, session)


@router.post("/register", status_code=201, response_model=AuthResultResponse, response_model_exclude_none=True)
def register(
    payload: RegisterRequest,
    request: Request,
    response: Response,
    session: Annotated[Session, Depends(get_database_session)],
) -> AuthResultResponse:
    enforce_rate_limit(request, "register", 5)
    user = User(email=payload.email, password_hash=hash_password(payload.password), language=payload.language)
    try:
        session.add(user)
        session.flush()
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=409, detail="Account already exists") from None
    family_id = uuid4()
    raw_refresh = secrets.token_urlsafe(48)
    session.add(_make_refresh_record(user.id, family_id, raw_refresh, request.app.state.settings, payload.remember_me))
    session.commit()
    session.refresh(user)
    return _auth_result(user, family_id, payload.client_type, raw_refresh, payload.remember_me, request, response)


@router.post("/login", response_model=AuthResultResponse, response_model_exclude_none=True)
def login(
    payload: LoginRequest,
    request: Request,
    response: Response,
    session: Annotated[Session, Depends(get_database_session)],
) -> AuthResultResponse:
    enforce_rate_limit(request, "login", 10)
    user = session.scalar(select(User).where(User.email == payload.email, User.deleted_at.is_(None)))
    if user is None:
        hash_password(payload.password)
        raise _unauthorized()
    if not verify_password(payload.password, user.password_hash):
        raise _unauthorized()
    family_id = uuid4()
    raw_refresh = secrets.token_urlsafe(48)
    session.add(_make_refresh_record(user.id, family_id, raw_refresh, request.app.state.settings, payload.remember_me))
    session.commit()
    return _auth_result(user, family_id, payload.client_type, raw_refresh, payload.remember_me, request, response)


@router.post("/password-reset/request", status_code=202, response_model=PasswordResetRequestResponse)
def request_password_reset(
    payload: PasswordResetRequest,
    request: Request,
    background_tasks: BackgroundTasks,
    session: Annotated[Session, Depends(get_database_session)],
) -> PasswordResetRequestResponse:
    enforce_rate_limit(request, "password_reset_request", 5, window_seconds=3600)
    user = session.scalar(select(User).where(User.email == payload.email, User.deleted_at.is_(None)))
    settings = request.app.state.settings
    if user is not None and settings.password_reset_email_enabled:
        now = _now()
        session.execute(
            update(PasswordResetToken)
            .where(PasswordResetToken.user_id == user.id, PasswordResetToken.used_at.is_(None))
            .values(used_at=now)
        )
        raw_token = secrets.token_urlsafe(32)
        session.add(
            PasswordResetToken(
                user_id=user.id,
                token_hash=_token_digest(raw_token),
                created_at=now,
                expires_at=now + timedelta(minutes=settings.password_reset_minutes),
            )
        )
        session.commit()
        background_tasks.add_task(
            _deliver_password_reset_email,
            settings,
            user.email,
            _reset_link(
                settings.password_reset_mobile_url if payload.client_type == "mobile" else settings.password_reset_url,
                raw_token,
            ),
        )
    return PasswordResetRequestResponse()


@router.post("/password-reset/confirm", status_code=204)
def confirm_password_reset(
    payload: PasswordResetConfirmRequest,
    request: Request,
    session: Annotated[Session, Depends(get_database_session)],
) -> Response:
    enforce_rate_limit(request, "password_reset_confirm", 10, window_seconds=3600)
    token_record = session.scalar(
        select(PasswordResetToken)
        .where(PasswordResetToken.token_hash == _token_digest(payload.token))
        .with_for_update()
    )
    now = _now()
    if token_record is None or token_record.used_at is not None or _aware(token_record.expires_at) <= now:
        raise HTTPException(status_code=400, detail="Reset link is invalid or expired")
    user = session.scalar(select(User).where(User.id == token_record.user_id, User.deleted_at.is_(None)))
    if user is None:
        raise HTTPException(status_code=400, detail="Reset link is invalid or expired")

    user.password_hash = hash_password(payload.new_password)
    token_record.used_at = now
    session.execute(
        update(PasswordResetToken)
        .where(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.id != token_record.id,
            PasswordResetToken.used_at.is_(None),
        )
        .values(used_at=now)
    )
    session.execute(
        update(RefreshToken)
        .where(RefreshToken.user_id == user.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=now)
    )
    session.commit()
    return Response(status_code=204)


@router.post("/refresh", response_model=AuthResultResponse, response_model_exclude_none=True)
def refresh(
    request: Request,
    response: Response,
    session: Annotated[Session, Depends(get_database_session)],
    payload: Annotated[RefreshRequest | None, Body()] = None,
    csrf_header: Annotated[str | None, Header(alias="X-CSRF-Token")] = None,
) -> AuthResultResponse:
    enforce_rate_limit(request, "refresh", 30)
    body = payload or RefreshRequest()
    cookie_token = request.cookies.get("scamshield_refresh")
    client_type = body.client_type or ("web" if cookie_token else "mobile")
    if client_type == "web":
        _csrf_required(request, csrf_header)
        raw_token = cookie_token
    else:
        raw_token = body.refresh_token
    if not raw_token:
        raise _unauthorized()

    token_record = session.scalar(
        select(RefreshToken)
        .where(RefreshToken.token_hash == _token_digest(raw_token))
        .with_for_update()
    )
    if token_record is None:
        raise _unauthorized()
    now = _now()
    if token_record.revoked_at is not None:
        session.execute(
            update(RefreshToken)
            .where(RefreshToken.family_id == token_record.family_id, RefreshToken.revoked_at.is_(None))
            .values(revoked_at=now)
        )
        session.commit()
        raise _unauthorized()
    if _aware(token_record.expires_at) <= now:
        token_record.revoked_at = now
        session.commit()
        raise _unauthorized()
    user = session.scalar(select(User).where(User.id == token_record.user_id, User.deleted_at.is_(None)))
    if user is None:
        raise _unauthorized()

    next_raw_token = secrets.token_urlsafe(48)
    next_record = _make_refresh_record(
        user.id,
        token_record.family_id,
        next_raw_token,
        request.app.state.settings,
        token_record.remember_me,
    )
    session.add(next_record)
    session.flush()
    token_record.revoked_at = now
    token_record.replaced_by_id = next_record.id
    session.commit()
    return _auth_result(user, token_record.family_id, client_type, next_raw_token, token_record.remember_me, request, response)


@router.post("/logout", status_code=204)
def logout(
    request: Request,
    response: Response,
    principal: Annotated[AuthenticatedSession, Depends(get_authenticated_session)],
    session: Annotated[Session, Depends(get_database_session)],
    csrf_header: Annotated[str | None, Header(alias="X-CSRF-Token")] = None,
) -> Response:
    if principal.client_type == "web":
        _csrf_required(request, csrf_header)
    now = _now()
    session.execute(
        update(RefreshToken)
        .where(RefreshToken.family_id == principal.family_id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=now)
    )
    session.commit()
    response.delete_cookie("scamshield_refresh", path="/api/v1/auth", secure=request.app.state.settings.app_env == "production", httponly=True, samesite="lax")
    response.delete_cookie("scamshield_csrf", path="/", secure=request.app.state.settings.app_env == "production", samesite="lax")
    response.status_code = 204
    return response
