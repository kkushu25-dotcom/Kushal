"""Safety checks used by the API."""
