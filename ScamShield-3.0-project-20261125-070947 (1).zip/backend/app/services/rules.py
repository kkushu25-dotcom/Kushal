from __future__ import annotations

import ipaddress
import json
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

from app.services.detection.entities import URL_PATTERN, extract_entities
from app.services.detection.language import Language, detect_language
from app.services.detection.normalization import normalize_message


@dataclass(frozen=True)
class Rule:
    key: str
    category: str
    pattern: re.Pattern[str]
    priority: int


_RULE_FILE = Path(__file__).parent / "detection" / "rules.json"
_FLAG_NAMES = {"IGNORECASE": re.IGNORECASE, "MULTILINE": re.MULTILINE, "DOTALL": re.DOTALL}
RULES = tuple(
    Rule(
        item["key"],
        item["category"],
        re.compile(item["pattern"], sum((_FLAG_NAMES[name] for name in item.get("flags", [])), re.NOFLAG)),
        item["priority"],
    )
    for item in json.loads(_RULE_FILE.read_text(encoding="utf-8"))
)

_URL_SIGNAL_FILE = Path(__file__).parent / "detection" / "url_signals.json"
_URL_SIGNALS = json.loads(_URL_SIGNAL_FILE.read_text(encoding="utf-8"))
SHORTENERS = set(_URL_SIGNALS["shorteners"])
RISKY_TLDS = set(_URL_SIGNALS["risky_tlds"])
BRAND_DOMAINS = {brand: tuple(domains) for brand, domains in _URL_SIGNALS["brand_domains"].items()}
TRUST_NEGATION = re.compile(
    r"\b(?:never|don't|do not|cannot|can't)\s+(?:share|send|give|reveal)(?:\s+(?:your|any|an?|it|this))?\b"
    r"|\bwill never ask for\b|साझा न करें|किसी को न बताएं|हಂಚಬೇಡಿ|ಹಂಚಬೇಡಿ",
    re.I,
)
LABELS: dict[Language, dict[str, tuple[str, str]]] = {
    "en": {
        "credentials": ("Sensitive information", "This text mentions an OTP, credential, or banking detail."),
        "urgency": ("Urgent pressure", "Urgent language can pressure people into acting before checking."),
        "payment_bait": ("Payment or reward claim", "Unexpected prizes, refunds, or fees are a common lure."),
        "impersonation": ("Authority or bank claim", "The sender may be claiming an official or bank role."),
        "remote_access": ("Remote access request", "Remote access can expose your device and accounts."),
        "kyc_update": ("KYC or identity update", "A message asking to update identity details can lead to credential theft."),
        "upi_collect": ("UPI payment request", "A UPI collect request asks you to authorize a payment; it does not receive money for you."),
        "fake_job": ("Unusual job or task offer", "Upfront fees and task deposits are warning signs in job offers."),
        "investment": ("Guaranteed investment claim", "Promises of guaranteed or unusually high returns deserve independent checks."),
        "delivery_fee": ("Unexpected delivery charge", "Unsolicited delivery fees can be used to draw people to a phishing link."),
        "support_number": ("Unverified support number", "Use contact details from an official app or website you type yourself."),
        "short_link": ("Shortened link", "The destination is hidden behind a link shortener."),
        "odd_host": ("Unusual web address", "The address uses a raw IP address or an unusual hostname."),
    },
    "hi": {
        "credentials": ("गोपनीय जानकारी", "इस संदेश में ओटीपी, पासवर्ड या बैंकिंग जानकारी का उल्लेख है।"),
        "urgency": ("जल्दबाज़ी का दबाव", "तुरंत कार्रवाई का दबाव जांचने का समय कम कर सकता है।"),
        "payment_bait": ("भुगतान या इनाम का दावा", "अचानक इनाम, रिफंड या शुल्क आम लालच हैं।"),
        "impersonation": ("बैंक या अधिकारी का दावा", "भेजने वाला बैंक या अधिकारी होने का दावा कर सकता है।"),
        "remote_access": ("रिमोट एक्सेस का अनुरोध", "रिमोट एक्सेस से आपका डिवाइस और खाते जोखिम में पड़ सकते हैं।"),
        "kyc_update": ("केवाईसी या पहचान अपडेट", "पहचान विवरण अपडेट करने का संदेश जानकारी चुराने का तरीका हो सकता है।"),
        "upi_collect": ("यूपीआई भुगतान अनुरोध", "यूपीआई कलेक्ट अनुरोध भुगतान की अनुमति मांगता है; इससे आपको पैसा नहीं मिलता।"),
        "fake_job": ("असामान्य नौकरी या टास्क प्रस्ताव", "नौकरी के लिए अग्रिम शुल्क या जमा राशि चेतावनी संकेत हैं।"),
        "investment": ("गारंटीड निवेश का दावा", "गारंटीड या बहुत अधिक रिटर्न के दावों की स्वतंत्र जांच करें।"),
        "delivery_fee": ("अनपेक्षित डिलीवरी शुल्क", "अनचाहा डिलीवरी शुल्क फ़िशिंग लिंक तक ले जा सकता है।"),
        "support_number": ("असत्यापित सहायता नंबर", "संपर्क विवरण आधिकारिक ऐप या वेबसाइट से लें।"),
        "short_link": ("छोटा किया गया लिंक", "लिंक का असली पता छिपा हुआ है।"),
        "odd_host": ("असामान्य वेब पता", "इस पते में सीधे IP या असामान्य होस्टनाम है।"),
    },
    "kn": {
        "credentials": ("ಗೌಪ್ಯ ಮಾಹಿತಿ", "ಈ ಪಠ್ಯದಲ್ಲಿ OTP, ಗುಪ್ತಪದ ಅಥವಾ ಬ್ಯಾಂಕ್ ವಿವರಗಳ ಉಲ್ಲೇಖವಿದೆ."),
        "urgency": ("ತುರ್ತು ಒತ್ತಡ", "ತಕ್ಷಣ ಕ್ರಮಕ್ಕೆ ಒತ್ತಾಯಿಸುವುದು ಪರಿಶೀಲನೆಗೆ ಸಮಯ ಕಡಿಮೆ ಮಾಡಬಹುದು."),
        "payment_bait": ("ಪಾವತಿ ಅಥವಾ ಬಹುಮಾನದ ಹೇಳಿಕೆ", "ಅನಿರೀಕ್ಷಿತ ಬಹುಮಾನ, ಮರುಪಾವತಿ ಅಥವಾ ಶುಲ್ಕ ಸಾಮಾನ್ಯ ಆಮಿಷಗಳಾಗಿವೆ."),
        "impersonation": ("ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಧಿಕಾರಿಯ ಹೇಳಿಕೆ", "ಕಳುಹಿಸಿದವರು ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಧಿಕಾರಿ ಎಂದು ಹೇಳಿಕೊಳ್ಳಬಹುದು."),
        "remote_access": ("ದೂರಸ್ಥ ಪ್ರವೇಶದ ವಿನಂತಿ", "ದೂರಸ್ಥ ಪ್ರವೇಶವು ನಿಮ್ಮ ಸಾಧನ ಮತ್ತು ಖಾತೆಗಳನ್ನು ಅಪಾಯಕ್ಕೆ ಒಳಪಡಿಸಬಹುದು."),
        "kyc_update": ("ಕೆವೈಸಿ ಅಥವಾ ಗುರುತು ನವೀಕರಣ", "ಗುರುತು ವಿವರಗಳನ್ನು ನವೀಕರಿಸುವ ಸಂದೇಶವು ಮಾಹಿತಿಯನ್ನು ಕದಿಯುವ ಪ್ರಯತ್ನವಾಗಿರಬಹುದು."),
        "upi_collect": ("ಯುಪಿಐ ಪಾವತಿ ವಿನಂತಿ", "ಯುಪಿಐ ಕಲೆಕ್ಟ್ ವಿನಂತಿ ಪಾವತಿಗೆ ಅನುಮತಿ ಕೇಳುತ್ತದೆ; ಅದು ನಿಮಗೆ ಹಣ ಸ್ವೀಕರಿಸುವುದಲ್ಲ."),
        "fake_job": ("ಅಸಾಮಾನ್ಯ ಉದ್ಯೋಗ ಅಥವಾ ಕೆಲಸದ ಆಫರ್", "ಉದ್ಯೋಗಕ್ಕಾಗಿ ಮುಂಗಡ ಶುಲ್ಕ ಅಥವಾ ಠೇವಣಿ ಎಚ್ಚರಿಕೆಯ ಸೂಚನೆಗಳಾಗಿವೆ."),
        "investment": ("ಖಚಿತ ಹೂಡಿಕೆ ಲಾಭದ ಹೇಳಿಕೆ", "ಖಚಿತ ಅಥವಾ ಅತಿಯಾದ ಲಾಭದ ಹೇಳಿಕೆಗಳನ್ನು ಸ್ವತಂತ್ರವಾಗಿ ಪರಿಶೀಲಿಸಿ."),
        "delivery_fee": ("ಅನಿರೀಕ್ಷಿತ ವಿತರಣಾ ಶುಲ್ಕ", "ಅನಿರೀಕ್ಷಿತ ವಿತರಣಾ ಶುಲ್ಕ ಫಿಶಿಂಗ್ ಲಿಂಕ್‌ಗೆ ಕರೆದೊಯ್ಯಬಹುದು."),
        "support_number": ("ಪರಿಶೀಲಿಸದ ಸಹಾಯವಾಣಿ ಸಂಖ್ಯೆ", "ಅಧಿಕೃತ ಆ್ಯಪ್ ಅಥವಾ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿರುವ ಸಂಪರ್ಕ ವಿವರಗಳನ್ನು ಬಳಸಿ."),
        "short_link": ("ಸಂಕ್ಷಿಪ್ತ ಲಿಂಕ್", "ಲಿಂಕ್‌ನ ನಿಜವಾದ ಗಮ್ಯಸ್ಥಾನ ಮರೆಮಾಡಲಾಗಿದೆ."),
        "odd_host": ("ಅಸಾಮಾನ್ಯ ವೆಬ್ ವಿಳಾಸ", "ಈ ವಿಳಾಸದಲ್ಲಿ ನೇರ IP ಅಥವಾ ಅಸಾಮಾನ್ಯ ಹೋಸ್ಟ್ ಹೆಸರು ಇದೆ."),
    },
}

MESSAGES: dict[Language, dict[str, str]] = {
    "en": {
        "uncertain": "Some warning signs matched. This automated check can be wrong; verify through a contact method you already trust.",
        "strong": "Several strong warning signs matched. Do not share codes or money; verify independently.",
        "clear": "No configured warning signs matched. This check cannot prove the content is safe.",
        "action": "Do not share OTPs, PINs, passwords, or payment details. Contact the organization using its official app or a number you already trust.",
        "action_report": "If money may have been lost in India, contact your bank and call 1930 or report at cybercrime.gov.in.",
    },
    "hi": {
        "uncertain": "कुछ चेतावनी संकेत मिले। यह स्वचालित जांच गलत हो सकती है; पहले से विश्वसनीय संपर्क माध्यम से पुष्टि करें।",
        "strong": "कई गंभीर चेतावनी संकेत मिले। कोड या पैसे साझा न करें; स्वतंत्र रूप से पुष्टि करें।",
        "clear": "निर्धारित चेतावनी संकेत नहीं मिले। इससे सामग्री सुरक्षित साबित नहीं होती।",
        "action": "OTP, PIN, पासवर्ड या भुगतान विवरण साझा न करें। आधिकारिक ऐप या पहले से ज्ञात नंबर से संस्था से संपर्क करें।",
        "action_report": "भारत में पैसे का नुकसान हुआ हो सकता है, तो बैंक से संपर्क करें और 1930 पर कॉल करें या cybercrime.gov.in पर रिपोर्ट करें।",
    },
    "kn": {
        "uncertain": "ಕೆಲವು ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ. ಈ ಸ್ವಯಂಚಾಲಿತ ಪರಿಶೀಲನೆ ತಪ್ಪಾಗಿರಬಹುದು; ನಿಮಗೆ ಈಗಾಗಲೇ ತಿಳಿದಿರುವ ವಿಶ್ವಾಸಾರ್ಹ ಮಾರ್ಗದಲ್ಲಿ ಪರಿಶೀಲಿಸಿ.",
        "strong": "ಹಲವು ಗಂಭೀರ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಕಂಡುಬಂದಿವೆ. ಕೋಡ್ ಅಥವಾ ಹಣವನ್ನು ಹಂಚಬೇಡಿ; ಸ್ವತಂತ್ರವಾಗಿ ಪರಿಶೀಲಿಸಿ.",
        "clear": "ಸಂರಚಿತ ಎಚ್ಚರಿಕೆ ಸೂಚನೆಗಳು ಹೊಂದಿಕೆಯಾಗಲಿಲ್ಲ. ಇದರಿಂದ ವಿಷಯ ಸುರಕ್ಷಿತವೆಂದು ಸಾಬೀತಾಗುವುದಿಲ್ಲ.",
        "action": "OTP, PIN, ಗುಪ್ತಪದ ಅಥವಾ ಪಾವತಿ ವಿವರಗಳನ್ನು ಹಂಚಬೇಡಿ. ಅಧಿಕೃತ ಆ್ಯಪ್ ಅಥವಾ ನಿಮಗೆ ಈಗಾಗಲೇ ತಿಳಿದಿರುವ ಸಂಖ್ಯೆಯ ಮೂಲಕ ಸಂಸ್ಥೆಯನ್ನು ಸಂಪರ್ಕಿಸಿ.",
        "action_report": "ಭಾರತದಲ್ಲಿ ಹಣ ಕಳೆದುಹೋಗಿರಬಹುದು ಎಂದಾದರೆ ಬ್ಯಾಂಕ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ, 1930ಕ್ಕೆ ಕರೆಮಾಡಿ ಅಥವಾ cybercrime.gov.in ನಲ್ಲಿ ವರದಿ ಮಾಡಿ.",
    },
}


def _indicators(text: str, language: Language) -> list[dict[str, object]]:
    found: list[dict[str, object]] = []
    occupied: list[tuple[int, int]] = []
    for rule in RULES:
        match = rule.pattern.search(text)
        if match is None:
            continue
        context = text[max(0, match.start() - 70) : min(len(text), match.end() + 70)]
        if rule.key == "credentials" and TRUST_NEGATION.search(context):
            continue
        label, why = LABELS[language][rule.key]
        found.append({"id": rule.key, "label": label, "why": why, "start": match.start(), "end": match.end()})
        occupied.append(match.span())

    for match in URL_PATTERN.finditer(text):
        raw_url = match.group(0).rstrip(".,!?;:)")
        detail = inspect_url(raw_url)
        indicator_key = "short_link" if detail["short_link"] else "odd_host" if detail["odd_host"] else None
        if indicator_key is None:
            continue
        start = match.start()
        end = start + len(raw_url)
        if any(start < prior_end and end > prior_start for prior_start, prior_end in occupied):
            continue
        label, why = LABELS[language][indicator_key]
        found.append({"id": indicator_key, "label": label, "why": why, "start": start, "end": end})
        occupied.append((start, end))

    return sorted(found, key=lambda item: int(item["start"]))


def inspect_url(raw_url: str) -> dict[str, object]:
    candidate = raw_url.strip()
    explicit_https = candidate.lower().startswith("https://")
    if candidate.lower().startswith("www."):
        candidate = f"http://{candidate}"
    elif "://" not in candidate:
        candidate = f"https://{candidate}"
    try:
        parsed = urlsplit(candidate)
        host = (parsed.hostname or "").rstrip(".").lower()
        port = parsed.port
    except ValueError:
        return {"host": None, "https": explicit_https, "short_link": False, "odd_host": True, "valid": False}

    try:
        ipaddress.ip_address(host)
        raw_ip = True
    except ValueError:
        raw_ip = False
    valid = (
        parsed.scheme.lower() in {"http", "https"}
        and bool(host)
        and ("." in host or host == "localhost" or raw_ip)
        and (port is None or 1 <= port <= 65535)
        and not any(character.isspace() for character in candidate)
    )
    if not valid:
        return {"host": host or None, "https": explicit_https, "short_link": False, "odd_host": True, "valid": False}

    short_link = host in SHORTENERS
    subdomain_count = max(0, len(host.split(".")) - 2)
    tld = host.rsplit(".", maxsplit=1)[-1]
    risky_tld = tld in RISKY_TLDS
    has_userinfo = parsed.username is not None or parsed.password is not None
    unusual_port = port is not None and port not in {80, 443}
    lookalike_brand = any(
        brand in host.replace("-", "").replace("_", "")
        and not any(host == domain or host.endswith(f".{domain}") for domain in domains)
        for brand, domains in BRAND_DOMAINS.items()
    )
    try:
        ascii_host = host.encode("idna").decode("ascii")
    except UnicodeError:
        ascii_host = ""
    punycode = not ascii_host or ascii_host.startswith("xn--") or ".xn--" in ascii_host
    odd_host = (
        raw_ip
        or host == "localhost"
        or host.endswith(".local")
        or punycode
        or risky_tld
        or subdomain_count > 4
        or has_userinfo
        or unusual_port
        or lookalike_brand
    )
    return {
        "host": host,
        "https": explicit_https,
        "short_link": short_link,
        "odd_host": odd_host,
        "raw_ip": raw_ip,
        "punycode": punycode,
        "risky_tld": risky_tld,
        "excessive_subdomains": subdomain_count > 4,
        "has_userinfo": has_userinfo,
        "unusual_port": unusual_port,
        "lookalike_brand": lookalike_brand,
        "valid": True,
    }


def assess_message(text: str, language: Language | None = None) -> dict[str, object]:
    normalized = normalize_message(text)
    detected_language = language or detect_language(text)
    indicators = _indicators(normalized.value, detected_language)
    for indicator in indicators:
        indicator["start"], indicator["end"] = normalized.source_span(
            int(indicator["start"]), int(indicator["end"])
        )
    entities = extract_entities(normalized)
    for entity in entities:
        entity["value"] = text[int(entity["start"]) : int(entity["end"])]
    keys = {str(indicator["id"]) for indicator in indicators}
    matched_rules = (rule for rule in RULES if rule.key in keys)
    highest_priority = max(matched_rules, key=lambda rule: rule.priority, default=None)
    category = highest_priority.category if highest_priority else None
    if category is None and keys.intersection({"short_link", "odd_host"}):
        category = "phishing_link"
    if category is None and "credentials" in keys:
        category = "credential_request"
    if category is None and "urgency" in keys:
        category = "social_engineering"
    strong_pairs = (
        {"credentials", "urgency"},
        {"credentials", "payment_bait"},
        {"credentials", "impersonation"},
        {"remote_access", "urgency"},
        {"upi_collect", "credentials"},
    )
    strong = any(pair.issubset(keys) for pair in strong_pairs) or len(keys) >= 3
    verdict = "SCAM" if strong else "SUSPICIOUS" if indicators else "SAFE"
    risk = {"SCAM": "high", "SUSPICIOUS": "medium", "SAFE": "low"}[verdict]
    messages = MESSAGES[detected_language]
    uncertainty = messages["strong"] if strong else messages["uncertain"] if indicators else messages["clear"]
    actions = [] if not indicators else [messages["action"]]
    if strong and keys.intersection({"credentials", "payment_bait", "impersonation", "upi_collect"}):
        actions.append(messages["action_report"])
    return {
        "verdict": verdict,
        "risk_level": risk,
        "category": category,
        "confidence": min(0.84, 0.55 + 0.09 * max(0, len(keys) - 1)) if keys else 0.0,
        "uncertainty": uncertainty,
        "indicators": indicators,
        "entities": entities,
        "recommended_actions": actions,
        "language": detected_language,
        "lesson_id": None,
        "engine": "rules",
        "llm_status": "not_configured",
    }


def assess_url(text: str, language: Language | None = None) -> dict[str, object]:
    details = inspect_url(text)
    result = assess_message(text, language)
    if details["short_link"] or details["odd_host"]:
        key = "short_link" if details["short_link"] else "odd_host"
        selected_language = result["language"]
        label, why = LABELS[selected_language][key]
        result["indicators"] = [{"id": key, "label": label, "why": why, "start": 0, "end": len(text)}]
        result["verdict"] = "SUSPICIOUS"
        result["risk_level"] = "medium"
        result["category"] = "phishing_link"
        result["confidence"] = 0.61
        result["uncertainty"] = MESSAGES[selected_language]["uncertain"]
        result["recommended_actions"] = [MESSAGES[selected_language]["action"]]
    result["reputation"] = "not_checked"
    result["https"] = bool(details["https"])
    result["host"] = details["host"]
    result["url_signals"] = {key: value for key, value in details.items() if key not in {"host", "https", "valid"}}
    return result
