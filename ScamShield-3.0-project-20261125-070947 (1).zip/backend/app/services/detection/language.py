from __future__ import annotations

from typing import Literal

Language = Literal["en", "hi", "kn"]


def detect_language(text: str) -> Language:
    """Choose a supported language by script; Latin-script input defaults to English."""

    devanagari = 0
    kannada = 0
    for character in text:
        codepoint = ord(character)
        if 0x0900 <= codepoint <= 0x097F:
            devanagari += 1
        elif 0x0C80 <= codepoint <= 0x0CFF:
            kannada += 1
    if kannada > devanagari:
        return "kn"
    if devanagari:
        return "hi"
    return "en"
