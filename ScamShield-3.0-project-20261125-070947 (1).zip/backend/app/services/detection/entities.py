from __future__ import annotations

import re

from app.services.detection.normalization import NormalizedText

URL_PATTERN = re.compile(r"https?://[^\s<>\"']+|www\.[^\s<>\"']+", re.I)
PHONE_PATTERN = re.compile(r"(?<![A-Za-z0-9])(?:\+?91[\s.-]?)?[6-9](?:[\s.-]?\d){9}(?!\d)")
UPI_PATTERN = re.compile(
    r"(?i)\b[a-z0-9][a-z0-9._-]{0,80}@(ybl|ibl|upi|paytm|okaxis|okhdfcbank|okicici|oksbi|axl|apl)\b"
)


def extract_entities(normalized: NormalizedText) -> list[dict[str, object]]:
    entities: list[dict[str, object]] = []
    for kind, pattern in (("url", URL_PATTERN), ("phone", PHONE_PATTERN), ("upi_id", UPI_PATTERN)):
        for match in pattern.finditer(normalized.value):
            start, end = normalized.source_span(match.start(), match.end())
            entities.append({"type": kind, "value": normalized.value[match.start() : match.end()], "start": start, "end": end})
    return sorted(entities, key=lambda entity: int(entity["start"]))
