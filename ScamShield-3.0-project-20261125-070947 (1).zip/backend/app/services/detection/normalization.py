from __future__ import annotations

import unicodedata
from dataclasses import dataclass

_REMOVED_FORMATTING = {"\u00ad", "\u200b", "\u200c", "\u200d", "\u2060", "\ufeff"}


@dataclass(frozen=True)
class NormalizedText:
    """NFKC text plus an index map back to the submitted string."""

    value: str
    source_start: tuple[int, ...]
    source_end: tuple[int, ...]

    def source_span(self, start: int, end: int) -> tuple[int, int]:
        start = max(0, min(start, len(self.source_start)))
        end = max(start, min(end, len(self.source_end)))
        if start == end:
            return (0, 0) if not self.source_start else (self.source_start[start - 1], self.source_end[start - 1])
        return self.source_start[start], self.source_end[end - 1]


def normalize_message(source: str) -> NormalizedText:
    """Normalize compatibility characters and invisible separators without losing offsets."""

    output: list[str] = []
    starts: list[int] = []
    ends: list[int] = []
    for index, original in enumerate(source):
        if original in _REMOVED_FORMATTING:
            continue
        normalized = unicodedata.normalize("NFKC", original)
        for character in normalized:
            if character in _REMOVED_FORMATTING:
                continue
            if unicodedata.category(character) in {"Zs", "Zl", "Zp"}:
                character = " "
            output.append(character)
            starts.append(index)
            ends.append(index + 1)
    return NormalizedText("".join(output), tuple(starts), tuple(ends))
