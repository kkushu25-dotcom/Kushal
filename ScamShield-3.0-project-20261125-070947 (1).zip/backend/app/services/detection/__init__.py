"""Shared detection primitives for the rule-based scanner."""
