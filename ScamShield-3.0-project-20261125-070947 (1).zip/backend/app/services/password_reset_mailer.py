from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

from app.core.config import Settings


def send_password_reset_email(settings: Settings, recipient: str, reset_url: str) -> None:
    """Send a plain-text, short-lived password reset link through configured SMTP."""
    if not settings.password_reset_email_enabled or not settings.smtp_host or not settings.smtp_from_email:
        return
    if not (settings.smtp_use_ssl or settings.smtp_starttls):
        raise ValueError("SMTP must use SSL or STARTTLS")

    message = EmailMessage()
    message["Subject"] = "Reset your ScamShield password"
    message["From"] = settings.smtp_from_email
    message["To"] = recipient
    message.set_content(
        "A password reset was requested for your ScamShield account.\n\n"
        f"Choose a new password using this one-time link (expires in {settings.password_reset_minutes} minutes):\n"
        f"{reset_url}\n\n"
        "If you did not request this, you can ignore this email. Your current password will remain unchanged."
    )

    context = ssl.create_default_context()
    if settings.smtp_use_ssl:
        server = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=10, context=context)
    else:
        server = smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10)
    with server:
        if settings.smtp_starttls and not settings.smtp_use_ssl:
            server.ehlo()
            server.starttls(context=context)
            server.ehlo()
        username = settings.smtp_username
        password = settings.smtp_password.get_secret_value() if settings.smtp_password else None
        if username:
            server.login(username, password or "")
        elif password:
            raise ValueError("SMTP_PASSWORD requires SMTP_USERNAME")
        server.send_message(message)
