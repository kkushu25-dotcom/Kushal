"""ScamShield backend application."""

