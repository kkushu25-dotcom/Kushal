import logging
import secrets
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from redis import Redis
from sqlalchemy import text

from app.api.v1.router import api_router
from app.core.config import Settings, get_settings
from app.core.database import create_database_engine, create_session_factory
from app.core.rate_limit import RateLimiter

logger = logging.getLogger("scamshield.api")


def _error(code: str, message: str, request_id: str) -> dict[str, object]:
    return {"error": {"code": code, "message": message, "request_id": request_id}}


def create_app(settings: Settings | None = None, database_engine=None) -> FastAPI:
    current_settings = settings or get_settings()
    if current_settings.app_env == "production":
        configured_secret = current_settings.jwt_secret.get_secret_value() if current_settings.jwt_secret else ""
        if len(configured_secret) < 32:
            raise RuntimeError("JWT_SECRET must contain at least 32 characters in production")
        signing_secret = configured_secret
        if not current_settings.redis_url:
            raise RuntimeError("REDIS_URL must be configured in production for shared rate limits")
    else:
        signing_secret = current_settings.jwt_secret.get_secret_value() if current_settings.jwt_secret else secrets.token_urlsafe(48)

    app = FastAPI(
        title="ScamShield API",
        version="1.0.0",
        docs_url=None if current_settings.app_env == "production" else "/docs",
        redoc_url=None if current_settings.app_env == "production" else "/redoc",
        openapi_url=None if current_settings.app_env == "production" else "/openapi.json",
    )
    engine = database_engine or create_database_engine(current_settings.database_url)
    app.state.settings = current_settings
    app.state.engine = engine
    app.state.session_factory = create_session_factory(engine)
    app.state.jwt_secret = signing_secret
    redis_client = Redis.from_url(current_settings.redis_url, socket_connect_timeout=1, socket_timeout=1) if current_settings.redis_url else None
    app.state.redis_client = redis_client
    app.state.rate_limiter = RateLimiter(redis_client)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=current_settings.allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-CSRF-Token", "X-Request-ID"],
        expose_headers=["X-Request-ID", "Retry-After"],
    )

    @app.middleware("http")
    async def secure_response_headers(request: Request, call_next):
        request_id = request.headers.get("x-request-id", "")[:80] or uuid4().hex
        request.state.request_id = request_id
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("unhandled_request", extra={"request_id": request_id, "path": request.url.path})
            response = JSONResponse(status_code=500, content=_error("internal_error", "The request could not be completed.", request_id))
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        response.headers["Cache-Control"] = "no-store"
        if current_settings.app_env == "production":
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
            response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        return response

    @app.exception_handler(HTTPException)
    async def http_error(request: Request, exc: HTTPException):
        request_id = getattr(request.state, "request_id", uuid4().hex)
        public_messages = {400: "The request could not be processed.", 401: "Authentication is required.", 403: "The request could not be authorized.", 404: "The requested resource was not found.", 409: "The request conflicts with existing data.", 422: "Check the submitted fields and try again.", 429: "Too many requests. Try again later.", 503: "The service is temporarily unavailable.", 501: "This capability is not available yet."}
        code = {401: "unauthorized", 403: "forbidden", 404: "not_found", 409: "conflict", 422: "validation_error", 429: "rate_limited", 501: "not_implemented", 503: "service_unavailable"}.get(exc.status_code, "request_error")
        message = public_messages.get(exc.status_code, "The request could not be processed.")
        return JSONResponse(status_code=exc.status_code, content=_error(code, message, request_id), headers=exc.headers)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, _exc: RequestValidationError):
        request_id = getattr(request.state, "request_id", uuid4().hex)
        return JSONResponse(status_code=422, content=_error("validation_error", "Check the submitted fields and try again.", request_id))

    @app.get("/health", tags=["health"])
    @app.get("/api/v1/health", tags=["health"], include_in_schema=False)
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/ready", tags=["health"])
    @app.get("/api/v1/ready", tags=["health"], include_in_schema=False)
    async def ready(request: Request) -> dict[str, str]:
        try:
            with request.app.state.engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            if request.app.state.redis_client is not None:
                request.app.state.redis_client.ping()
        except Exception as exc:
            raise HTTPException(status_code=503, detail="Service is not ready") from exc
        return {"status": "ready"}

    app.include_router(api_router, prefix="/api/v1")

    @app.on_event("shutdown")
    def close_engine() -> None:
        app.state.engine.dispose()
        if app.state.redis_client is not None:
            app.state.redis_client.close()

    return app


app = create_app()

