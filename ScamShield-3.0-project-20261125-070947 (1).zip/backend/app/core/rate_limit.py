from __future__ import annotations

import hashlib
import threading
import time

from fastapi import HTTPException, Request
from redis.exceptions import RedisError


class RateLimiter:
    """Fixed-window limiter; Redis is shared across workers, memory is for local development."""

    _SCRIPT = """
    local count = redis.call('INCR', KEYS[1])
    if count == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]) end
    return {count, redis.call('TTL', KEYS[1])}
    """

    def __init__(self, redis_client=None) -> None:
        self._redis = redis_client
        self._lock = threading.Lock()
        self._local: dict[str, tuple[int, int]] = {}

    def consume(self, key: str, limit: int, window_seconds: int = 60) -> int | None:
        if self._redis is not None:
            try:
                count, ttl = self._redis.eval(self._SCRIPT, 1, key, window_seconds)
            except RedisError:
                raise HTTPException(status_code=503, detail="Rate limiting is temporarily unavailable") from None
            return int(ttl) if int(count) > limit else None

        now = time.time()
        window = int(now // window_seconds)
        with self._lock:
            prior_window, prior_count = self._local.get(key, (window, 0))
            count = prior_count + 1 if prior_window == window else 1
            self._local[key] = (window, count)
        if count <= limit:
            return None
        return max(1, int((window + 1) * window_seconds - now))


def enforce_rate_limit(request: Request, bucket: str, limit: int, window_seconds: int = 60) -> None:
    host = request.client.host if request.client is not None else "unknown"
    digest = hashlib.sha256(host.encode("utf-8")).hexdigest()[:24]
    retry_after = request.app.state.rate_limiter.consume(f"scamshield:{bucket}:{digest}", limit, window_seconds)
    if retry_after is not None:
        raise HTTPException(status_code=429, detail="Too many requests", headers={"Retry-After": str(retry_after)})
