from functools import lru_cache
from typing import Literal

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=(".env", "backend/.env"), extra="ignore")

    app_env: Literal["development", "test", "production"] = "development"
    database_url: str = "sqlite+pysqlite:///./scamshield.db"
    redis_url: str | None = None
    jwt_secret: SecretStr | None = None
    web_origins: str = "http://localhost:5173"
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    password_reset_minutes: int = 60
    password_reset_url: str = "http://localhost:5173/auth/forgot-password"
    password_reset_mobile_url: str = "scamshield://auth/reset-password"
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: SecretStr | None = None
    smtp_from_email: str | None = None
    smtp_use_ssl: bool = False
    smtp_starttls: bool = True

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.web_origins.split(",") if origin.strip()]

    @property
    def password_reset_email_enabled(self) -> bool:
        return bool(self.smtp_host and self.smtp_from_email and (self.smtp_use_ssl or self.smtp_starttls))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()

