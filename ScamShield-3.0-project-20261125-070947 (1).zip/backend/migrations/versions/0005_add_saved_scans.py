"""Store opt-in scan assessment metadata without source text or entities."""

import sqlalchemy as sa
from alembic import op

revision = "0005_add_saved_scans"
down_revision = "0004_add_password_reset_tokens"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "saved_scans",
        sa.Column("id", sa.Uuid(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("user_id", sa.Uuid(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("scan_type", sa.String(length=12), nullable=False),
        sa.Column("verdict", sa.String(length=12), nullable=False),
        sa.Column("risk_level", sa.String(length=8), nullable=False),
        sa.Column("category", sa.String(length=80), nullable=True),
        sa.Column("language", sa.String(length=2), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_saved_scans_user_id", "saved_scans", ["user_id"])
    op.create_index("ix_saved_scans_created_at", "saved_scans", ["created_at"])


def downgrade() -> None:
    op.drop_index("ix_saved_scans_created_at", table_name="saved_scans")
    op.drop_index("ix_saved_scans_user_id", table_name="saved_scans")
    op.drop_table("saved_scans")
