"""Persist the web session's remember-me choice across refresh rotation."""

import sqlalchemy as sa
from alembic import op

revision = "0003_add_remember_me"
down_revision = "0002_add_refresh_tokens"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "refresh_tokens",
        sa.Column("remember_me", sa.Boolean(), server_default=sa.false(), nullable=False),
    )


def downgrade() -> None:
    op.drop_column("refresh_tokens", "remember_me")
