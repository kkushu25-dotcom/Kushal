# Database design

PostgreSQL is the production datastore. IDs are UUIDs; timestamps are stored in UTC. Foreign keys use deliberate deletion behavior. Sensitive payloads are excluded by default.

## Current implementation status

The ER diagram and table inventory below describe the target schema. Current Alembic migrations implement users, user_preferences, refresh_tokens, password_reset_tokens, and saved_scans. Saved scans contain only an explicitly opted-in assessment summary; submitted message/URL text and extracted entities are not stored. The remaining tables in the target schema are not implemented yet. Learning lessons and quizzes are bundled in packages/content/learning-content.json; there are no server-side lesson, quiz-attempt, or learning-progress records.

## Entity relationship diagram

```mermaid
erDiagram
  USERS ||--|| USER_PREFERENCES : has
  USERS ||--o{ REFRESH_TOKENS : owns
  USERS ||--o{ PASSWORD_RESET_TOKENS : requests
  USERS ||--o{ SAVED_SCANS : saves
  USERS ||--o{ SCANS : owns
  SCANS ||--o{ SCAN_FINDINGS : explains
  USERS ||--o{ SECURITY_ALERTS : receives
  USERS ||--o{ EMERGENCY_CASES : opens
  EMERGENCY_CASES ||--o{ EVIDENCE_ITEMS : records
  USERS ||--o{ TRUSTED_CONTACTS : manages
  USERS ||--o{ CONSENT_RECORDS : grants
  USERS ||--o{ AUDIT_LOGS : actor
  USERS ||--o{ REGISTERED_DEVICES : registers
  USERS ||--o{ COMMUNITY_REPORTS : submits
  USERS ||--o{ CHECKLIST_PROGRESS : tracks
  LESSONS ||--o{ QUIZ_QUESTIONS : contains
  USERS ||--o{ QUIZ_ATTEMPTS : takes
  LESSONS ||--o{ QUIZ_ATTEMPTS : assesses
```

## Tables

| Table | Purpose and key constraints | Status |
|---|---|
| `users` | UUID, normalized unique email, Argon2id hash, created/updated/deleted timestamps. Deletion cascades owned private data. | Implemented |
| `user_preferences` | One-to-one locale, theme, notification and consent preferences. | Implemented |
| `refresh_tokens` | Hashed token only, family UUID, expiry, rotation/revocation timestamps, reuse detection; user FK cascades. | Implemented |
| `password_reset_tokens` | Hashed single-use reset token, expiry, used/revoked timestamps; user FK cascades. | Implemented |
| `saved_scans` | Owner-scoped opted-in summary: scan type, verdict, risk level, category, language and timestamp; excludes source text and extracted entities. | Implemented |
| `scans` | Owner-scoped assessment record: kind, verdict, risk, category, language, engine, provider status, timestamps. No raw message or URL. Guest results are never persisted. | Planned |
| `scan_findings` | Scan FK, rule ID, translated label key, start/end offsets, severity. Does not store matched source text. | Planned |
| `threat_indicators` | Canonical hashed/normalized indicator and moderation/reputation metadata; access policy separates public verified data. | Planned |
| `lessons` | Localized content key, category, revision and publication state; authored data seeded from `packages/content`. | Planned |
| `quiz_questions` | Lesson FK, locale, prompt/choices, answer index and explanation; answer data is server-side. | Planned |
| `quiz_attempts` | User FK, lesson FK, score, completion timestamp; no guessed safety score. | Planned |
| `security_alerts` | User FK, scan FK optional, severity, educational-demo flag, read state, action key. | Planned |
| `emergency_cases` | User FK, incident category, current step, state, optional bank/cyber acknowledgement numbers; free text is guarded against secrets. | Planned |
| `evidence_items` | Case FK, opaque storage key, content type/size/hash, original filename sanitized, created timestamp; content held outside web root and malware-scanned before availability. | Planned |
| `trusted_contacts` | Owner FK, display name and contact channel stored encrypted where feasible; no message contents. | Planned |
| `consent_records` | Owner FK, subject/contact FK, scope, granted/revoked timestamps, audit metadata. Sharing requires active scope. | Planned |
| `audit_logs` | Actor UUID nullable, action, resource type/id, timestamp, request correlation ID; no bodies, secrets, or evidence. | Planned |
| `registered_devices` | User FK, provider token encrypted, platform, enabled state, updated timestamp. | Planned |
| `community_reports` | User FK nullable for guest reports, normalized indicator, report reason category, moderation state and timestamps; unverified data never appears as confirmed. | Planned |
| `checklist_progress` | User FK, checklist key, completion state and timestamp; uniqueness per user/key. | Planned |

## Deletion and retention

- Implemented user deletion removes refresh tokens, password reset tokens, and saved scan summaries. The planned resource tables listed above must be added to the deletion workflow as those features are implemented.
- When evidence storage is implemented, object deletion must be confirmed before the case row is removed; failures need retry and audit handling that does not retain secrets in logs.
- Audit entries retain only the minimum operational metadata and must follow the retention policy set for the deployment.
- Guest scans are not inserted into these tables.
- Exact retention periods, legal basis, and data residency must be reviewed before production launch.

