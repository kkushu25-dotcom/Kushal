# Screen map

Navigation uses a mobile-style, centered, approximately 860 px maximum-width layout. There is no sidebar. A top bar shows a back button and the active screen title. Five tabs remain visible: Home, Scan, Learn, Alerts, Profile. Category tiles open vertical feature-row lists; rows open feature screens. Dropdowns close on outside click and Escape and support keyboard operation.

| Section/category | Screens |
|---|---|
| Onboarding | Welcome, language selection, consent and privacy choices |
| Home | Dashboard, recent scans, alerts, checklist progress, next steps |
| Scam detection | Message Scanner, URL Scanner, QR Code Scanner, Scan History, Scan Result |
| Digital protection | Security Alerts, Privacy Centre, Cookie & Tracker guidance, Secure My Account |
| Emergency centre | I Lost Money, Account Hacked, Report Cyber Fraud, Emergency History, Emergency Checklist |
| Learning centre | Scam Lessons, Lesson Detail, Interactive Quizzes, Scam Simulator, My Learning Progress |
| Family safety | Trusted Contacts, Family Protection, Consent Management |
| Settings | My Profile, Language, Notifications, Privacy Settings |
| Authentication | Login, Registration, Password Reset, Account Deletion |

## Screen behavior

- **Dashboard:** gradient/glow hero, three quick actions, coral emergency card, six category tiles, recent scans and learning/checklist next steps. Demo/educational content is labelled.
- **Category:** feature rows with icon, title, short description, and chevron.
- **Message/URL scanner:** local input, clear privacy note, size feedback, accessible submit and loading state.
- **Scan result:** distinct verdict treatment, risk/category/confidence, explicit uncertainty, findings with safe offset highlights, next actions and related lesson. Provider outage says “AI analysis unavailable”; it never implies a failed provider result.
- **Emergency flow:** one step per view, separate money-loss/account-hacked paths, checklist progress, official links, call 1930, optional non-sensitive references stored on-device, and a persistent disclaimer. Android guidance and progress work offline.
- **Android account security:** Profile opens a Secure My Account route with a six-step checklist saved on-device, official Google and Meta security links, and a clear guidance-only disclaimer. It never requests credentials or changes account settings.
- **Android alerts and emergency navigation:** the Alerts tab states that push registration and delivery are unavailable and does not fabricate events. Home opens a separate emergency stack route for the offline response checklist.
- **Android category navigation:** Home displays Scam Detection, Digital Protection, Emergency Centre, Learning Centre, Family Safety, and Settings. Each category opens feature rows; feature pages route to implemented flows, provide guidance, or state that the feature is unavailable.
- **Android language choice:** Home and Profile share a SecureStore-backed English/Hindi/Kannada selection. Supported tabs and content use the shared preference; untranslated interface copy remains English and is tracked as incomplete.
- **Android Home:** includes message, URL, and QR quick actions; a separate emergency card; opted-in recent assessment metadata for signed-in users; and progress counts from the two offline emergency checklists.
- **Learning centre:** ten synthetic scam-pattern lessons and quizzes share English, Hindi, and Kannada content. Feedback explains the safer action; lesson completion is learning activity, not a safety score. Web progress is tab-local and Android progress is stored only on the device, not synced to an account. Educational examples never represent a scan result.
- **Android QR scanner:** request camera permission only for scanning, decode QR text on-device, show a denied-permission state, and preview content before the user chooses an assessment. Links are not opened and UPI payments are never started.
- **Android share-to-scan:** shared text and links prefill the message or URL scanner; users review the content and tap Check before anything is sent.
- **Scan history and Home recent scans:** only opted-in assessment summaries are shown; submitted message/URL text and extracted entities are not saved.
- **Privacy/Cookie guidance:** explicitly states the web app does not inspect browser cookies or other sites.
- **Profile/Settings:** web preferences and consent controls; Android includes guest-to-account sign-in/registration, password recovery, confirmed account deletion, and owner-scoped saved scan metadata. Push notifications are not sent in this build.
- **Empty, loading, error, and offline states:** present in every API-connected feature. Private results are not cached by the PWA shell.

## Visual system

Use tokens in `packages/design-tokens/tokens.json`. The design follows the written brief: dark default, black hero with CSS glow blobs, quiet frosted surfaces, coral gradient primary controls, Jost with robust system fallback, 20 px cards, 28 px hero, full-pill buttons, 16 px inputs. Respect light theme, `prefers-color-scheme`, reduced motion, WCAG 2.2 AA, 44 px controls, and visible keyboard focus.

The prototype and Securify reference image were not supplied in the repository; exact visual matching remains unverified.

