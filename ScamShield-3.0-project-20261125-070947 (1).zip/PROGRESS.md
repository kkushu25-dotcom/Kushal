# Progress log

## 2026-11-24 — Discovery

**Objective:** inspect the repository and `/reference/`, then write requirements, architecture, schema, API contract, screen map, and roadmap.

**Completed:** confirmed the local workspace had no files, Git metadata, or `/reference/` assets; read the full pasted build brief; inspected the supplied GitHub repository (its `main` branch contained only the initial README); created the discovery documents and documented missing reference files and technical/deployment risks. Created remote working branch `codex/scamshield-3.0` from `main` for incremental pushes.

**Verification:** repository inspection succeeded. This milestone adds documentation and the API contract; no test suite or linter is configured yet. Confirmed Node 24.22.3 and Git are available; npm, Python, Docker, and YAML validators are unavailable, so application suites and container checks cannot run here. Exact owner commands are recorded in `TESTING.md` and `DEPLOYMENT.md`.

**Limitations:** visual fidelity to the missing prototype/image is unverified. No credentials or deployment target were supplied.

## 2026-11-24 — Foundation and first scan flow

**Completed:** added pinned web/mobile/API workspace manifests, shared design tokens and emergency guidance, responsive web shell and Expo tab shell, API client, FastAPI liveness/readiness endpoints, UUID-compatible initial migration, Dockerfiles/Compose, and GitHub Actions checks. Added a deterministic, explainable message/URL rules assessment in English, Hindi, and Kannada. URL checks are offline and never make network requests; scan text is not persisted or returned. Opt-in saved history is explicitly rejected until account storage is implemented.

**Verification:** parsed all 10 JSON manifests/content files and passed `node --check` on the service worker, ESLint config, and Playwright config using Node 24.22.3. Added backend rule/API tests and a web scanner test; they have not run locally. The first GitHub Actions run executed: Compose configuration passed; Ruff found import/unused-import issues in the API job, and npm dependency resolution failed because TypeScript 7.0.2 was outside `typescript-eslint@8.74.0`'s peer range. These findings are being corrected in the next milestone. Dependency installation and application checks are unavailable locally: npm is absent, the available Python executable is a Windows Store shim, and Docker, PostgreSQL, and Android tooling are absent.

**Limitations:** the rule set is a small starter, not a validated detector. No external reputation or LLM provider is configured. The web and Android guest scanners call the new API; other product modules remain guidance/placeholders. Dependency installation, typecheck, tests, builds, migrations, and Compose startup remain unverified locally. Generate and commit `package-lock.json` on a machine with npm before relying on reproducible installs.

## 2026-11-25 — Backend account foundation

**Objective:** implement the account and session foundation: registration, login, logout, refresh rotation, user profile updates/deletion, rate limiting, and consistent API errors.

**Completed:** added Argon2 password hashing, short-lived access JWTs, hashed single-use refresh tokens with family reuse revocation, web HttpOnly refresh cookies with CSRF double-submit validation, mobile response refresh tokens, account/profile endpoints, a refresh-token migration, Redis-backed production rate limits, and auth/profile tests. Updated the API and security docs. Fixed the initial Ruff import findings and pinned TypeScript to 6.0.3 to satisfy the peer range reported by npm.

**Verification:** Node 24.22.3 successfully parsed the affected JSON manifests and `node --check` passed for the service worker and JavaScript-based config files. GitHub Actions confirmed Compose, Ruff, pytest, Alembic migration, web typecheck, web lint, Vitest, and web build pass. The mobile typecheck then found a wrong relative path to the shared emergency content JSON; that import is corrected locally. Python/pytest/Ruff and npm-based checks cannot run locally because the workspace has no usable Python installation or npm; the next CI run will verify the mobile correction.

**Limitations:** password reset and client sign-in screens are not implemented. Only user-profile data exists, so ownership enforcement for scans, alerts, cases, evidence, and contacts remains future work. No production deployment has been configured.

## 2026-11-25 — Detection pipeline and evaluation

**Objective:** improve the explainable rules, add normalization/language/entity extraction, assess URLs without fetching them, and create a labeled evaluation set.

**Completed:** moved message patterns to a versioned JSON rules file; added NFKC/invisible-character normalization with source-offset mapping, English/Hindi/Kannada script detection with request override, URL/phone/UPI candidate extraction, and URL risk signals for shorteners, raw IPs, punycode, userinfo, risky TLDs, unusual ports, excessive subdomains, and lookalike brands. Added a 150-message synthetic JSONL fixture set and an evaluator that reports confusion counts, precision/recall, false-positive/false-negative rates, category metrics, and measured latency. Added the evaluator to CI. URL inspection stays offline and makes no network requests.

**Verification:** local Node validation counted 150 records (120 synthetic scam-style and 30 ordinary examples) across all three languages and parsed the rules JSON. GitHub Actions passed Compose validation and all web checks, plus Ruff, pytest, and the Alembic migration. The evaluator command initially failed because invoking the file path did not make `backend/` importable; CI and runbook commands now execute it as a backend module. The first successful evaluator run exposed four fixture misses, followed by two Kannada customer-care category mismatches; rules and regression cases were updated.

**Limitations:** this fixture set is hand-authored and not representative of real scam traffic. No LLM or reputation provider is configured; redirect fetching remains disabled. Safe-fetch SSRF defenses, broader category coverage, and validation with independent data remain open.

## 2026-11-25 — Detection evaluation and emergency web flow

**Detection evaluation:** on GitHub Actions run [45475065726](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45475065726), the API job passed Ruff, pytest, evaluation, and Alembic. The 150 synthetic fixtures produced 120 true positives, 0 false positives, 0 false negatives, and 30 true negatives: precision 1.0000, recall 1.0000, false-positive rate 0.0000, false-negative rate 0.0000, exact category accuracy 1.0000, and mean rule-check latency 0.115 ms on the hosted runner. Each of the ten fixture categories had 12/12 exact category matches. These are results on hand-authored fixtures only; they do not estimate real-world performance.

**Web emergency flow:** added a one-step-at-a-time checklist with completion tracking, next/back/reset controls, localized emergency step copy, direct 1930 and official portal actions, and optional report references held in the current browser tab only. Basic checks reject common OTP- and card-number-shaped values. Added unit and Playwright flow coverage. The initial run found the tests had assumed the wrong step order and dashboard button label; corrected tests and strict TypeScript errors have been pushed. Follow-up GitHub Actions run [45475638204](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45475638204) passed all four jobs: API, web, browser smoke, and Compose.

**Limitations:** the emergency checklist is browser-session state, not a saved backend case. It does not upload or retain message contents. Other web modules remain guidance screens or unavailable guest states; authentication UI, saved history, alert generation, lessons/quizzes, and account ownership workflows remain open. No password-reset delivery provider, optional LLM, reputation provider, SSRF-safe fetcher, production deployment, or real-world detection corpus is configured.

## 2026-11-25 — Web account and welcome flows

**Completed:** added web registration and sign-in with validation, an explicit remember-me preference, in-memory access-token storage, HttpOnly refresh cookies with CSRF, profile preferences, sign-out, account deletion, and guest-mode messaging. Added a welcome page that explains the current guest privacy boundary and links directly to guest scan or account setup. Implemented password reset request/confirmation endpoints with SHA-256 hashed one-time tokens, expiry, generic account-independent responses, optional SMTP TLS delivery, token replay rejection, and session family revocation. Added a configurable reset screen and confirmation flow.

**Verification:** GitHub Actions run [45478828246](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45478828246) passed API Ruff/pytest/evaluation/migrations, web typecheck/lint/unit tests/build, browser E2E, mobile typecheck, and Compose validation for the account screens. The welcome flow was pushed in [4a1ed3e](https://github.com/pradhan5117np-stack/scamshieled_hackproject/commit/4a1ed3e64ecb81f5b808550aaccdfa88a831def2), and its run plus the new password-reset implementation are awaiting CI.

**CI correction:** welcome run [45480000439](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45480000439) passed all four jobs, including the welcome E2E. The first password-reset run stopped at Ruff import formatting before backend tests; the integrated fix and history run [45485706196](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45485706196) passed all four jobs.

**Limitations:** SMTP must be configured to actually deliver reset emails. Account creation currently does not unlock saved scans because scan-history persistence and resource ownership are not implemented. Android authentication, saved history, learning activities, and most feature routes remain open.

## 2026-11-25 — Opt-in scan metadata history

**Completed:** added account-owned scan summary records, opt-in save behavior for authenticated message and URL scans, a private keyset-paginated history API, item deletion, and a web history screen. Stored fields are limited to scan type, verdict, risk level, category, language, and timestamp; source message text, URLs, phone/UPI values, and extracted entities are excluded. Added owner-isolation, pagination, guest-save rejection, and deletion tests.

**Verification:** GitHub Actions run [45485706196](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45485706196) passed API Ruff, pytest, the synthetic evaluator and Alembic upgrade; web typecheck, lint, unit tests, build and mobile typecheck; browser E2E; and Compose validation. Follow-up run [45486625915](https://github.com/pradhan5117np-stack/scamshieled_hackproject/actions/runs/45486625915) passed all four jobs after adding the Home recent-scan card and a browser test for signed-in history opt-in.

**Limitations:** cases, alerts, family sharing, and evidence storage remain unimplemented. Web and Android learning content is the next milestone and is awaiting CI.

## 2026-11-25 — Learning and practice flow

**Completed:** added shared English, Hindi, and Kannada lesson and quiz content for ten common scam patterns, including KYC impersonation, UPI requests, fake jobs, prize fees, investment claims, phishing links, fake support numbers, delivery fees, and remote-access requests. Web lessons, quizzes, and synthetic scenarios explain the safer action and track tab-local progress. The Android Learn tab shares the localized examples and interactive questions. Storage failures do not prevent a lesson from being completed in the current view.

**Verification:** the web unit test and Playwright completion flow, including the ten-lesson progress count, plus the Android TypeScript check are included in the next CI run. Local npm-based checks are unavailable in this environment; the GitHub Actions result will be recorded after the push.

**Limitations:** web progress is local to the current browser tab; Android progress is stored on-device but is not synchronized to an account. Independent translation review, remaining Android integrations, and the other planned modules remain open.

## 2026-11-25 — Local QR scanning and assessment

**Completed locally:** added an Android camera flow with explicit permission and denied-permission handling, on-device QR decoding, a decoded-content preview, and a user-triggered assessment request. Added a rate-limited API endpoint that classifies URL, UPI payment request, or text payloads, parses bounded UPI payee/amount/note fields, returns localized payment cautions, never opens the URL or initiates a payment, and does not save QR payloads. Added API regression tests and updated the OpenAPI and product documentation.

**Verification:** JSON lesson data was validated locally. The QR API tests were added but could not be run because Python/pytest is unavailable; the mobile typecheck and native permission/camera checks also remain pending. GitHub writes are currently blocked by the connected tool's usage limit, so this local milestone has not been committed or run through CI.

**Limitations:** camera behavior still requires a physical Android device or emulator. Share-to-app intake, mobile account flows, push notifications, and installable EAS output remain open.

## 2026-11-25 — Local Android account and history flow

**Completed locally:** added mobile registration and sign-in, startup refresh-token rotation, an in-memory access token, Expo SecureStore persistence for the rotating refresh token, authenticated request retry, server-side sign-out, and profile state. Mobile message/URL scans now offer an explicit save-history choice; the profile lists, paginates, and deletes owner-scoped metadata summaries. Mobile lesson completion IDs also persist on-device through SecureStore and can be cleared by the user.

**Verification:** mobile TypeScript checks and API integration tests were not run locally because npm and a usable Python installation are unavailable. The changes remain local and are not in GitHub CI because the connected GitHub write tool is usage-limited.

**Limitations:** mobile password reset and account deletion flows remain open. SecureStore restoration, refresh rotation, and account history require CI and device validation.

## 2026-11-25 — Local Android account recovery and deletion

**Completed locally:** added a generic mobile password-reset request in Profile, mobile-specific reset email deep links (`scamshield://auth/reset-password` by default), and a native single-use token confirmation screen. Added explicit confirmation before account deletion; successful deletion clears the server account and local SecureStore refresh token. Updated API schema and handover docs.

**Verification:** added an API regression test for the mobile deep-link shape. No tests or typecheck were run locally because Python and npm are unavailable. The changes are local only; GitHub writes remain blocked by the connected tool's usage limit.

**Limitations:** SMTP must be configured. Users need the app installed to open the default custom-scheme link; app-link fallback, push, device testing, and an EAS artifact remain open.

## 2026-11-25 — Local Android share-to-scan intake

**Completed locally:** configured `expo-share-intent` for Android text shares and added a scanner handoff that fills the link or message field. Shared content remains in the app and is not submitted until the user presses Check. Oversize or empty shares are rejected and the native share payload is cleared after intake.

**Verification:** reviewed the package's SDK 58 setup instructions and pinned the compatible 9.0.0 package. No package install, typecheck, or native build was run locally because npm and Android tooling are unavailable. GitHub writes remain blocked by the connected tool usage limit.

**Limitations:** this native share target requires a development/production build rather than Expo Go. Text and URL intake is configured; share-target behavior still needs a device test. Push registration/sending and an installable EAS artifact remain open.

## 2026-11-25 — Local Android EAS profiles

**Completed locally:** added EAS development APK, preview APK, and production app-bundle profiles. Updated the mobile start command to use a development client and documented local native build steps for share-intent support.

**Verification:** no EAS build was run; the workspace has no Expo account/project ID, Android signing setup, npm installation, or Android SDK. EAS profile syntax still needs CLI validation.

## 2026-11-25 — Local Android emergency checklist

**Completed locally:** replaced the static Alerts page with step-by-step money-loss and account-hacked checklists in English, Hindi, and Kannada. Added progress controls, the official 1930 call and reporting-portal actions, an always-visible disclaimer, and opt-in on-device storage for progress and validated complaint references. Refreshed the official-contact verification date after checking the National Cyber Crime Reporting Portal.

**Verification:** no mobile typecheck or device preview was possible because npm and Android tooling are unavailable. SecureStore, locale, navigation, and deep-link behavior remain unverified on a device.

## 2026-11-25 — Web preview setup attempt

**Completed locally:** added pnpm workspace metadata and documented the web preview and workspace verification commands.

**Verification:** Node 24.22.3 and pnpm 11.25.0 are available. `pnpm install` could not retrieve packages from the registry, and an offline retry failed when Windows denied pnpm's attempt to symlink the workspace into its package store outside the writable root. No dependencies or lockfile were produced; the web app was not built or previewed. This workspace also has no `.git` repository. The connected GitHub write was previously rejected by automatic approval review due to its usage limit, so these local changes have not been pushed.

**Next owner commands:** on a machine with registry access and a normal pnpm workspace, run `pnpm install --link-workspace-packages`, then `pnpm --filter @scamshield/web dev` and open `http://localhost:5173`. Run the build and verification commands in `TESTING.md` before treating the application as release-ready.

## 2026-11-25 — Local Android account-security checklist

**Completed locally:** added a Secure My Account route available from Profile, with a six-step guidance checklist in English, Hindi, and Kannada. Completion indices are stored in SecureStore. Added explicit official Google Security Checkup and Meta security links and guidance-only copy; the screen never requests credentials or changes account settings.

**Verification:** links were checked against official Google and Meta pages. No TypeScript check or device preview was run because dependency installation and Android tooling are unavailable. Progress restoration, route navigation, and external-link behavior still need device validation.

## 2026-11-25 — Separate Android alerts from emergency guidance

**Completed locally:** moved the offline emergency checklist to a dedicated stack route and linked it from Home. The Alerts tab now states that push registration and delivery are unavailable, explains that monitoring is not active, and does not display fabricated alerts. Added language selection and direct links to scanning, emergency help, and account security.

**Verification:** source and route configuration were reviewed. No TypeScript check or device preview was run because dependencies and Android tooling remain unavailable; navigation and all three localized states still need device validation.

## 2026-11-25 — Android category and feature navigation

**Completed locally:** added the six product categories to Home, category feature lists, and feature detail routes. Implemented destinations open the existing scanner, learning, account, alerts, emergency, and security flows. Privacy and language items show guidance; family sharing and emergency history are explicitly unavailable. URL and emergency scenario destinations now pass their selected modes into the target screens.

**Verification:** route definitions and destination mappings were reviewed. The Android typecheck and device preview remain unverified because dependencies could not be installed and Android tooling is unavailable.

## 2026-11-25 — Shared mobile language preference

**Completed locally:** added a SecureStore-backed English/Hindi/Kannada language provider, exposed the selector on Home and Profile, synchronized tab labels and existing localized Alerts, emergency, learning, and account-security screens, and sent the selected language with mobile message/URL assessments and registration.

**Verification:** locale-provider integration was reviewed in source. No app typecheck or restart/device validation was possible in this environment. Several mobile screen labels and category/feature details remain English-only.

## 2026-11-25 — Mobile Home saved activity

**Completed locally:** Home now shows up to three saved scan summaries only for the signed-in account, with a loading/error/empty state and a link to full history. It clears old account rows when the signed-in user changes. Added progress counts for the money-loss and account-hacked offline checklists without displaying stored references.

**Verification:** source was reviewed for opt-in and account-switch behavior. No mobile typecheck or device validation was possible because dependencies and Android tooling remain unavailable.

## 2026-11-25 — Localized Android scan and account flows

**Completed locally:** extended the shared English/Hindi/Kannada preference across the message/link scanner, QR camera assessment, Profile sign-in/register/reset/delete flows, saved-history labels, and Learn progress/quiz controls. QR assessments now send the selected language to the API. Removed a duplicate style key found during source review.

**Verification:** reviewed request payloads, locale lookups, and screen wiring in source. TypeScript validation and native preview remain unavailable because the workspace dependencies, package-registry access, and Android toolchain are missing.

## 2026-11-25 — Localized web scanner interface

**Completed locally:** added English, Hindi, and Kannada copy for web message/URL scan forms, privacy and history controls, local validation, and result framing. Scan requests continue to use the selected language and preserve the existing opt-in metadata behavior.

**Verification:** reviewed locale branches and the existing API calls in source. Web typecheck/build and browser preview could not run because package dependencies are not installed and registry access failed.

## 2026-11-25 — Localized web Home

**Completed locally:** translated the web dashboard's main hero, quick actions, emergency entry, category tiles, recent-scan states, and next-step copy in English, Hindi, and Kannada. It keeps the same account-scoped scan history query and navigation destinations.

**Verification:** source review only. Typecheck and browser preview are still unavailable because dependencies are absent and registry access did not succeed.

## 2026-11-25 — Workspace install and preview build

**Completed locally:** installed the pinned workspace dependencies into the ignored `.pnpm-store/` cache and generated `pnpm-lock.yaml`. Fixed mobile language type imports to use the API type subpath, added the missing Profile success style, and corrected the emergency-resource JSON import path.

**Verification:** `apps/web/node_modules/.bin/tsc.CMD --noEmit` passed; `apps/web/node_modules/.bin/vite.CMD build` passed; `apps/mobile/node_modules/.bin/tsc.CMD --noEmit` passed. Vite reports the main JavaScript chunk at 618.66 kB minified, above the 500 kB warning threshold. No test suites were run.

**Preview:** the production bundle was opened and visually verified in Codex's in-app browser at `http://127.0.0.1:4175/` (Vite selected this port because 4173 and 4174 were occupied). The ScamShield Home screen and navigation render. The backend is not running, so sign-in and API-backed scan actions are not live in this preview.

**Remaining:** no `.git` directory is present in this workspace, and the previously rejected GitHub write is still unavailable. Push, backend runtime, Android device preview/EAS artifact, push delivery, and planned family/community modules are not complete.


## 2026-11-25 — Offline guest message scan

**Completed:** guest message scans now use the shared detection rule file locally when the scan API is unavailable. Results are labeled as an offline, reduced-coverage check in English, Hindi, and Kannada. Opted-in history still requires the API; no local history is written.

**Verification:** web TypeScript check and production build passed. No tests were run, per the current instruction.

**Limit:** offline URL checks, saved history, sign-in, and other API-backed flows still require the backend.

## 2026-11-25 — Offline guest URL scan

**Completed:** guest URL scans now assess syntax, shorteners, IP hosts, punycode, risky TLDs, excessive subdomains, user info, unusual ports, and lookalike brands locally from shared signal data. Results show the host, HTTPS presence, and that reputation was not checked; the URL is never opened. Opted-in history still requires the API.

**Verification:** web TypeScript check and production build passed. No tests were run.

**Limit:** no live reputation provider is configured; saved history and other backend-backed routes still require the API.

## 2026-11-25 — Guest profile preferences

**Completed:** the profile screen now localizes account and guest states in English, Hindi, and Kannada. Guests can change the app language immediately and save it on-device; signed-in profile edits still use the authenticated API.

**Verification:** web TypeScript check and production build passed. No tests were run.

**Limit:** account creation, profile persistence, sign-out, and deletion require the backend; GitHub push remains unavailable in this workspace.
